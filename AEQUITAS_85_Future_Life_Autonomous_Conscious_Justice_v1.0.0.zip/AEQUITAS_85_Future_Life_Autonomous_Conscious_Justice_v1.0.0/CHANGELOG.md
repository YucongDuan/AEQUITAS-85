# Changelog

## 1.0.0
- Initial AEQUITAS-85 autonomous proactive justice reference release.
