# Code of Conduct

Respect affected parties, avoid doxxing, harassment, dehumanization and unsupported allegations. Critique claims and systems, not protected identities.
