# Contributing

Contributions must preserve provenance, contestability, non-discrimination, no-binding-AI-judgment boundaries, deterministic tests and public documentation. Synthetic data only in pull requests.
