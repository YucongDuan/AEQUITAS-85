# Governance

The public constitution, versioned source registry, affected-party voice, named authority chain, appeals, independent audit and correction worldlines govern changes. No model, administrator or organization may silently rewrite evidence or acquire judicial authority.
