# Roadmap

- v1.1: jurisdiction-specific rule packs and evidence adapters
- v1.2: structured hearing and dissent capture
- v1.3: independent fairness and accessibility test harness
- v2.0: multi-institution federated responsibility worldlines
