# Security

Report vulnerabilities privately. Do not upload real case files, biometric data, confidential evidence or privileged communications to the demo. External write is disabled by default. Production requires institutional security review, identity, encryption, key management, retention and incident response.
