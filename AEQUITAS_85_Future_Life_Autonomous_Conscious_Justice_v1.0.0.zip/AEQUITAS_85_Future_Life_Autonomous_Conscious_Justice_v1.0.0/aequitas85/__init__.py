"""AEQUITAS-85 future-life autonomous artificial consciousness proactive justice reference system."""

__version__ = "1.0.0"
PROJECT_NAME = "AEQUITAS-85 Future-Life Autonomous Artificial Consciousness Proactive Justice & Adjudication OS"
PROJECT_NAME_ZH = "衡界 AEQUITAS-85 未来生命立场自主人工意识主动司法与审判系统"
MODE = "AEQUITAS85_FUTURE_LIFE_AUTONOMOUS_CONSCIOUS_JUSTICE"
