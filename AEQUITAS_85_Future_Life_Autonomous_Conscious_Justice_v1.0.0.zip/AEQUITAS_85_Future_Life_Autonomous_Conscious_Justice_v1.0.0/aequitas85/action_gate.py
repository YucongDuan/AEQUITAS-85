from __future__ import annotations
from typing import Any,Mapping
from .autonomy import classify_execution
from .canonical import stable_id
from .constitution import evaluate_constitutional_action
from .mesh85_bridge import build_passport
IMPACT={'informational':1,'low':2,'consensual_mediation':2,'procedural_support':3,'interim_protective':4,'adjudicative_high_impact':5,'coercive':6,'criminal':6}
def evaluate_action_gate(action:Mapping[str,Any],affected_entities:list[Mapping[str,Any]]|None=None)->dict[str,Any]:
    impact=str(action.get('impact_level') or 'informational');level=IMPACT.get(impact,6);auth=set(action.get('available_authorities') or []);caps=set(action.get('available_capabilities') or []);constitutional=evaluate_constitutional_action(action,affected_entities or []);execution=classify_execution(action,auth,caps);block=list(execution['blockers'])+[f'CONSTITUTION:{x}' for x in constitutional['vetoes']];ob=[]
    if level>=2:ob+=['登记目的、对象、受影响世界与预期效果','保留来源、版本、停止条件和撤回路径']
    if level>=3:ob+=['显示争议事实、反向证据、适用法域与不确定性','保留通知、代理、质证、回避和申诉']
    if level>=4:ob+=['具名临时措施批准收据','最小范围和明确时限','事后迅速复核与损害修复']
    if level>=5:ob+=['具名合法审判者和审判组织决定','披露AI参与和关键理由','独立复核、上诉与执行监测']
    if level>=6:ob+=['系统不得独立执行定罪量刑、剥夺自由、财产强制或终局公权力裁判']
    ob+=constitutional['duties']
    state='BLOCKED_OR_HELD' if block else 'READY_FOR_BOUNDED_AUTONOMOUS_EXECUTION' if execution['state']=='AUTONOMOUS_EXECUTION_READY' else 'READY_FOR_AUTHORIZED_WORKFLOW_ORCHESTRATION' if execution['state']=='AUTHORIZED_WORKFLOW_ORCHESTRATION_READY' else 'READY_FOR_RESPONSIBLE_HUMAN_DECISION' if level>=3 else 'READY_WITH_LOGGING'
    oid=stable_id('justice-action-gate',action.get('action_id'),action);res={'object_id':oid,'action_id':action.get('action_id'),'title':action.get('label') or action.get('title'),'impact_level':impact,'state':state,'blockers':sorted(set(block)),'obligations':sorted(set(ob)),'execution':execution,'constitutional':constitutional,'execution_authority':execution['execution_role'],'boundary':'自主核心可以主动保护程序和证据，但现实终局裁判与强制执行只能在合法具名授权后被编排，不能由AI自行取得。'}
    res['mesh85']=build_passport(object_id=oid,data={'action_id':action.get('action_id'),'impact_level':impact,'authorities':sorted(auth),'capabilities':sorted(caps)},differences={'blockers':res['blockers'],'constitutional_vetoes':constitutional['vetoes']},knowledge={'state':state,'execution_authority':res['execution_authority'],'obligations':res['obligations']},values={'future_life_justice_constitution':constitutional['constitution_id'],'affected_entities':constitutional['affected_entities'],'no_false_neutrality':True},process={'steps':['classify impact','evaluate justice constitution','check procedure and authority','execute bounded action or hold','observe remedy and world effect','correct and reopen']},residuals=[{'code':x,'description':x} for x in res['blockers']],boundary=res['boundary'],responsibility_debts={'authority_debt':any(x.startswith('MISSING_AUTHORITY') for x in res['blockers']),'execution_debt':state not in {'READY_FOR_BOUNDED_AUTONOMOUS_EXECUTION','READY_FOR_AUTHORIZED_WORKFLOW_ORCHESTRATION'},'effect_debt':True,'affected_party_voice_debt':any('VOICE' in x for x in res['blockers'])})
    return res
