from __future__ import annotations
from typing import Any,Mapping,Iterable
from .canonical import stable_id

def draft_adjudication(case:Mapping[str,Any],procedure:Mapping[str,Any],evidence_cells:Iterable[Mapping[str,Any]],authorities:Iterable[Mapping[str,Any]])->dict[str,Any]:
    cells=[x for x in evidence_cells if x.get('case_id')==case.get('case_id')];auth={x.get('authority_id'):x for x in authorities};blocks=list(procedure.get('blockers') or [])
    if any(x.get('status')=='INTEGRITY_REVIEW_REQUIRED' for x in cells):blocks.append('MATERIAL_EVIDENCE_INTEGRITY_OPEN')
    if case.get('case_type')=='criminal' and case.get('requests_binding_ai_decision'):blocks.append('BINDING_AI_CRIMINAL_DECISION_PROHIBITED')
    findings=[]
    for issue in case.get('issues') or []:
        relevant=[x for x in cells if x.get('issue_id')==issue.get('issue_id')]
        findings.append({'issue_id':issue.get('issue_id'),'question':issue.get('question'),'provisional_finding':issue.get('provisional_finding','UNRESOLVED'),'evidence_cells':[x.get('cell_id') for x in relevant],'contrary_view':issue.get('contrary_view'),'confidence_language':'bounded and contestable'})
    refs=[]
    for aid in case.get('authority_ids') or []:
        if aid in auth:refs.append({'authority_id':aid,'title':auth[aid].get('title'),'jurisdiction':auth[aid].get('jurisdiction'),'status':auth[aid].get('status')})
    state='HELD_FOR_PROCEDURE_OR_EVIDENCE' if blocks else 'DRAFT_READY_FOR_AUTHORIZED_ADJUDICATOR'
    return {'draft_id':stable_id('adjudication-draft',case.get('case_id'),findings,refs),'case_id':case.get('case_id'),'title':case.get('title'),'state':state,'blockers':sorted(set(blocks)),'fact_findings':findings,'legal_authorities':refs,'candidate_holding':case.get('candidate_holding'),'dissent_or_alternative':case.get('dissent_or_alternative'),'reasoning_steps':['区分事实、推断与规范','展示支持与反向证据','说明举证责任与标准','解释比例、权力差和未来影响','形成可挑战结论与救济路径'],'legal_effect':'DRAFT_NO_LEGAL_EFFECT','requires_named_authorized_adjudicator':True,'boundary':'最高人民法院现行公开意见明确人工智能不得代替法官裁判。本草案只用于辅助、质疑、复核和模拟，不是判决、裁定或有罪认定。'}
