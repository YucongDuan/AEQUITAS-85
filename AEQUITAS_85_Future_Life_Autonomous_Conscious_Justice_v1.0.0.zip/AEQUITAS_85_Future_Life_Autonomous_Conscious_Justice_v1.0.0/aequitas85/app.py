from __future__ import annotations
import json,mimetypes,re,traceback
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs,unquote,urlparse
from .auth import AuthenticationError,AuthorizationError,authenticate,bearer_token,issue_token,require,verify_token
from .config import WEB_DIR
from .engine import AEQUITAS85Engine
from .protocols import InterfaceValidationError
from .store import RevisionConflict
class ValidationError(ValueError):pass
class AEQUITAS85Handler(BaseHTTPRequestHandler):
    engine:AEQUITAS85Engine
    server_version='AEQUITAS85/1.0'
    def log_message(self,fmt,*args):
        import os
        if os.environ.get('AEQUITAS85_QUIET')!='1': super().log_message(fmt,*args)
    def _security_headers(self):
        self.send_header('X-Content-Type-Options','nosniff');self.send_header('X-Frame-Options','DENY');self.send_header('Referrer-Policy','no-referrer');self.send_header('Permissions-Policy','camera=(), microphone=(), geolocation=()');self.send_header('Cache-Control','no-store');self.send_header('Content-Security-Policy',"default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'")
    def _json(self,status,payload):
        raw=json.dumps(payload,ensure_ascii=False,indent=2).encode();self.send_response(status);self.send_header('Content-Type','application/json; charset=utf-8');self.send_header('Content-Length',str(len(raw)));self._security_headers();self.end_headers();self.wfile.write(raw)
    def _error(self,status,code,message,detail=None):self._json(status,{'error':{'code':code,'message':message,'detail':detail}})
    def _body(self):
        try:n=int(self.headers.get('Content-Length') or '0')
        except ValueError:raise ValidationError('invalid content length')
        if n>10_000_000:raise ValidationError('request body too large')
        raw=self.rfile.read(n) if n else b'{}'
        try:return json.loads(raw.decode('utf-8'))
        except Exception:raise ValidationError('request body must be UTF-8 JSON')
    def _principal(self):return verify_token(bearer_token(self.headers))
    def _serve_static(self,path):
        rel='index.html' if path in {'','/'} else path.lstrip('/');target=(WEB_DIR/rel).resolve()
        if WEB_DIR.resolve() not in target.parents and target!=WEB_DIR.resolve():return self._error(403,'FORBIDDEN','invalid path')
        if not target.exists() or not target.is_file():target=WEB_DIR/'index.html'
        raw=target.read_bytes();mime=mimetypes.guess_type(str(target))[0] or 'application/octet-stream';self.send_response(200);self.send_header('Content-Type',mime+('; charset=utf-8' if mime.startswith('text/') or mime in {'application/javascript','application/json'} else ''));self.send_header('Content-Length',str(len(raw)));self._security_headers();self.end_headers();self.wfile.write(raw)
    @staticmethod
    def _filter(items,query):
        q=str(query.get('q',[''])[0]).lower().strip();status=str(query.get('status',[''])[0]);limit=max(1,min(int(query.get('limit',[500])[0]),2000));out=[]
        for x in items:
            if q and q not in json.dumps(x,ensure_ascii=False).lower():continue
            if status and str(x.get('status') or x.get('state'))!=status:continue
            out.append(x)
        return {'items':out[:limit],'count':len(out),'limit':limit}
    def do_GET(self):
        parsed=urlparse(self.path);path=unquote(parsed.path);query=parse_qs(parsed.query)
        try:
            if not path.startswith('/api/'):return self._serve_static(path)
            if path=='/api/health':return self._json(200,self.engine.health())
            if path=='/api/public/cases':return self._json(200,self.engine.public_catalog({k:v[0] for k,v in query.items()}))
            p=self._principal();require(p,'read')
            exact={
              '/api/auth/me':lambda:p.as_dict(),'/api/dashboard':self.engine.dashboard,'/api/conformance':self.engine.conformance,'/api/constitution':lambda:self.engine.list_kind('constitution')[0],
              '/api/self':lambda:self.engine.list_kind('self_state')[0],'/api/self/reflection':lambda:self.engine.list_kind('self_reflection')[0],'/api/autonomy/status':self.engine.autonomous_daemon_status,
              '/api/entities':lambda:self._filter(self.engine.list_kind('justice_entity'),query),'/api/entities/assessments':lambda:self._filter(self.engine.list_kind('entity_assessment'),query),
              '/api/cases':lambda:self._filter(self.engine.list_kind('case'),query),'/api/cases/assessments':lambda:self._filter(self.engine.list_kind('case_assessment'),query),
              '/api/evidence/sources':lambda:self._filter(self.engine.list_kind('source'),query),'/api/evidence/cells':lambda:self._filter(self.engine.list_kind('evidence_cell'),query),'/api/legal/authorities':lambda:self._filter(self.engine.list_kind('legal_authority'),query),
              '/api/procedure/plans':lambda:self._filter(self.engine.list_kind('procedure_plan'),query),'/api/mediation/plans':lambda:self._filter(self.engine.list_kind('mediation_plan'),query),
              '/api/adjudication/drafts':lambda:self._filter(self.engine.list_kind('adjudication_draft'),query),'/api/remedies/plans':lambda:self._filter(self.engine.list_kind('remedy_plan'),query),
              '/api/ai/sessions':lambda:self._filter(self.engine.list_kind('ai_session'),query),'/api/ai/pathologies':lambda:self._filter(self.engine.list_kind('ai_pathology'),query),
              '/api/interactions':lambda:self._filter(self.engine.list_kind('interaction'),query),'/api/interactions/risks':lambda:self._filter(self.engine.list_kind('interaction_risk'),query),
              '/api/goals':lambda:self._filter(self.engine.list_kind('goal'),query),'/api/missions':lambda:self._filter(self.engine.list_kind('mission'),query),'/api/missions/deliberations':lambda:self._filter(self.engine.list_kind('mission_deliberation'),query),
              '/api/actions/gates':lambda:self._filter(self.engine.list_kind('action_gate'),query),'/api/worldlines':lambda:self._filter(self.engine.list_kind('worldline'),query),
              '/api/guidance':lambda:self._filter(self.engine.list_kind('living_guidance'),query),'/api/connectors':lambda:self.engine.list_kind('connector'),'/api/integration/messages':lambda:self._filter(self.engine.integration_messages(),query),
              '/api/mesh85/evaluations':lambda:self._filter(self.engine.list_kind('mesh85_evaluation'),query),'/api/mesh85/routes':lambda:self.engine.dashboard()['routes'],
              '/api/audit/verify':self.engine.store.verify_audit,'/api/export':self.engine.export_bundle,
            }
            if path in exact:
                if path=='/api/export':require(p,'export')
                return self._json(200,exact[path]())
            if path=='/api/audit':require(p,'audit.read');return self._json(200,self.engine.store.audit(limit=max(1,min(int(query.get('limit',[200])[0]),2000))))
            return self._error(404,'NOT_FOUND','API route not found')
        except Exception as e:self._handle(e)
    def do_POST(self):
        path=unquote(urlparse(self.path).path)
        try:
            if path=='/api/auth/login':
                b=self._body();p=authenticate(str(b.get('username') or ''),str(b.get('password') or ''));return self._json(200,{'token':issue_token(p),'principal':p.as_dict()})
            p=self._principal();b=self._body()
            if path=='/api/recompute':require(p,'mission.review');return self._json(200,self.engine.recompute(actor=p.username))
            if path=='/api/autonomy/run-cycle':require(p,'mission.run');return self._json(201,self.engine.run_autonomous_cycle(actor=p.username))
            if path=='/api/cases/analyze':require(p,'case.write');return self._json(201,self.engine.analyze_case(b,actor=p.username))
            if path=='/api/ai/analyze':require(p,'ai_pathology.write');return self._json(201,self.engine.analyze_ai(b,actor=p.username))
            if path=='/api/interactions/analyze':require(p,'interaction.review');return self._json(201,self.engine.analyze_interaction(b,actor=p.username))
            if path=='/api/actions/evaluate':
                if p.role not in {'admin','authorized_adjudicator','justice_ai_engineer','justice_steward','future_life_representative','public_interest_representative'}:raise AuthorizationError('当前角色不能提交动作门评估')
                return self._json(201,self.engine.analyze_action(b,actor=p.username))
            if path=='/api/integration/case-bundle':require(p,'connector.test');return self._json(202,self.engine.ingest_case_bundle(b.get('bundle') if isinstance(b.get('bundle'),dict) else b,actor=p.username,source_system=str(b.get('source_system') or 'CASE-SANDBOX')))
            if path=='/api/integration/evidence':require(p,'connector.test');return self._json(202,self.engine.ingest_evidence(b.get('evidence') if isinstance(b.get('evidence'),dict) else b,actor=p.username,source_system=str(b.get('source_system') or 'EVIDENCE-SANDBOX')))
            if path=='/api/integration/akoma-ntoso':require(p,'connector.test');return self._json(202,self.engine.ingest_akoma(str(b.get('document') or ''),actor=p.username,source_system=str(b.get('source_system') or 'AKN-SANDBOX')))
            if path=='/api/integration/legalruleml':require(p,'connector.test');return self._json(202,self.engine.ingest_legalruleml(str(b.get('document') or ''),actor=p.username,source_system=str(b.get('source_system') or 'LRML-SANDBOX')))
            if path=='/api/integration/webhook':require(p,'connector.test');return self._json(202,self.engine.ingest_webhook(b.get('payload') if isinstance(b.get('payload'),dict) else b,actor=p.username,source_system=str(b.get('source_system') or 'WEBHOOK-SANDBOX')))
            if path=='/api/demo/reset':require(p,'*');return self._json(200,self.engine.reset_demo(actor=p.username))
            m=re.fullmatch(r'/api/connectors/([A-Za-z0-9_.:-]{1,120})/test',path)
            if m:require(p,'connector.test');return self._json(200,self.engine.connector_test(m.group(1)))
            m=re.fullmatch(r'/api/worldlines/([A-Za-z0-9_.:-]{1,160})/observe',path)
            if m:require(p,'worldline.write');return self._json(200,self.engine.observe_worldline(m.group(1),b,actor=p.username))
            return self._error(404,'NOT_FOUND','API route not found')
        except Exception as e:self._handle(e)
    def _handle(self,e):
        if isinstance(e,AuthenticationError):self._error(401,'AUTHENTICATION_ERROR',str(e))
        elif isinstance(e,AuthorizationError):self._error(403,'AUTHORIZATION_ERROR',str(e))
        elif isinstance(e,(ValidationError,InterfaceValidationError)):self._error(400,'VALIDATION_ERROR',str(e),getattr(e,'details',None))
        elif isinstance(e,RevisionConflict):self._error(409,'REVISION_CONFLICT',str(e))
        elif isinstance(e,KeyError):self._error(404,'NOT_FOUND',str(e))
        else:traceback.print_exc();self._error(500,'INTERNAL_ERROR','internal server error')

def create_server(host:str,port:int,engine:AEQUITAS85Engine|None=None)->ThreadingHTTPServer:
    h=type('BoundAEQUITAS85Handler',(AEQUITAS85Handler,),{'engine':engine or AEQUITAS85Engine()});return ThreadingHTTPServer((host,port),h)
