from __future__ import annotations
import base64,hashlib,hmac,json,secrets,time
from dataclasses import dataclass
from typing import Any
from .config import demo_password,token_secret,token_ttl_seconds
class AuthenticationError(PermissionError):pass
class AuthorizationError(PermissionError):pass
@dataclass(frozen=True)
class Principal:
    username:str;display_name:str;role:str
    def as_dict(self)->dict[str,Any]:return {'username':self.username,'display_name':self.display_name,'role':self.role,'workflow_label_only':True,'real_world_credential_verified':False}
DEMO_USERS={
 'justice_steward':Principal('justice_steward','未来生命正义宪章守护角色','justice_steward'),
 'autonomous_core':Principal('autonomous_core','主动司法自主核心观察角色','autonomous_core_observer'),
 'judge':Principal('judge','演示审判责任角色','authorized_adjudicator'),
 'clerk':Principal('clerk','演示书记与程序管理角色','court_clerk'),
 'mediator':Principal('mediator','演示调解与修复司法角色','mediator'),
 'advocate':Principal('advocate','演示辩护与代理角色','advocate'),
 'public_interest':Principal('public_interest','公共利益与弱势保护角色','public_interest_representative'),
 'future_life':Principal('future_life','未来世代与非人生命代表角色','future_life_representative'),
 'engineer':Principal('engineer','司法AI与互联工程角色','justice_ai_engineer'),
 'auditor':Principal('auditor','责任世界线审计角色','auditor'),
 'admin':Principal('admin','演示系统管理员','admin'),
}
ROLE_CAPABILITIES={
 'admin':{'*'},
 'justice_steward':{'read','constitution.review','case.review','mission.review','action.hold','audit.read','export'},
 'autonomous_core_observer':{'read','self.read','mission.read','mission.run','worldline.read','worldline.write','export'},
 'authorized_adjudicator':{'read','case.write','case.review','procedure.approve','adjudication.review','remedy.approve','action.approve','worldline.write','audit.read','export'},
 'court_clerk':{'read','case.write','procedure.write','connector.test','audit.read','export'},
 'mediator':{'read','mediation.write','mediation.review','action.propose','export'},
 'advocate':{'read','evidence.write','case.write','objection.write','export'},
 'public_interest_representative':{'read','case.review','need.write','action.hold','export'},
 'future_life_representative':{'read','constitution.review','case.review','action.hold','export'},
 'justice_ai_engineer':{'read','ai_pathology.write','interaction.review','connector.test','mission.run','audit.read','export'},
 'auditor':{'read','audit.read','worldline.read','export'},
}
def _b64e(raw:bytes)->str:return base64.urlsafe_b64encode(raw).rstrip(b'=').decode('ascii')
def _b64d(v:str)->bytes:return base64.urlsafe_b64decode((v+'='*(-len(v)%4)).encode('ascii'))
def _pwd(password:str,username:str)->bytes:return hashlib.pbkdf2_hmac('sha256',password.encode(),f'aequitas85:{username}'.encode(),120000)
def authenticate(username:str,password:str)->Principal:
    p=DEMO_USERS.get(str(username).strip())
    if p is None:_pwd(str(password),'unknown');raise AuthenticationError('用户名或密码错误')
    if not hmac.compare_digest(_pwd(str(password),p.username),_pwd(demo_password(),p.username)):raise AuthenticationError('用户名或密码错误')
    return p
def issue_token(p:Principal)->str:
    now=int(time.time());payload={'sub':p.username,'role':p.role,'name':p.display_name,'iat':now,'exp':now+token_ttl_seconds(),'aud':'aequitas85-demo','jti':secrets.token_hex(8)}
    enc=_b64e(json.dumps(payload,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode());sig=_b64e(hmac.new(token_secret().encode(),enc.encode('ascii'),hashlib.sha256).digest());return f'{enc}.{sig}'
def verify_token(token:str|None)->Principal:
    if not token:raise AuthenticationError('缺少 Bearer 令牌')
    try:
        enc,sig=token.split('.',1);exp=_b64e(hmac.new(token_secret().encode(),enc.encode('ascii'),hashlib.sha256).digest())
        if not hmac.compare_digest(sig,exp):raise AuthenticationError('令牌签名无效')
        payload=json.loads(_b64d(enc).decode())
    except Exception as exc:
        if isinstance(exc,AuthenticationError):raise
        raise AuthenticationError('令牌格式无效') from exc
    if payload.get('aud')!='aequitas85-demo' or int(payload.get('exp',0))<int(time.time()):raise AuthenticationError('令牌无效或已过期')
    p=DEMO_USERS.get(str(payload.get('sub','')))
    if p is None or p.role!=payload.get('role'):raise AuthenticationError('令牌主体无效')
    return p
def bearer_token(headers:Any)->str|None:
    v=headers.get('Authorization') if headers is not None else None
    return str(v)[7:].strip() if v and str(v).lower().startswith('bearer ') else None
def has_capability(p:Principal,c:str)->bool:
    caps=ROLE_CAPABILITIES.get(p.role,set());return '*' in caps or c in caps or ('read' in caps and c.endswith('.read'))
def require(p:Principal,c:str)->None:
    if not has_capability(p,c):raise AuthorizationError(f'角色 {p.role} 无权限执行 {c}')
