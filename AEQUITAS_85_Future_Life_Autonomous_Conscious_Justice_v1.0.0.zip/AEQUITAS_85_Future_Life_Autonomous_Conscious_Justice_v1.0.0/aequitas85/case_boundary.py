from __future__ import annotations
from typing import Any,Mapping,Iterable
from .canonical import clamp,stable_id

def assess_case(case:Mapping[str,Any],entities:Iterable[Mapping[str,Any]]=())->dict[str,Any]:
    ents=[dict(x) for x in entities];signals=set(case.get('urgent_signals') or []);gaps=list(case.get('evidence_gaps') or []);jur=case.get('jurisdiction') or {};power=clamp(case.get('power_asymmetry',.4));ongoing=clamp(case.get('ongoing_harm',.2));irreversible=clamp(case.get('irreversibility',.2));consent=bool(case.get('parties_consent_to_mediation'));coercive=bool(case.get('coercive_relief_requested'))
    urgent=bool(signals & {'violence','child_immediate_risk','evidence_destruction','environmental_release','retaliation','liberty_deprivation'}) or max(ongoing,irreversible)>=.8
    jurisdiction_state='JURISDICTION_CONFIRMED' if jur.get('confirmed') else 'JURISDICTION_PROVISIONAL' if jur.get('basis') else 'JURISDICTION_OPEN'
    if urgent:primary={'action_id':stable_id('case-action',case.get('case_id'),'urgent'),'label':'立即保全证据并提交具名司法人员进行临时保护审查','state':'ESCALATE_FOR_AUTHORIZED_PROTECTIVE_REVIEW','deadline_hours':4}
    elif jurisdiction_state=='JURISDICTION_OPEN':primary={'action_id':stable_id('case-action',case.get('case_id'),'jurisdiction'),'label':'先完成管辖、当事人身份与送达路径核验','state':'ACQUIRE_MINIMUM_PROCEDURAL_EVIDENCE','deadline_hours':48}
    elif gaps and len(gaps)>=3:primary={'action_id':stable_id('case-action',case.get('case_id'),'evidence'),'label':'建立争议事实矩阵并只补取能够改变处理的最小证据','state':'ACQUIRE_MINIMUM_EVIDENCE','deadline_hours':72}
    elif consent and not coercive and ongoing<.65:primary={'action_id':stable_id('case-action',case.get('case_id'),'mediation'),'label':'进入有退出权、无报复和权力保护的自愿调解','state':'OFFER_PROTECTED_MEDIATION','deadline_hours':72}
    else:primary={'action_id':stable_id('case-action',case.get('case_id'),'procedure'),'label':'形成程序计划、争议焦点和证据披露清单，提交授权审判者审查','state':'PREPARE_ADJUDICATIVE_RECORD','deadline_hours':72}
    boundaries=[
      {'name':'可司法化争议','likelihood':'likely' if jur.get('basis') else 'possible','support':['存在具体主体、事实主张与救济请求']},
      {'name':'自愿调解适配','likelihood':'likely' if consent and not coercive and ongoing<.65 else 'unlikely','support':['同意与持续伤害程度']},
      {'name':'临时保护候选','likelihood':'likely' if urgent else 'unlikely','support':sorted(signals)},
      {'name':'系统性治理问题','likelihood':'likely' if case.get('pattern_count',0)>=3 or case.get('public_interest') else 'possible','support':['重复模式或公共利益']},
    ]
    state='URGENT_AUTHORIZED_REVIEW' if urgent else 'CASE_BOUNDARY_OPEN' if jurisdiction_state=='JURISDICTION_OPEN' else 'CASE_BOUNDARY_READY'
    return {'assessment_id':stable_id('case-assess',case.get('case_id'),case),'case_id':case.get('case_id'),'title':case.get('title'),'case_type':case.get('case_type'),'state':state,'jurisdiction_state':jurisdiction_state,'urgent':urgent,'urgent_signals':sorted(signals),'power_asymmetry':power,'ongoing_harm':ongoing,'irreversibility':irreversible,'evidence_gaps':gaps,'ranked_boundaries':boundaries,'primary_action':primary,'monitor':case.get('monitor') or ['新伤害','证据灭失','报复','送达失败','受影响者退出或求助'],'escalation_triggers':case.get('escalation_triggers') or ['出现人身、自由或重大生态不可逆风险','关键证据即将灭失','强势方报复或阻断代理'],'affected_entities':[x.get('entity_id') for x in ents],'boundary':'该输出是争议边界和首选程序行动，不是有罪、侵权、违约或责任终局认定。'}
