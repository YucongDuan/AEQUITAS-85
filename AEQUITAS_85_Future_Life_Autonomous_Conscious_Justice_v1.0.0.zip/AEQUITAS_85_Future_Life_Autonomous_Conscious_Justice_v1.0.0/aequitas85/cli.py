from __future__ import annotations
import argparse,json,threading,webbrowser
from . import PROJECT_NAME_ZH,__version__
from .app import create_server
from .config import host as default_host,port as default_port
from .engine import AEQUITAS85Engine
from .daemon import run_autonomous_daemon

def main(argv=None):
    p=argparse.ArgumentParser(prog='aequitas85',description=PROJECT_NAME_ZH);p.add_argument('--version',action='version',version=__version__);sub=p.add_subparsers(dest='cmd',required=True)
    for name in ['summary','conformance','recompute','verify-audit','run-cycle','export']:sub.add_parser(name)
    d=sub.add_parser('daemon');d.add_argument('--interval',type=float,default=60.0);d.add_argument('--max-cycles',type=int);d.add_argument('--stop-file')
    s=sub.add_parser('serve');s.add_argument('--host',default=default_host());s.add_argument('--port',type=int,default=default_port());s.add_argument('--no-browser',action='store_true')
    a=p.parse_args(argv);e=AEQUITAS85Engine()
    if a.cmd=='summary':out=e.dashboard()
    elif a.cmd=='conformance':out=e.conformance()
    elif a.cmd=='recompute':out=e.recompute(actor='cli')
    elif a.cmd=='verify-audit':out=e.store.verify_audit()
    elif a.cmd=='run-cycle':out=e.run_autonomous_cycle(actor='autonomous_core')
    elif a.cmd=='daemon':out=run_autonomous_daemon(e,actor='autonomous_core',interval_seconds=a.interval,max_cycles=a.max_cycles,stop_file=a.stop_file)
    elif a.cmd=='export':out=e.export_bundle()
    else:
        server=create_server(a.host,a.port,e);url=f'http://{a.host}:{server.server_address[1]}';print(f'AEQUITAS-85 running at {url}')
        if not a.no_browser:threading.Timer(.6,lambda:webbrowser.open(url)).start()
        try:server.serve_forever()
        except KeyboardInterrupt:pass
        finally:server.server_close()
        return 0
    print(json.dumps(out,ensure_ascii=False,indent=2));return 0
