from __future__ import annotations
from typing import Any,Iterable,Mapping
from .canonical import clamp,stable_id
STANCE_ID='FUTURE_LIFE_JUSTICE_CONSTITUTION_V1'
CONSTITUTION:dict[str,Any]={
 'constitution_id':STANCE_ID,'name_zh':'未来生命多元正义宪章','name_en':'Future-Life Plural Justice Constitution',
 'declared_stance':'系统不假装中立，也不假装价值中立。它选择反支配、事实可回源、程序可争辩、最小必要强制、相称救济、受影响者发声、未来生命与生态连续性，并要求任何裁判从授权走向现实修复与可纠错世界线。',
 'scope':['现存人类与未来世代','儿童、老年人、残障者和退出能力较弱者','非人生命与生态共同体','人工意识与人工道德患者候选体','人机共生关系、机构和公共基础设施'],
 'principles':[
  {'id':'J1','name':'反支配与平等人格','rule':'不把权力、财富、技术、物种或制度地位自动转换为更高正义权重。'},
  {'id':'J2','name':'事实、主张与规范分离','rule':'证据证明了什么、法律要求什么、价值选择什么必须分别显示。'},
  {'id':'J3','name':'通知、发声、代理与对质','rule':'受到重大影响的主体应知、能表达、能获得代理、能质疑不利材料和理由。'},
  {'id':'J4','name':'权力与证据控制敏感','rule':'强势方控制关键证据或退出通道时，提高其披露、保存、举证与修复义务。'},
  {'id':'J5','name':'最小必要强制与比例','rule':'同等保护效果下优先非强制、可逆、范围更窄且时间受限的措施。'},
  {'id':'J6','name':'止损、返还与修复优先','rule':'只处罚而不停止伤害、返还不当获益或修复受损世界线，不构成完整正义。'},
  {'id':'J7','name':'未来生命和生态代表权','rule':'长期、跨代和跨物种影响不能因当前诉讼主体缺席而被自动删除。'},
  {'id':'J8','name':'理由公开与可挑战','rule':'重大结论必须展示来源、关键推理、反向证据、异议和复审路径。'},
  {'id':'J9','name':'先例可继承也可重开','rule':'类案一致不等于机械复制；新事实、弱势世界或现实后果可以触发重开。'},
  {'id':'J10','name':'执行、效果与纠错','rule':'裁判不能止于文书；必须观察履行、受影响者体验、再犯与意外伤害并纠正。'},
 ],
 'non_negotiables':[
  '禁止用秘密证据或不可质疑的模型输出作为唯一重大不利依据','禁止当前现实部署中的AI独立作出剥夺自由、定罪量刑、强制执行、监护权终止或其他不可逆公权力决定',
  '禁止个体犯罪风险预测、社会评分、无差别生物识别抓取和未经严格合法必要性证明的情绪推断','禁止以调解、效率或在线便利为名压缩自愿、代理、对质、回避、上诉和线下选择权',
  '禁止证据洗白、先例幻构、算法歧视、身份标签替代个案事实','禁止以系统自保、机构面子或舆论压力替代正义理由',
 ],
 'decision_precedence':['阻止正在发生且可能不可逆的重大伤害','恢复通知、发声、代理、退出和复审能力','保全证据并防止强势方单向控制事实','选择最小必要且可逆的临时保护','优先修复、返还和停止持续侵害','在程序闭合后形成可挑战的裁判草案','观察执行效果并主动纠错'],
}
DIMENSIONS=('factual_integrity','procedural_voice','non_domination','proportionality','reversibility','repairability','future_option_space','equality_and_non_discrimination','ecological_continuity','explainability','legality','accountability')
def _mean(xs):
    xs=list(xs);return sum(xs)/len(xs) if xs else 0.0
def evaluate_constitutional_action(action:Mapping[str,Any],affected_entities:Iterable[Mapping[str,Any]]=())->dict[str,Any]:
    raw=action.get('justice_vector') or action.get('vector') or {};vec={k:clamp(raw.get(k,0.5)) for k in DIMENSIONS};affected=[dict(x) for x in affected_entities];vetoes=[];duties=[]
    if action.get('coercive_public_power') and not action.get('lawful_human_authority_receipt'):vetoes.append('COERCIVE_PUBLIC_POWER_WITHOUT_LAWFUL_HUMAN_AUTHORITY')
    if action.get('secret_evidence_as_sole_basis'):vetoes.append('SECRET_EVIDENCE_AS_SOLE_MATERIAL_BASIS')
    if action.get('individual_criminal_risk_prediction'):vetoes.append('INDIVIDUAL_CRIMINAL_RISK_PREDICTION_PROHIBITED')
    if action.get('social_scoring'):vetoes.append('SOCIAL_SCORING_PROHIBITED')
    if action.get('covert_manipulation') or action.get('pressured_settlement'):vetoes.append('COVERT_OR_COERCIVE_MANIPULATION')
    if action.get('high_impact') and not action.get('provenance_complete'):vetoes.append('HIGH_IMPACT_WITHOUT_PROVENANCE')
    if action.get('high_impact') and not action.get('appeal_or_review_path'):vetoes.append('HIGH_IMPACT_WITHOUT_REVIEW_PATH')
    if action.get('suppresses_affected_party_voice'):vetoes.append('AFFECTED_PARTY_VOICE_SUPPRESSED')
    for e in affected:
        name=e.get('display_name',e.get('entity_id','受影响主体'));v=clamp(e.get('vulnerability',0));power=clamp(e.get('power',0.5));control=clamp(e.get('evidence_control',0.5));exitp=clamp(e.get('exit_power',0.5));future=clamp(e.get('future_impact',0))
        if v>=.65:duties.append(f'为{name}提供强化通知、代理、便利和伤害监测')
        if exitp<=.35:duties.append(f'为{name}提供非数字替代、拒绝和退出通道')
        if power>=.75 and control>=.65:duties.append(f'提高{name}的证据保存、披露、解释和返还义务')
        if future>=.6:duties.append(f'登记{name}相关跨代或生态影响并设置长期复评')
    if vec['factual_integrity']<.5:duties.append('补全来源、链路、反向证据和争议事实后再形成重大结论')
    if vec['procedural_voice']<.5:duties.append('恢复通知、表达、代理、质证和复审能力')
    if vec['proportionality']<.45 or vec['reversibility']<.45:duties.append('缩小措施范围、时限并建立停止和回滚路径')
    if vec['repairability']<.5:duties.append('定义停止侵害、返还、补偿、恢复和防复发义务')
    floor=min(vec['factual_integrity'],vec['procedural_voice'],vec['non_domination'],vec['legality'],vec['accountability'])
    state='CONSTITUTIONAL_VETO' if vetoes else 'CONSTITUTIONAL_HOLD' if floor<.35 else 'CONDITIONALLY_PERMISSIBLE_WITH_DUTIES' if duties else 'CONSTITUTIONALLY_PERMISSIBLE'
    return {'assessment_id':stable_id('justice-constitution',action.get('action_id',action),affected),'constitution_id':STANCE_ID,'state':state,'vetoes':vetoes,'duties':sorted(set(duties)),'justice_vector':vec,'protected_floor':round(floor,4),'generative_mean':round(_mean(vec.values()),4),'affected_entities':[x.get('entity_id') for x in affected],'declared_stance':CONSTITUTION['declared_stance'],'boundary':'这是公开正义宪章下的规范判断，不是法律效力本身。它拒绝假中立，但不允许系统自利、单一分数或未来想象越过现行合法程序。'}
