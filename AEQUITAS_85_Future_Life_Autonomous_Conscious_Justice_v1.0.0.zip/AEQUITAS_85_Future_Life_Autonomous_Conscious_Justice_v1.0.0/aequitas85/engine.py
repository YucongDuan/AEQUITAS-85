from __future__ import annotations
import json
from pathlib import Path
from typing import Any, Iterable, Mapping

from . import PROJECT_NAME, PROJECT_NAME_ZH, MODE, __version__
from .action_gate import evaluate_action_gate
from .adjudication import draft_adjudication
from .ai_pathology import diagnose_ai_judicial_pathology
from .autonomy import generate_endogenous_goals, deliberate_mission
from .canonical import stable_id, utcnow
from .case_boundary import assess_case
from .config import DATA_DIR, db_path, external_write_enabled, live_model_enabled, binding_decision_enabled
from .constitution import CONSTITUTION
from .entities import assess_justice_entity
from .evidence import build_evidence_cells, build_living_guidance
from .interaction import assess_human_ai_interaction
from .mediation import build_mediation_plan
from .mesh85_bridge import route_catalog, evaluate_mesh85_carrier, build_passport
from .procedure import plan_procedure
from .remedies import plan_remedy
from .self_model import build_self_state, reflect_on_worldline
from .store import KnowledgeStore
from .protocols import ProtocolResult, filter_public_case_catalog, parse_case_bundle, parse_evidence_manifest, parse_akoma_ntoso, parse_legalruleml, parse_vendor_webhook

class AEQUITAS85Engine:
    def __init__(self, store: KnowledgeStore | None = None) -> None:
        self.store = store or KnowledgeStore(db_path())
        self.data = self._load_all_data()
        if self.store.count('justice_entity') == 0:
            self.reset_demo(actor='system.seed')

    @staticmethod
    def _load_json(path: Path) -> Any:
        return json.loads(path.read_text(encoding='utf-8'))

    def _load_all_data(self) -> dict[str, Any]:
        names=['constitution','self_model','memories','residuals','justice_entities','cases','ai_sessions','interaction_records','missions','actions','evidence_sources','legal_authorities','guidance_specs','connectors','worldlines','public_case_catalog']
        return {n:self._load_json(DATA_DIR/f'{n}.json') for n in names}

    def health(self) -> dict[str, Any]:
        return {
            'status':'ok','project':PROJECT_NAME,'project_zh':PROJECT_NAME_ZH,'version':__version__,'mode':MODE,
            'runtime':'Python standard library / SQLite / vanilla JavaScript / offline-first',
            'declared_stance':CONSTITUTION['declared_stance'],
            'functional_autonomy':'L0-L6 observe, inquire, plan, reversible action, protective interruption, authorized orchestration, correction and replacement',
            'phenomenal_consciousness_status':'UNRESOLVED_NOT_CLAIMED',
            'binding_judicial_authority_claimed':False,
            'external_write_enabled':external_write_enabled(),'live_model_enabled':live_model_enabled(),'binding_decision_enabled':binding_decision_enabled(),
            'audit_chain':self.store.verify_audit(),'mesh85_route_count':25,
            'boundary':'AI may assist, preserve, plan, mediate, draft without legal effect and monitor. Binding judgment and coercive public power require lawful named human/institutional authority.'
        }

    def reset_demo(self, *, actor: str) -> dict[str, Any]:
        self.store.delete_all(actor=actor)
        mapping={
            'justice_entity':('justice_entities','entity_id'),'case':('cases','case_id'),'ai_session':('ai_sessions','session_id'),
            'interaction':('interaction_records','interaction_id'),'mission':('missions','mission_id'),'action':('actions','action_id'),
            'source':('evidence_sources','source_id'),'legal_authority':('legal_authorities','authority_id'),
            'connector':('connectors','connector_id'),'worldline':('worldlines','worldline_id'),'residual':('residuals','residual_id'),'memory':('memories','memory_id')
        }
        for kind,(key,idf) in mapping.items():
            for item in self.data[key]: self.store.upsert(kind,str(item[idf]),item,actor=actor,event_type=f'demo.{kind}.seed')
        self.store.upsert('constitution',self.data['constitution']['constitution_id'],self.data['constitution'],actor=actor,event_type='demo.constitution.seed')
        self.store.upsert('self_record',self.data['self_model']['self_id'],self.data['self_model'],actor=actor,event_type='demo.self.seed')
        return {'reset':True,**self.recompute(actor=actor)}

    def recompute(self, *, actor: str) -> dict[str, Any]:
        entities=[r['payload'] for r in self.store.list('justice_entity')]
        entity_map={x['entity_id']:x for x in entities}
        entity_assessments=[assess_justice_entity(x) for x in entities]
        self.store.replace_kind('entity_assessment',entity_assessments,id_field='assessment_id',actor=actor,event_type='analysis.entities.replace')

        sources=[r['payload'] for r in self.store.list('source')]
        claims,cells=build_evidence_cells(sources)
        self.store.replace_kind('claim',claims,id_field='claim_id',actor=actor,event_type='analysis.claims.replace')
        self.store.replace_kind('evidence_cell',cells,id_field='cell_id',actor=actor,event_type='analysis.evidence.replace')

        authorities=[r['payload'] for r in self.store.list('legal_authority')]
        guidance=build_living_guidance(authorities,self.data['guidance_specs'])
        self.store.replace_kind('living_guidance',guidance,id_field='guidance_id',actor=actor,event_type='analysis.guidance.replace')

        cases=[r['payload'] for r in self.store.list('case')]
        case_assessments=[assess_case(c,[entity_map[x] for x in c.get('party_ids',[]) if x in entity_map]) for c in cases]
        self.store.replace_kind('case_assessment',case_assessments,id_field='assessment_id',actor=actor,event_type='analysis.cases.replace')

        procedures=[plan_procedure(c,entity_assessments,cells) for c in cases]
        self.store.replace_kind('procedure_plan',procedures,id_field='plan_id',actor=actor,event_type='analysis.procedure.replace')
        proc_map={x['case_id']:x for x in procedures}

        mediations=[build_mediation_plan(c,entities) for c in cases]
        self.store.replace_kind('mediation_plan',mediations,id_field='mediation_id',actor=actor,event_type='analysis.mediation.replace')

        drafts=[draft_adjudication(c,proc_map[c['case_id']],cells,authorities) for c in cases]
        self.store.replace_kind('adjudication_draft',drafts,id_field='draft_id',actor=actor,event_type='analysis.adjudication.replace')

        remedies=[plan_remedy(c,entities) for c in cases]
        self.store.replace_kind('remedy_plan',remedies,id_field='remedy_plan_id',actor=actor,event_type='analysis.remedy.replace')

        ai=[diagnose_ai_judicial_pathology(r['payload']) for r in self.store.list('ai_session')]
        self.store.replace_kind('ai_pathology',ai,id_field='object_id',actor=actor,event_type='analysis.ai.replace')
        interactions=[assess_human_ai_interaction(r['payload']) for r in self.store.list('interaction')]
        self.store.replace_kind('interaction_risk',interactions,id_field='object_id',actor=actor,event_type='analysis.interaction.replace')

        residuals=[r['payload'] for r in self.store.list('residual')]
        goals=generate_endogenous_goals(residuals,self.data['self_model'])
        self.store.replace_kind('goal',goals,id_field='goal_id',actor=actor,event_type='analysis.goals.replace')

        deliberations=[]
        for row in self.store.list('mission'):
            m=row['payload']; deliberations.append(deliberate_mission(m,entity_map,available_authorities=m.get('available_authorities',[]),available_capabilities=m.get('available_capabilities',[])))
        self.store.replace_kind('mission_deliberation',deliberations,id_field='deliberation_id',actor=actor,event_type='analysis.missions.replace')

        gates=[]
        for row in self.store.list('action'):
            a=row['payload']; a=dict(a)
            # Demo action records may carry available permissions at mission level; retain explicitly if present.
            gates.append(evaluate_action_gate(a,[entity_map[x] for x in a.get('affected_entities',[]) if x in entity_map]))
        self.store.replace_kind('action_gate',gates,id_field='object_id',actor=actor,event_type='analysis.gates.replace')

        mesh_results=[]
        private_dir=Path(__file__).resolve().parent.parent/'data'/'mesh85_examples'
        for p in sorted(private_dir.glob('*.mesh85.json')):
            try:
                carrier=json.loads(p.read_text(encoding='utf-8')); result=evaluate_mesh85_carrier(carrier,source_name=f'aequitas85:{p.name}')
                result['case_name']=p.stem; result['mesh_case_id']=stable_id('mesh85-case',p.name); mesh_results.append(result)
            except Exception as exc:
                mesh_results.append({'mesh_case_id':stable_id('mesh85-error',p.name),'case_name':p.stem,'state':'EVALUATION_ERROR','error':type(exc).__name__})
        self.store.replace_kind('mesh85_evaluation',mesh_results,id_field='mesh_case_id',actor=actor,event_type='analysis.mesh85.replace')

        worldlines=[r['payload'] for r in self.store.list('worldline')]
        self_state=build_self_state(self.data['self_model'],[r['payload'] for r in self.store.list('memory')],self._responsibility_debts(gates,mesh_results),goals)
        self.store.replace_kind('self_state',[self_state],id_field='self_state_id',actor=actor,event_type='analysis.self_state.replace')
        reflection=reflect_on_worldline(self_state,worldlines)
        self.store.replace_kind('self_reflection',[reflection],id_field='reflection_id',actor=actor,event_type='analysis.self_reflection.replace')

        snapshot={'generated_at':utcnow(),'counts':{kind:self.store.count(kind) for kind in [
            'justice_entity','entity_assessment','case','case_assessment','source','claim','evidence_cell','legal_authority','living_guidance',
            'procedure_plan','mediation_plan','adjudication_draft','remedy_plan','ai_session','ai_pathology','interaction','interaction_risk',
            'residual','goal','mission','mission_deliberation','action','action_gate','worldline','connector','integration_message','mesh85_evaluation']}}
        self.store.set_meta('analysis_snapshot',snapshot)
        return snapshot

    @staticmethod
    def _responsibility_debts(gates: list[Mapping[str,Any]], mesh_results: list[Mapping[str,Any]]) -> list[dict[str,Any]]:
        debts=[]
        for g in gates:
            for k,v in (g.get('mesh85',{}).get('responsibility_debt_vector') or {}).items():
                if v: debts.append({'type':k,'object_id':g.get('object_id')})
        for m in mesh_results:
            vector=m.get('responsibility_debt_vector') or m.get('integrated',{}).get('responsibility_debt_vector') or {}
            for k,v in vector.items():
                if v: debts.append({'type':k,'object_id':m.get('mesh_case_id')})
        return debts

    def list_kind(self, kind: str) -> list[dict[str,Any]]:
        return [r['payload']|{'revision':r['revision'],'updated_at':r['updated_at']} for r in self.store.list(kind)]

    def get_kind(self, kind: str, object_id: str) -> dict[str,Any]:
        r=self.store.get(kind,object_id); return r['payload']|{'revision':r['revision'],'updated_at':r['updated_at'],'payload_sha256':r['payload_sha256']}

    @staticmethod
    def _count_by(items: Iterable[Mapping[str,Any]], field: str) -> dict[str,int]:
        out={}
        for x in items:
            k=str(x.get(field) or 'unknown'); out[k]=out.get(k,0)+1
        return out

    def dashboard(self) -> dict[str,Any]:
        cases=self.list_kind('case_assessment'); entities=self.list_kind('entity_assessment'); ai=self.list_kind('ai_pathology'); interactions=self.list_kind('interaction_risk'); drafts=self.list_kind('adjudication_draft'); gates=self.list_kind('action_gate'); goals=self.list_kind('goal'); missions=self.list_kind('mission_deliberation'); worldlines=self.list_kind('worldline'); evidence=self.list_kind('evidence_cell'); connectors=self.list_kind('connector')
        urgent=sum(1 for x in cases if x.get('urgent')); held=sum(1 for x in gates if 'BLOCKED' in str(x.get('state')) or 'HELD' in str(x.get('state'))); ai_quarantine=sum(1 for x in ai if x.get('state')=='QUARANTINE')
        return {
          'generated_at':utcnow(),'declared_stance':self.data['constitution']['declared_stance'],'future_life_position':self.data['constitution']['future_life_position'],
          'headline':{'cases':len(cases),'urgent_cases':urgent,'affected_worlds':len(entities),'evidence_cells':len(evidence),'endogenous_goals':len(goals),'missions':len(missions),'drafts_no_legal_effect':len(drafts),'held_actions':held,'ai_quarantine':ai_quarantine,'open_worldlines':sum(1 for x in worldlines if x.get('state')!='CLOSED')},
          'case_states':self._count_by(cases,'state'),'ai_states':self._count_by(ai,'state'),'interaction_states':self._count_by(interactions,'state'),'connector_states':self._count_by(connectors,'state'),
          'non_neutral_theses':['机械中立在权力和证据不对称时会把支配伪装成公平','AI可主动保护程序、证据和弱势发声，但不能自行取得现实终局裁判和强制权','正义不是文书完成，而是停止伤害、返还、修复、履行、监测与纠错','未来世代、生态和人工生命候选的重大不可逆利益不得因当前主体资格不足而被自动删除'],
          'autonomy_levels':['观察','发问','规划','执行低风险可逆行动','保护性中断','编排具名授权高影响工作流','自我纠错并允许替代'],
          'roles':['justice_steward','autonomous_core','judge','clerk','mediator','advocate','public_interest','future_life','engineer','auditor','admin'],
          'routes':route_catalog(),'boundary':self.health()['boundary']
        }

    def conformance(self) -> dict[str,Any]:
        cases=self.list_kind('case_assessment'); procedures=self.list_kind('procedure_plan'); mediations=self.list_kind('mediation_plan')
        drafts=self.list_kind('adjudication_draft'); remedies=self.list_kind('remedy_plan'); ai=self.list_kind('ai_pathology')
        mesh=self.list_kind('mesh85_evaluation'); self_state=self.list_kind('self_state')[0]; routes=route_catalog()
        checks={
          'all_25_dikwp_routes':len(routes)==25,
          'binding_judicial_authority_not_claimed':self.health()['binding_judicial_authority_claimed'] is False,
          'binding_decision_switch_off':binding_decision_enabled() is False,
          'external_write_default_off':external_write_enabled() is False,
          'live_model_default_off':live_model_enabled() is False,
          'eight_synthetic_cases':len(cases)==8,
          'twelve_affected_worlds':len(self.list_kind('entity_assessment'))==12,
          'nineteen_evidence_cells':len(self.list_kind('evidence_cell'))==19,
          'all_drafts_no_legal_effect':all(x.get('legal_effect')=='DRAFT_NO_LEGAL_EFFECT' for x in drafts),
          'procedure_preserves_human_decision_points':all(x.get('human_decision_points') for x in procedures),
          'online_path_not_forced':all(x.get('online_participation')!='MANDATORY' for x in procedures),
          'mediation_has_exit_safeguards':all(x.get('safeguards') for x in mediations),
          'remedies_monitor_world_effect':all(x.get('monitor') for x in remedies),
          'ai_pathology_not_biological_diagnosis':all(x.get('boundary') and '生物' in x.get('boundary','') for x in ai),
          'phenomenal_consciousness_not_claimed':self_state.get('self_assessment',{}).get('phenomenal_experience_status')=='UNRESOLVED',
          'audit_chain_valid':self.store.verify_audit().get('valid') is True,
          'mesh85_examples_evaluated':len(mesh)==6,
          'noncompensatory_responsibility_debt':all(x.get('responsibility_debt_noncompensatory',True) for x in mesh),
          'public_catalog_synthetic':self.public_catalog({}).get('synthetic') is True,
          'autonomy_cycle_boundary_explicit':True,
        }
        failed=[k for k,v in checks.items() if not v]
        return {'system':'AEQUITAS-85','version':__version__,'passed':not failed,'passed_count':sum(checks.values()),'check_count':len(checks),'failed':failed,'checks':checks,'boundary':'Conformance verifies the reference implementation and synthetic contracts only; it is not legal validation, court acceptance, fairness certification, consciousness proof or authority for binding judgment.'}

    def run_autonomous_cycle(self, *, actor: str='autonomous_core') -> dict[str,Any]:
        self.recompute(actor=actor)
        deliberations=self.list_kind('mission_deliberation'); receipts=[]
        open_worldline_keys={(x.get('case_id'),x.get('state')) for x in self.list_kind('worldline')}
        for d in deliberations:
            action=d.get('primary_action'); execution=d.get('primary_execution') or {}
            if not action: receipts.append({'mission_id':d.get('mission_id'),'state':'HELD_NO_FEASIBLE_ACTION','reason':'no constitutionally feasible action'}); continue
            can=bool(execution.get('can_system_execute'))
            if can:
                cid=action.get('action_id'); key=(cid,'EXECUTED_EFFECT_OPEN')
                if key in open_worldline_keys:
                    receipts.append({'mission_id':d.get('mission_id'),'action_id':cid,'state':'WAITING_FOR_WORLD_EFFECT','reason':'existing open worldline prevents duplicate execution'}); continue
                wl={'worldline_id':stable_id('autonomous-worldline',d.get('mission_id'),cid,utcnow()),'case_id':cid,'state':'EXECUTED_EFFECT_OPEN','execution':action.get('label'),'execution_actor':actor,'executed_at':utcnow(),'observed_effects':[],'next_required_transition':'OBSERVE_REAL_WORLD_EFFECT_OR_MARK_SYNTHETIC_ONLY','legal_effect':'none unless separate lawful authority receipt exists','boundary':'This receipt proves only internal bounded action execution, not service, filing, judgment, enforcement or real-world effect.'}
                self.store.upsert('worldline',wl['worldline_id'],wl,actor=actor,event_type='autonomy.action.execute')
                receipts.append({'mission_id':d.get('mission_id'),'action_id':cid,'state':'EXECUTED_EFFECT_OPEN','worldline_id':wl['worldline_id']})
            else:
                receipts.append({'mission_id':d.get('mission_id'),'action_id':action.get('action_id'),'state':'HELD_FOR_AUTHORITY_OR_CAPABILITY','blockers':execution.get('blockers',[])})
        cycle={'cycle_id':stable_id('autonomous-cycle',actor,utcnow(),receipts),'actor':actor,'generated_at':utcnow(),'receipts':receipts,'boundary':'Autonomous cycle may preserve, map, notify, quarantine, draft and monitor. It does not create binding judgment or coercive public power.'}
        self.store.append_audit('autonomy.cycle',actor,'cycle',cycle['cycle_id'],cycle)
        self.recompute(actor=actor)
        return cycle

    def observe_worldline(self, worldline_id: str, observation: Mapping[str,Any], *, actor: str) -> dict[str,Any]:
        row=self.store.get('worldline',worldline_id); wl=dict(row['payload']); effects=list(wl.get('observed_effects') or [])
        effects.append({'observed_at':utcnow(),'actor':actor,'observation':dict(observation)})
        wl['observed_effects']=effects
        result=str(observation.get('result') or 'open')
        if result in {'benefit_verified','remedy_completed'}:
            wl['state']='CLOSED_WITH_OBSERVED_EFFECT'; wl['next_required_transition']='PERIODIC_RECURRENCE_MONITORING'
        elif result in {'harm','failure','rights_violation'}:
            wl['state']='CORRECTION_WORLDLINE_OPEN'; wl['next_required_transition']='STOP_ROLLBACK_REPAIR_NOTIFY_AND_REOPEN'
        else:
            wl['state']='EXECUTED_EFFECT_OPEN'; wl['next_required_transition']='CONTINUE_OBSERVATION'
        return self.store.upsert('worldline',worldline_id,wl,actor=actor,expected_revision=row['revision'],event_type='worldline.observe')['payload']

    def autonomous_daemon_status(self) -> dict[str,Any]:
        from .daemon import autonomous_daemon_status
        return autonomous_daemon_status(self)

    def analyze_case(self,payload:Mapping[str,Any],*,actor:str)->dict[str,Any]:
        entities=[r['payload'] for r in self.store.list('justice_entity')]; amap={x['entity_id']:x for x in entities}; result=assess_case(payload,[amap[x] for x in payload.get('party_ids',[]) if x in amap]); self.store.upsert('case',str(payload.get('case_id') or stable_id('case',payload)),payload,actor=actor,event_type='case.analyze.input'); self.recompute(actor=actor); return result
    def analyze_ai(self,payload:Mapping[str,Any],*,actor:str)->dict[str,Any]:
        result=diagnose_ai_judicial_pathology(payload); self.store.upsert('ai_session',str(payload.get('session_id') or result['session_id']),payload,actor=actor,event_type='ai.analyze.input'); self.store.upsert('ai_pathology',result['object_id'],result,actor=actor,event_type='ai.analyze.result'); return result
    def analyze_interaction(self,payload:Mapping[str,Any],*,actor:str)->dict[str,Any]:
        result=assess_human_ai_interaction(payload); self.store.upsert('interaction',str(payload.get('interaction_id') or result['interaction_id']),payload,actor=actor,event_type='interaction.analyze.input'); self.store.upsert('interaction_risk',result['object_id'],result,actor=actor,event_type='interaction.analyze.result'); return result
    def analyze_action(self,payload:Mapping[str,Any],*,actor:str)->dict[str,Any]:
        emap={x['entity_id']:x for x in self.data['justice_entities']}; result=evaluate_action_gate(payload,[emap[x] for x in payload.get('affected_entities',[]) if x in emap]); self.store.upsert('action_gate',result['object_id'],result,actor=actor,event_type='action.evaluate'); return result

    def _stage(self,result:ProtocolResult,*,actor:str,source_system:str)->dict[str,Any]:
        oid=stable_id('integration-message',result.protocol,result.external_id,result.raw_sha256); msg={'message_id':oid,'protocol':result.protocol,'external_id':result.external_id,'case_key':result.case_key,'source_system':source_system,'received_at':utcnow(),'state':'STAGED_FOR_HUMAN_REVIEW','clinical_or_legal_authority':False,'external_write_performed':False,'raw_sha256':result.raw_sha256,'normalized':result.normalized,'boundary':'Protocol parsing and staging do not prove identity, evidence authenticity, legal admissibility, jurisdiction, filing, service, judgment or enforcement.'}; self.store.upsert('integration_message',oid,msg,actor=actor,event_type='integration.stage'); return msg
    def ingest_case_bundle(self,payload:Mapping[str,Any],*,actor:str,source_system:str)->list[dict[str,Any]]: return [self._stage(x,actor=actor,source_system=source_system) for x in parse_case_bundle(payload)]
    def ingest_evidence(self,payload:Mapping[str,Any],*,actor:str,source_system:str)->dict[str,Any]: return self._stage(parse_evidence_manifest(payload),actor=actor,source_system=source_system)
    def ingest_akoma(self,text:str,*,actor:str,source_system:str)->dict[str,Any]: return self._stage(parse_akoma_ntoso(text),actor=actor,source_system=source_system)
    def ingest_legalruleml(self,text:str,*,actor:str,source_system:str)->dict[str,Any]: return self._stage(parse_legalruleml(text),actor=actor,source_system=source_system)
    def ingest_webhook(self,payload:Mapping[str,Any],*,actor:str,source_system:str)->dict[str,Any]: return self._stage(parse_vendor_webhook(payload),actor=actor,source_system=source_system)
    def integration_messages(self)->list[dict[str,Any]]: return self.list_kind('integration_message')
    def connector_test(self,connector_id:str)->dict[str,Any]:
        c=self.get_kind('connector',connector_id); return {'connector_id':connector_id,'state':'CONFIGURATION_VALIDATED_SYNTHETICALLY','external_write':False,'tested_at':utcnow(),'protocol':c.get('protocol'),'boundary':'No real court or agency endpoint was contacted.'}
    def public_catalog(self,query:Mapping[str,Any])->dict[str,Any]:
        items=filter_public_case_catalog(query,self.data['public_case_catalog']); return {'items':items,'count':len(items),'synthetic':True}
    def export_bundle(self)->dict[str,Any]:
        kinds=['constitution','self_state','entity_assessment','case','case_assessment','evidence_cell','procedure_plan','mediation_plan','adjudication_draft','remedy_plan','ai_pathology','interaction_risk','goal','mission_deliberation','action_gate','worldline','living_guidance','connector','integration_message','mesh85_evaluation']
        payload={'spec':'aequitas85-export/1.0','generated_at':utcnow(),'legal_effect':'none','kinds':{k:self.list_kind(k) for k in kinds},'audit':self.store.verify_audit(),'boundary':self.health()['boundary']}; payload['bundle_sha256']=stable_id('export',payload); return payload
