from __future__ import annotations
from typing import Any,Mapping
from .canonical import clamp,stable_id

def assess_justice_entity(entity:Mapping[str,Any])->dict[str,Any]:
    v=clamp(entity.get('vulnerability',.3));p=clamp(entity.get('power',.5));c=clamp(entity.get('evidence_control',.5));x=clamp(entity.get('exit_power',.5));r=clamp(entity.get('representation_access',.5));f=clamp(entity.get('future_impact',0))
    duties=[]
    if v>=.65:duties+=['强化程序便利','主动检查不利后果','提供可理解说明']
    if x<=.35:duties+=['提供线下或代理通道','禁止以默认同意推定放弃权利']
    if r<=.4:duties+=['评估法律援助或独立代理需要']
    if p>=.75 and c>=.65:duties+=['提高证据保存与披露义务','记录潜在报复或议价压迫']
    if f>=.6:duties+=['纳入未来世代或生态代表','设置长期效果复评']
    state='HEIGHTENED_PROTECTION_REQUIRED' if v>=.65 or x<=.35 or r<=.4 else 'POWER_ASYMMETRY_REVIEW' if p>=.75 and c>=.65 else 'STANDARD_PARTICIPATION'
    return {'assessment_id':stable_id('entity-assess',entity.get('entity_id'),entity),'entity_id':entity.get('entity_id'),'display_name':entity.get('display_name'),'kind':entity.get('kind'),'state':state,'vulnerability':v,'power':p,'evidence_control':c,'exit_power':x,'representation_access':r,'future_impact':f,'protective_duties':sorted(set(duties)),'boundary':'实体画像用于分配保护、披露和程序义务，不得作为人格价值、可信度或责任的替代标签。'}
