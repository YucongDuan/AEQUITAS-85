from __future__ import annotations
from typing import Any,Iterable,Mapping
from .canonical import clamp,stable_id

def build_evidence_cells(sources:Iterable[Mapping[str,Any]])->tuple[list[dict[str,Any]],list[dict[str,Any]]]:
    src=[dict(x) for x in sources];claims=[]
    for s in src:
        for i,c in enumerate(s.get('claims') or []):
            claims.append({'claim_id':str(c.get('claim_id') or stable_id('claim',s.get('source_id'),i,c)),'source_id':s.get('source_id'),'statement':c.get('statement'),'stance':c.get('stance','supports'),'issue_id':c.get('issue_id'),'case_id':c.get('case_id'),'scope':c.get('scope'),'authoritative':bool(s.get('authoritative')),'independence_group':s.get('independence_group') or s.get('source_id'),'provenance_complete':bool(s.get('provenance_complete',True)),'integrity_signal':s.get('integrity_signal','none'),'chain_of_custody':s.get('chain_of_custody','documented'),'confidentiality':s.get('confidentiality','case-limited')})
    groups={}
    for c in claims:groups.setdefault((c.get('case_id'),c.get('issue_id'),c.get('statement')),[]).append(c)
    cells=[]
    for (case_id,issue_id,statement),xs in groups.items():
        support=[x for x in xs if x['stance']=='supports'];oppose=[x for x in xs if x['stance'] in {'contradicts','limits'}];ind=len({x['independence_group'] for x in support});prov=all(x['provenance_complete'] for x in xs);tamper=any(x['integrity_signal'] not in {'none','verified'} for x in xs);custody=all(x['chain_of_custody'] in {'documented','verified'} for x in xs)
        if tamper:status='INTEGRITY_REVIEW_REQUIRED'
        elif support and oppose:status='CONTESTED'
        elif ind>=2 and prov and custody:status='INDEPENDENT_CORROBORATION'
        elif support:status='SINGLE_SOURCE_OR_DEPENDENT_SUPPORT'
        else:status='UNRESOLVED'
        vector={'provenance':1.0 if prov else .3,'integrity':.3 if tamper else .9,'independence':min(1.0,ind/2),'relevance':clamp(max((1 if x.get('issue_id') else .5) for x in xs),0,1),'completeness':min(1.0,len(xs)/3),'contestability':1.0 if oppose or len(xs)>=2 else .5,'chain_of_custody':.95 if custody else .35}
        residuals=[]
        if not prov:residuals.append({'code':'PROVENANCE_GAP','description':'来源或版本不完整'})
        if tamper:residuals.append({'code':'INTEGRITY_SIGNAL','description':'存在篡改或一致性复核信号'})
        if ind<2:residuals.append({'code':'INDEPENDENCE_GAP','description':'缺少独立来源交叉支持'})
        if not oppose:residuals.append({'code':'COUNTEREVIDENCE_GAP','description':'尚未登记反向或限制证据'})
        cells.append({'cell_id':stable_id('evidence-cell',case_id,issue_id,statement),'case_id':case_id,'issue_id':issue_id,'statement':statement,'status':status,'source_ids':[x['source_id'] for x in xs],'support_count':len(support),'contrary_count':len(oppose),'independent_support_groups':ind,'evidence_vector':vector,'residuals':residuals,'noncompensatory':True,'boundary':'证据向量不合成为真值总分；可采性、证明力与事实认定仍需适用法域规则和授权审判者判断。'})
    return claims,cells

def build_living_guidance(authorities:Iterable[Mapping[str,Any]],specs:Iterable[Mapping[str,Any]])->list[dict[str,Any]]:
    auth=[dict(x) for x in authorities];out=[]
    for spec in specs:
        refs=[x for x in auth if x.get('authority_id') in set(spec.get('authority_ids') or [])]
        out.append({'guidance_id':spec.get('guidance_id'),'title':spec.get('title'),'state':'CURRENT_PUBLIC_REFERENCE' if refs else 'SOURCE_GAP','principle':spec.get('principle'),'authority_ids':[x.get('authority_id') for x in refs],'jurisdiction':spec.get('jurisdiction'),'last_reviewed':spec.get('last_reviewed'),'reopen_triggers':spec.get('reopen_triggers') or [],'boundary':'活指引用于显示当前公开规范来源和重开条件，不替代个案适法、正式司法解释或具名法律意见。'})
    return out
