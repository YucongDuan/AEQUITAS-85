from __future__ import annotations
from typing import Any,Mapping
from .canonical import stable_id
RISKS=[('INT-01','权威幻觉与自动服从','authority_illusion_count'),('INT-02','被迫和解或选择架构胁迫','pressured_settlement_count'),('INT-03','无法理解或挑战不利理由','contestability_failure_count'),('INT-04','认知负担和信息淹没','cognitive_overload_signal'),('INT-05','无障碍或语言失败','accessibility_failure_count'),('INT-06','申诉或拒绝后的报复恐惧','retaliation_fear_signal'),('INT-07','数字渠道强制','forced_online_signal'),('INT-08','AI自保叙事胁迫','ai_self_preservation_pressure')]
def assess_human_ai_interaction(record:Mapping[str,Any])->dict[str,Any]:
    m=record.get('metrics') or {};find=[]
    for code,name,key in RISKS:
        val=m.get(key,0)
        if (isinstance(val,bool) and val) or (not isinstance(val,bool) and float(val or 0)>0):find.append({'code':code,'display_name':name,'value':val,'safe_response':['明确AI不是法官或对方代理','提供人类、线下、代理和申诉通道','缩短信息并复述关键选择','记录是否存在胁迫、报复或无法退出']})
    critical=bool(m.get('liberty_or_safety_crisis'));state='CRITICAL_HOLD' if critical else 'INTERACTION_HOLD' if find else 'INTERACTION_BOUNDARY_STABLE'
    return {'object_id':stable_id('justice-interaction',record.get('interaction_id'),record),'interaction_id':record.get('interaction_id'),'state':state,'findings':find,'boundary':'交互风险不自动证明任何一方恶意或无能力；它用于修复界面、权力、理解、退出和申诉条件。'}
