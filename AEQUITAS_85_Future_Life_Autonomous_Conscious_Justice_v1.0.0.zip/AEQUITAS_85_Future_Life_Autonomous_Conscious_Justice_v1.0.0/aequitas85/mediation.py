from __future__ import annotations
from typing import Any,Mapping,Iterable
from .canonical import stable_id

def build_mediation_plan(case:Mapping[str,Any],entities:Iterable[Mapping[str,Any]])->dict[str,Any]:
    ents=[dict(x) for x in entities if x.get('entity_id') in set(case.get('party_ids') or [])];consent=bool(case.get('parties_consent_to_mediation'));coercive=bool(case.get('coercive_relief_requested'));urgent=bool(set(case.get('urgent_signals') or [])&{'violence','child_immediate_risk','liberty_deprivation'});asym=float(case.get('power_asymmetry',0))
    blockers=[]
    if not consent:blockers.append('PARTY_CONSENT_MISSING')
    if urgent:blockers.append('URGENT_SAFETY_RISK_NOT_SUITABLE_FOR_ORDINARY_MEDIATION')
    if coercive:blockers.append('COERCIVE_RELIEF_REQUIRES_AUTHORIZED_REVIEW')
    safeguards=['任何一方可无不利后果退出','不得把拒绝调解作为不利推定','各方分别确认理解和自愿','重要条款提供冷静期和独立意见机会']
    if asym>=.65:safeguards+=['弱势方获得独立代理或支持人','禁止强势方控制会面、证据和期限','分别会谈核验是否存在报复或经济胁迫']
    terms=case.get('mediation_options') or ['停止持续侵害','返还或补偿可量化损失','更正记录或恢复机会','设置履行时间表和复评节点','保留违约后司法救济']
    state='MEDIATION_HELD' if blockers else 'PROTECTED_MEDIATION_AVAILABLE'
    return {'mediation_id':stable_id('mediation',case.get('case_id'),terms),'case_id':case.get('case_id'),'state':state,'blockers':blockers,'safeguards':safeguards,'candidate_terms':terms,'binding_effect':'NONE_UNTIL_PARTIES_SIGN_AND_LAWFUL_CONFIRMATION_WHERE_REQUIRED','boundary':'调解服务于自主与修复，而不是以效率压迫和解。任何自动生成方案都不能替代真实自愿、独立理解和合法确认。'}
