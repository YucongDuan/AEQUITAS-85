from __future__ import annotations
from typing import Any,Mapping,Iterable
from .canonical import stable_id

def plan_procedure(case:Mapping[str,Any],entity_assessments:Iterable[Mapping[str,Any]],evidence_cells:Iterable[Mapping[str,Any]])->dict[str,Any]:
    ents=[x for x in entity_assessments if x.get('entity_id') in set(case.get('party_ids') or [])];cells=[x for x in evidence_cells if x.get('case_id')==case.get('case_id')];steps=['核验管辖、主体和送达','告知AI参与、用途、局限和退出权','形成争议焦点与举证责任地图','向各方披露可依法披露的不利材料','给予答辩、质证、代理和回避机会']
    obligations=[];blockers=[]
    if any(x.get('state')=='HEIGHTENED_PROTECTION_REQUIRED' for x in ents):steps+=['提供适龄、无障碍、语言或代理便利'];obligations.append('HEIGHTENED_PARTICIPATION_SUPPORT')
    if any(x.get('status')=='INTEGRITY_REVIEW_REQUIRED' for x in cells):steps+=['对争议证据开展独立完整性复核'];blockers.append('EVIDENCE_INTEGRITY_OPEN')
    if case.get('requires_expert'):steps+=['选择无利益冲突专家并允许各方质询']
    if case.get('public_interest'):steps+=['评估公共利益、生态和未来世代代表参与']
    if case.get('hearing_required',True):steps+=['开展可记录、可回放且不强制在线的听证或庭审']
    steps+=['形成可挑战理由、少数意见和救济说明','送达决定并开放上诉、复审或申诉','监测执行和现实效果']
    if not (case.get('jurisdiction') or {}).get('basis'):blockers.append('JURISDICTION_BASIS_OPEN')
    if not case.get('party_ids'):blockers.append('PARTIES_NOT_IDENTIFIED')
    state='PROCEDURE_HELD' if blockers else 'PROCEDURE_PLAN_READY'
    return {'plan_id':stable_id('procedure',case.get('case_id'),steps),'case_id':case.get('case_id'),'state':state,'steps':steps,'obligations':obligations,'blockers':blockers,'online_mode':'OPTIONAL_NOT_MANDATORY','human_decision_points':['临时强制措施','证据排除','事实认定','法律适用','终局裁判','强制执行'],'appeal_or_review_path':True,'boundary':'程序效率不能以减少通知、代理、质证、回避、线下选择或复审权为代价。'}
