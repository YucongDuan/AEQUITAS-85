from __future__ import annotations
from dataclasses import dataclass
from typing import Any,Mapping
import xml.etree.ElementTree as ET
from .canonical import stable_id,sha256_text
class InterfaceValidationError(ValueError):pass
@dataclass
class ProtocolResult:
    protocol:str;external_id:str;case_key:str|None;normalized:dict[str,Any];raw_sha256:str

def parse_case_bundle(payload:Mapping[str,Any])->list[ProtocolResult]:
    if not isinstance(payload,Mapping):raise InterfaceValidationError('case payload must be object')
    if payload.get('resourceType')=='CaseBundle':items=payload.get('entry') or []
    else:items=[payload]
    out=[]
    for x in items:
        obj=x.get('resource') if isinstance(x,Mapping) and isinstance(x.get('resource'),Mapping) else x
        if not isinstance(obj,Mapping) or not obj.get('case_id'):raise InterfaceValidationError('case_id is required')
        cid=str(obj['case_id']);out.append(ProtocolResult('CaseBundle/1.0',cid,cid,dict(obj),sha256_text(str(obj))))
    return out
def parse_evidence_manifest(payload:Mapping[str,Any])->ProtocolResult:
    if not isinstance(payload,Mapping) or not payload.get('evidence_id') or not payload.get('case_id'):raise InterfaceValidationError('evidence_id and case_id are required')
    if not payload.get('content_sha256'):raise InterfaceValidationError('content_sha256 is required')
    return ProtocolResult('EvidenceManifest/1.0',str(payload['evidence_id']),str(payload['case_id']),dict(payload),sha256_text(str(payload)))
def _safe_xml(text:str)->ET.Element:
    if '<!DOCTYPE' in text.upper() or '<!ENTITY' in text.upper():raise InterfaceValidationError('DOCTYPE and ENTITY are prohibited')
    try:return ET.fromstring(text)
    except Exception as e:raise InterfaceValidationError('invalid XML') from e
def parse_akoma_ntoso(text:str)->ProtocolResult:
    root=_safe_xml(text)
    if not root.tag.lower().endswith('akomantoso'):raise InterfaceValidationError('Akoma Ntoso root required')
    name='document';uri=None
    for e in root.iter():
        if e.tag.lower().endswith('frbrthis'):uri=e.attrib.get('value') or uri
        if e.tag.lower().endswith('docnumber') and e.text:name=e.text.strip()
    ext=uri or stable_id('akn',name,text);return ProtocolResult('AkomaNtoso-subset',ext,None,{'document_id':ext,'document_number':name},sha256_text(text))
def parse_legalruleml(text:str)->ProtocolResult:
    root=_safe_xml(text)
    if 'legalruleml' not in root.tag.lower():raise InterfaceValidationError('LegalRuleML root required')
    key=root.attrib.get('key') or stable_id('lrml',text);return ProtocolResult('LegalRuleML-subset',key,None,{'rule_document_id':key,'element_count':sum(1 for _ in root.iter())},sha256_text(text))
def parse_vendor_webhook(payload:Mapping[str,Any])->ProtocolResult:
    if not isinstance(payload,Mapping) or not payload.get('event_id'):raise InterfaceValidationError('event_id is required')
    return ProtocolResult('VendorWebhook/1.0',str(payload['event_id']),str(payload.get('case_id')) if payload.get('case_id') else None,dict(payload),sha256_text(str(payload)))
def filter_public_case_catalog(query:Mapping[str,Any],catalog:list[Mapping[str,Any]]|None=None)->list[dict[str,Any]]:
    catalog=catalog or [{'case_id':'PUB-SYN-001','case_type':'labor','status':'published_synthetic'},{'case_id':'PUB-SYN-002','case_type':'environment','status':'published_synthetic'}];return [dict(x) for x in catalog if all(str(x.get(k,''))==str(v) for k,v in query.items() if v)]
