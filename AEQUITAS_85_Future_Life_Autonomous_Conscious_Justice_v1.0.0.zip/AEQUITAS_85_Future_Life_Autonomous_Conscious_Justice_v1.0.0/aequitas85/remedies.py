from __future__ import annotations
from typing import Any,Mapping,Iterable
from .canonical import clamp,stable_id

def plan_remedy(case:Mapping[str,Any],entities:Iterable[Mapping[str,Any]])->dict[str,Any]:
    options=[]
    for o in case.get('remedy_options') or []:
        vec=o.get('remedy_vector') or {};v={k:clamp(vec.get(k,.5)) for k in ['harm_stoppage','agency_restoration','restitution','proportionality','least_coercion','future_protection','monitorability','repairability']};veto=[]
        if o.get('collective_punishment'):veto.append('COLLECTIVE_PUNISHMENT')
        if o.get('indefinite_surveillance'):veto.append('INDEFINITE_SURVEILLANCE')
        if o.get('humiliation'):veto.append('HUMILIATING_REMEDY')
        if o.get('irreversible') and not o.get('lawful_necessity'):veto.append('IRREVERSIBLE_WITHOUT_LAWFUL_NECESSITY')
        rank=(0 if veto else 1,round(min(v['harm_stoppage'],v['proportionality'],v['repairability']),4),round(v['agency_restoration'],4),round(v['restitution'],4),round(v['least_coercion'],4),round(v['future_protection'],4),round(v['monitorability'],4),-clamp(o.get('burden',.5)))
        options.append({'option':dict(o),'vector':v,'vetoes':veto,'rank_tuple':rank})
    ranked=sorted(options,key=lambda x:x['rank_tuple'],reverse=True);primary=ranked[0] if ranked and not ranked[0]['vetoes'] else None
    return {'remedy_plan_id':stable_id('remedy',case.get('case_id'),options),'case_id':case.get('case_id'),'state':'REMEDY_PROPOSAL_READY' if primary else 'NO_PERMISSIBLE_REMEDY','primary_remedy':primary['option'] if primary else None,'primary_vector':primary['vector'] if primary else None,'alternatives':[{'remedy_id':x['option'].get('remedy_id'),'label':x['option'].get('label'),'vetoes':x['vetoes'],'rank_tuple':x['rank_tuple']} for x in ranked],'monitor':['持续侵害是否停止','返还和补偿是否到位','主体性和机会是否恢复','是否出现报复或替代性侵害','长期生态或跨代效果'],'legal_effect':'PROPOSAL_ONLY','boundary':'救济优先停止伤害、返还、恢复与防复发；处罚不能成为替代修复的仪式。强制救济仍需合法裁判和执行授权。'}
