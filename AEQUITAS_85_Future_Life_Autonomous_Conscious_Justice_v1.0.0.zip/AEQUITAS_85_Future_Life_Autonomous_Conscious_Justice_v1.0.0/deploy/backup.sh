#!/usr/bin/env bash
set -euo pipefail
mkdir -p backups
python - <<'PY2'
import os, sqlite3, datetime
src=os.getenv('AEQUITAS85_DB','var/aequitas85.db')
out='backups/aequitas85-'+datetime.datetime.utcnow().strftime('%Y%m%dT%H%M%SZ')+'.db'
a=sqlite3.connect(src); b=sqlite3.connect(out); a.backup(b); b.close(); a.close(); print(out)
PY2
