"""DIKWP-MESH 8.5 reference runtime."""
from .integrated import MODE, SYSTEM_NAME, evaluate_file, evaluate_integrated, normalize_integrated

__all__ = ["MODE", "SYSTEM_NAME", "evaluate_file", "evaluate_integrated", "normalize_integrated"]
__version__ = "8.5.0"
