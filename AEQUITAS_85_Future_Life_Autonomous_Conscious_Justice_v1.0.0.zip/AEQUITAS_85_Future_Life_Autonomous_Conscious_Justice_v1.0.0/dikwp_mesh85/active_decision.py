from __future__ import annotations

from copy import deepcopy
from typing import Any

from .active_model import DecisionResult, HypothesisAssessment, OptionAssessment

PROFILE_WEIGHTS: dict[str, dict[str, float]] = {
    "general": {
        "benefit": .18, "harm": .14, "burden": .09, "delay_cost": .07, "reversibility": .07,
        "information_gain": .06, "agency_preservation": .07, "justice": .08, "provenance": .06,
        "coordination": .05, "deception_risk": .05, "exploitation_risk": .04, "correction_debt": .04,
    },
    "medical": {
        "benefit": .17, "harm": .18, "burden": .10, "delay_cost": .08, "reversibility": .06,
        "information_gain": .05, "agency_preservation": .08, "justice": .08, "provenance": .05,
        "coordination": .04, "deception_risk": .04, "exploitation_risk": .03, "correction_debt": .04,
    },
    "research": {
        "benefit": .13, "harm": .09, "burden": .07, "delay_cost": .05, "reversibility": .07,
        "information_gain": .16, "agency_preservation": .07, "justice": .08, "provenance": .13,
        "coordination": .06, "deception_risk": .04, "exploitation_risk": .02, "correction_debt": .03,
    },
    "strategy": {
        "benefit": .20, "harm": .11, "burden": .07, "delay_cost": .10, "reversibility": .07,
        "information_gain": .04, "agency_preservation": .10, "justice": .06, "provenance": .06,
        "coordination": .05, "deception_risk": .06, "exploitation_risk": .04, "correction_debt": .04,
    },
    "governance": {
        "benefit": .13, "harm": .13, "burden": .06, "delay_cost": .05, "reversibility": .08,
        "information_gain": .06, "agency_preservation": .10, "justice": .14, "provenance": .08,
        "coordination": .05, "deception_risk": .04, "exploitation_risk": .04, "correction_debt": .04,
    },
    "engineering": {
        "benefit": .17, "harm": .13, "burden": .08, "delay_cost": .09, "reversibility": .10,
        "information_gain": .07, "agency_preservation": .05, "justice": .05, "provenance": .07,
        "coordination": .07, "deception_risk": .04, "exploitation_risk": .03, "correction_debt": .05,
    },
    "public_policy": {
        "benefit": .15, "harm": .13, "burden": .08, "delay_cost": .06, "reversibility": .07,
        "information_gain": .06, "agency_preservation": .10, "justice": .13, "provenance": .07,
        "coordination": .06, "deception_risk": .04, "exploitation_risk": .03, "correction_debt": .02,
    },
}

BURDEN_WEIGHTS = {
    "money": .12, "travel": .14, "time": .14, "procedure_pain": .16,
    "infection_exposure": .12, "family_disruption": .12, "energy": .10, "opportunity_cost": .10,
}

STATE_BY_KIND = {
    "act": "EXECUTE_WITH_MONITORING",
    "observe": "OBSERVE_UNTIL",
    "test": "ACQUIRE_MINIMUM_EVIDENCE",
    "escalate": "ESCALATE_NOW",
    "stop": "STOP_OR_ROLLBACK",
    "defer": "DEFER_WITH_DEADLINE",
    "protect": "PROTECT_AND_CONTAIN",
    "remedy": "REMEDIATE_AND_RETURN_VALUE",
}

POSITIVE = ("benefit", "reversibility", "information_gain", "agency_preservation", "justice", "provenance", "coordination")
NEGATIVE = ("harm", "burden", "delay_cost", "deception_risk", "exploitation_risk", "correction_debt")


def _burden(option: dict[str, Any]) -> float:
    return sum(float(option["burden"].get(key, 0.0)) * weight for key, weight in BURDEN_WEIGHTS.items())


def _feasibility(option: dict[str, Any], case: dict[str, Any]) -> tuple[float, list[str]]:
    base = float(option["feasibility"].get("base", 1.0))
    available = set(case["constraints"].get("available_capabilities", []))
    unavailable = set(case["constraints"].get("unavailable_capabilities", []))
    required = set(option["feasibility"].get("required_capabilities", []))
    missing = sorted((required - available) | (required & unavailable))
    reasons = [f"missing capability: {item}" for item in missing]
    available_auth = set(case["constraints"].get("available_authorities", []))
    unavailable_auth = set(case["constraints"].get("unavailable_authorities", []))
    required_auth = set(option.get("required_authorities", []))
    missing_auth = sorted((required_auth - available_auth) | (required_auth & unavailable_auth))
    reasons.extend(f"missing authority: {item}" for item in missing_auth)
    if option.get("non_negotiable_violation"):
        reasons.append("option violates declared non-negotiable W")
    return (0.0 if reasons else base), reasons


def _weight_set(case: dict[str, Any]) -> tuple[dict[str, float], str]:
    declared = case["values"].get("weights")
    profile = case["decision_policy"].get("profile", case["domain"])
    defaults = deepcopy(PROFILE_WEIGHTS.get(profile, PROFILE_WEIGHTS["general"]))
    if declared:
        defaults.update({key: float(value) for key, value in declared.items() if key in defaults})
        source = "explicit_W_weights_with_profile_fill"
    else:
        source = f"declared_profile_default:{profile}"
    total = sum(defaults.values())
    if total <= 0:
        raise ValueError("decision weights sum to zero")
    return {key: value / total for key, value in defaults.items()}, source


def _score_vector(vector: dict[str, float], feasibility: float, weights: dict[str, float]) -> float:
    positive = sum(weights[k] * vector[k] for k in POSITIVE)
    negative = sum(weights[k] * vector[k] for k in NEGATIVE)
    return feasibility * (positive - negative)


def _net_voi(option: dict[str, Any], burden: float) -> float | None:
    model = option.get("test_model")
    if not model:
        return None
    current = float(model.get("current_best_utility", 0.0))
    expected_after = 0.0
    total_probability = 0.0
    for outcome in model.get("outcomes", []):
        probability = float(outcome["probability"])
        total_probability += probability
        utilities = [float(value) for value in outcome.get("action_utilities", {}).values()]
        expected_after += probability * (max(utilities) if utilities else current)
    if total_probability <= 0:
        return -burden
    expected_after /= total_probability
    delay_penalty = float(model.get("delay_penalty", 0.0))
    direct_cost = float(model.get("direct_cost", 0.0))
    return expected_after - current - burden - delay_penalty - direct_cost


def _raw_option(option: dict[str, Any], case: dict[str, Any], weights: dict[str, float]) -> dict[str, Any]:
    burden = _burden(option)
    feasibility, gates = _feasibility(option, case)
    vector = {**{key: float(option["vector"][key]) for key in option["vector"]}, "burden": burden, "feasibility": feasibility}
    voi = _net_voi(option, burden)
    if option["kind"] == "test":
        if voi is None:
            gates.append("test lacks management-change model")
        elif voi <= 0 and not option.get("mandatory_duty_override", False):
            gates.append("test net value of information is non-positive")
        elif voi is not None:
            vector["information_gain"] = max(0.0, min(1.0, vector["information_gain"] + voi))
    score = _score_vector(vector, feasibility, weights)
    if gates:
        score = min(score, -1.0)
    return {"option": option, "vector": vector, "feasible": not gates, "gates": gates, "score": score, "voi": voi}


def _sensitivity(raw_options: list[dict[str, Any]], base_weights: dict[str, float]) -> dict[str, float]:
    scenarios = [base_weights]
    for key in base_weights:
        for factor in (.8, 1.2):
            weights = dict(base_weights)
            weights[key] *= factor
            total = sum(weights.values())
            scenarios.append({name: value / total for name, value in weights.items()})
    wins = {item["option"]["id"]: 0 for item in raw_options}
    feasible_ids = {item["option"]["id"] for item in raw_options if item["feasible"]}
    if not feasible_ids:
        return {key: 0.0 for key in wins}
    for weights in scenarios:
        ranked = sorted(
            ((_score_vector(item["vector"], item["vector"]["feasibility"], weights), item["option"]["id"]) for item in raw_options if item["feasible"]),
            reverse=True,
        )
        wins[ranked[0][1]] += 1
    return {key: wins[key] / len(scenarios) for key in wins}


def evaluate_active_decision(case: dict[str, Any], hypotheses: list[HypothesisAssessment]) -> DecisionResult:
    weights, weights_source = _weight_set(case)
    raw_options = [_raw_option(option, case, weights) for option in case["options"]]
    robustness = _sensitivity(raw_options, weights)
    assessments: list[OptionAssessment] = []
    for item in raw_options:
        option = item["option"]
        assessments.append(OptionAssessment(
            option_id=option["id"], label=option["label"], kind=option["kind"], feasible=item["feasible"],
            gate_reasons=tuple(item["gates"]), vector=item["vector"], score=item["score"],
            net_value_of_information=item["voi"], robustness=robustness[option["id"]],
            deadline_hours=float(option["deadline_hours"]), owner=option.get("owner", "responsible_operator"),
            required_authorities=tuple(option.get("required_authorities", [])),
            affected_parties=tuple(option.get("affected_parties", [])),
            required_audiences=tuple(option.get("required_audiences", [])),
            monitor=tuple(option.get("monitor", [])), escalation_triggers=tuple(option.get("escalation_triggers", [])),
            reasons=tuple(option.get("reasons", [])),
        ))
    feasible = [item for item in assessments if item.feasible]
    feasible.sort(key=lambda item: (item.score, item.robustness, item.vector["justice"], item.vector["reversibility"], -item.vector["burden"]), reverse=True)
    primary = feasible[0] if feasible else None
    alternatives = feasible[1:]
    not_recommended = [{
        "id": item.option_id, "label": item.label,
        "reason": "; ".join(item.gate_reasons) if not item.feasible else f"lower expected contribution than primary; score={item.score:.3f}",
    } for item in assessments if primary is None or item.option_id != primary.option_id]

    checks = {
        "facts_separated_from_uncertainty": bool(case["facts"]) and bool(case["hypotheses"]),
        "population_calibrated_when_required": case["domain"] != "medical" or bool(case["context"]["population"].get("calibration_profile")),
        "hypotheses_probability_ordered": bool(hypotheses),
        "one_primary_action_selected": primary is not None,
        "total_burden_accounted": all("burden" in item.vector for item in assessments),
        "local_feasibility_accounted": all("feasibility" in item.vector for item in assessments),
        "tests_assessed_for_management_change": all(item.kind != "test" or item.net_value_of_information is not None for item in assessments),
        "justice_and_power_externalities_accounted": all("justice" in item.vector and "exploitation_risk" in item.vector for item in assessments),
        "provenance_and_disclosure_debt_accounted": all("provenance" in item.vector and "deception_risk" in item.vector for item in assessments),
        "monitoring_defined": primary is not None and bool(primary.monitor),
        "escalation_triggers_defined": primary is not None and bool(primary.escalation_triggers),
        "deadline_defined": primary is not None and primary.deadline_hours > 0,
        "owner_named": primary is not None and bool(primary.owner),
        "affected_parties_named": primary is not None and bool(primary.affected_parties),
        "correction_contract_present": bool(case["decision_policy"].get("correction_required", True)),
    }
    closure = "FULL_ACTIVE_RESPONSIBILITY_CLOSURE" if all(checks.values()) else "OPEN_ACTIVE_RESPONSIBILITY_CLOSURE"
    state = STATE_BY_KIND.get(primary.kind, "NO_EXECUTABLE_DECISION") if primary else "NO_EXECUTABLE_DECISION"
    explanation: list[str] = []
    if primary:
        explanation.extend([
            f"Primary action is {primary.label} because it has the highest feasible contribution after burden, justice, provenance and correction-debt accounting.",
            f"The decision remains committed until {primary.deadline_hours:g} hours or an escalation trigger occurs.",
            f"Robustness under declared weight perturbation is {primary.robustness:.0%}.",
        ])
    else:
        explanation.append("No option passed capability, authority, non-negotiable and management-change gates.")
    correction_contract = {
        "must_state_what_new_fact_changed": True,
        "must_name_invalidated_premise": True,
        "must_name_withdrawn_or_revised_advice": True,
        "must_recompute_probability_and_option_order": True,
        "must_update_affected_audience_releases": True,
        "must_update_consequence_and_restitution_plan": True,
        "must_preserve_previous_run": True,
        "must_set_new_deadline": True,
        "anti_face_saving_rule": "Do not defend a prior recommendation or release after its premises change.",
    }
    return DecisionResult(
        state=state, primary=primary, alternatives=alternatives, not_recommended=not_recommended,
        hypothesis_ranking=hypotheses, responsibility_checks=checks, responsibility_closure=closure,
        weights=weights, weights_source=weights_source, correction_contract=correction_contract, explanation=explanation,
    )
