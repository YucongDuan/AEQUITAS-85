from __future__ import annotations

from typing import Any

from .canonical import alias_digest, core_digest
from .errors import SpecError
from .model import AliasBinding, AliasOverlay, CoreArtifact


def normalize_alias_overlay(
    raw: Any,
    artifact: CoreArtifact,
    *,
    source_name: str = "",
) -> AliasOverlay:
    if raw is None:
        return AliasOverlay(version="8.5", bindings=[], source_name=source_name)
    if not isinstance(raw, dict):
        raise SpecError("alias overlay must be a JSON object")
    extra = set(raw) - {"mesh_version", "bindings"}
    if extra:
        raise SpecError(f"alias overlay contains non-protocol fields: {sorted(extra)}")
    if str(raw.get("mesh_version", "")) not in {"8.5", "8.5.0", "8.25", "8.25.0"}:
        raise SpecError("alias overlay mesh_version must be 8.5 or migratable 8.25")
    bindings_raw = raw.get("bindings")
    if not isinstance(bindings_raw, list):
        raise SpecError("alias overlay bindings must be a list")
    bindings: list[AliasBinding] = []
    seen: set[tuple[str, str]] = set()
    for index, item in enumerate(bindings_raw):
        path = f"bindings[{index}]"
        if not isinstance(item, dict):
            raise SpecError(f"{path} must be an object")
        extra_binding = set(item) - {"alias", "targets", "language"}
        if extra_binding:
            raise SpecError(f"{path} contains non-protocol fields: {sorted(extra_binding)}")
        alias = item.get("alias")
        if not isinstance(alias, str) or not alias.strip():
            raise SpecError(f"{path}.alias must be a non-empty string")
        language = item.get("language", "")
        if not isinstance(language, str):
            raise SpecError(f"{path}.language must be a string")
        targets = item.get("targets")
        if not isinstance(targets, list) or not targets:
            raise SpecError(f"{path}.targets must be a non-empty list")
        if not all(isinstance(value, str) and value for value in targets):
            raise SpecError(f"{path}.targets must contain non-empty record ids")
        target_tuple = tuple(targets)
        if len(target_tuple) != len(set(target_tuple)):
            raise SpecError(f"{path}.targets cannot contain duplicates")
        missing = [target for target in target_tuple if target not in artifact.records]
        if missing:
            raise SpecError(f"{path} targets absent records: {missing}")
        key = (language, alias.strip())
        if key in seen:
            raise SpecError(
                f"duplicate alias in the same language carrier: {language!r} {alias!r}"
            )
        seen.add(key)
        bindings.append(
            AliasBinding(alias=alias.strip(), targets=target_tuple, language=language)
        )
    return AliasOverlay(version="8.5", bindings=bindings, source_name=source_name)


def alias_roundtrips(
    artifact: CoreArtifact, overlay: AliasOverlay
) -> list[dict[str, Any]]:
    by_targets: dict[tuple[str, ...], list[AliasBinding]] = {}
    for binding in overlay.bindings:
        by_targets.setdefault(binding.targets, []).append(binding)
    results: list[dict[str, Any]] = []
    for binding in sorted(
        overlay.bindings, key=lambda item: (item.language, item.alias, item.targets)
    ):
        reverse = sorted(
            (
                {"alias": item.alias, "language": item.language}
                for item in by_targets[binding.targets]
            ),
            key=lambda item: (item["language"], item["alias"]),
        )
        results.append(
            {
                "alias": binding.alias,
                "language": binding.language,
                "targets": list(binding.targets),
                "alias_recovered": any(
                    item["alias"] == binding.alias
                    and item["language"] == binding.language
                    for item in reverse
                ),
                "all_aliases_for_targets": reverse,
                "core_digest_unchanged": core_digest(artifact),
            }
        )
    return results


def overlay_summary(artifact: CoreArtifact, overlay: AliasOverlay) -> dict[str, Any]:
    roundtrips = alias_roundtrips(artifact, overlay)
    return {
        "binding_count": len(overlay.bindings),
        "alias_digest": alias_digest(overlay),
        "core_digest": core_digest(artifact),
        "automatic_alias_generation": False,
        "roundtrips": roundtrips,
        "all_roundtrips_valid": all(item["alias_recovered"] for item in roundtrips),
    }
