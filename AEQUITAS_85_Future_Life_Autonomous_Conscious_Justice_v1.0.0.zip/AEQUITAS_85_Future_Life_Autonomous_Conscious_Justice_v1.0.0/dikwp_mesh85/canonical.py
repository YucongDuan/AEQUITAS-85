from __future__ import annotations

import hashlib
import json
from typing import Any

from .model import AliasOverlay, CoreArtifact, SemanticRecord


def _record_object(record: SemanticRecord) -> dict[str, Any]:
    base: dict[str, Any] = {
        "id": record.record_id,
        "kind": record.kind,
        "given": record.given,
    }
    if record.kind == "P":
        base["input"] = {
            "refs": list(record.input_endpoint.refs),
            "payload_hex": record.input_endpoint.payload.hex(),
        }
        base["output"] = {
            "refs": list(record.output_endpoint.refs),
            "payload_hex": record.output_endpoint.payload.hex(),
        }
    else:
        base["refs"] = list(record.refs)
        base["payload_hex"] = record.payload.hex()
    return base


def canonical_core_object(artifact: CoreArtifact) -> dict[str, Any]:
    return {
        "mesh_version": "8.5",
        "semantic_authority": ["D", "I", "K", "W", "P"],
        "records": [
            _record_object(artifact.records[record_id])
            for record_id in sorted(artifact.records)
        ],
        "routes": [
            {"source": route.source, "target": route.target}
            for route in sorted(artifact.routes)
        ],
    }


def canonical_alias_object(overlay: AliasOverlay) -> dict[str, Any]:
    return {
        "mesh_version": "8.5",
        "bindings": [
            {
                "alias": binding.alias,
                "language": binding.language,
                "targets": list(binding.targets),
            }
            for binding in sorted(
                overlay.bindings,
                key=lambda item: (item.language, item.alias, item.targets),
            )
        ],
    }


def canonical_bytes(value: Any) -> bytes:
    return json.dumps(
        value,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")


def sha256(value: Any) -> str:
    return hashlib.sha256(canonical_bytes(value)).hexdigest()


def core_digest(artifact: CoreArtifact) -> str:
    return sha256(canonical_core_object(artifact))


def alias_digest(overlay: AliasOverlay) -> str:
    return sha256(canonical_alias_object(overlay))
