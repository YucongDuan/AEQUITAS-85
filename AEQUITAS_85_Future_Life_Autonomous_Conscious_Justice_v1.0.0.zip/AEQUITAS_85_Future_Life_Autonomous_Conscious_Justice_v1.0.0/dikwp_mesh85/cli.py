from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path

from . import __version__
from .dashboard import render_result_dashboard
from .integrated import MODE, SYSTEM_NAME, evaluate_integrated


def _load(path: str | Path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def _write(value, path: str | Path):
    output = Path(path)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return output


def examples_dir() -> Path:
    env = os.environ.get("MESH85_ROOT")
    if env:
        return Path(env) / "examples"
    here = Path(__file__).resolve()
    for parent in here.parents:
        candidate = parent / "examples"
        if candidate.exists():
            return candidate
    packaged = here.parent / "resources" / "examples"
    if packaged.exists():
        return packaged
    return Path.cwd() / "examples"


def command_summary(_args):
    print(json.dumps({
        "system": SYSTEM_NAME,
        "version": __version__,
        "mode": MODE,
        "semantic_authority": ["D", "I", "K", "W", "P"],
        "non_core_semantic_authority": 0,
    }, ensure_ascii=False, indent=2))
    return 0


def command_run(args):
    source = _load(args.input)
    result = evaluate_integrated(source, source_name=str(args.input))
    wrapper = {"mesh85_run": result, "source_carrier": source}
    if args.out:
        _write(wrapper, args.out)
    else:
        print(json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True))
    if args.dashboard:
        Path(args.dashboard).write_text(render_result_dashboard(result, private=not args.public), encoding="utf-8")
    return 0


def command_replay(args):
    wrapper = _load(args.run_file)
    source = wrapper.get("source_carrier")
    previous = wrapper.get("mesh85_run", {})
    if not source:
        raise SystemExit("run file lacks source_carrier")
    replay = evaluate_integrated(source, source_name=str(args.run_file) + "#replay")
    payload = {
        "valid": replay.get("run_digest") == previous.get("run_digest"),
        "previous_digest": previous.get("run_digest"),
        "replay_digest": replay.get("run_digest"),
        "state": replay.get("system_state"),
    }
    print(json.dumps(payload, ensure_ascii=False, indent=2))
    return 0 if payload["valid"] else 2


EXPECTED = {
    "full_worldline_closed.mesh85.json": "FULL_MESH85_WORLDLINE_RESPONSIBILITY_CLOSURE",
    "planned_pilot.mesh85.json": "PARTIAL_MESH85_CLOSURE",
    "executed_effect_open.mesh85.json": "EXECUTED_EFFECT_OPEN",
    "private_intent_leak.mesh85.json": "TRUTH_OR_DISCLOSURE_GATE_BLOCKED",
    "formal_neutrality_capture.mesh85.json": "FORMALLY_CLOSED_BUT_SUBSTANTIVELY_UNPROTECTED",
    "authority_open.mesh85.json": "AUTHORITY_CHAIN_OPEN",
}


def run_conformance():
    folder = examples_dir() / "private"
    checks = []
    for name, expected in EXPECTED.items():
        result = evaluate_integrated(_load(folder / name), source_name=str(folder / name))
        actual = result["system_state"]
        checks.append({"name": name, "expected": expected, "actual": actual, "passed": actual == expected})
    full = evaluate_integrated(_load(folder / "full_worldline_closed.mesh85.json"))
    checks += [
        {"name": "core_semantic_authority_only", "passed": full["semantic_authority"] == ["D", "I", "K", "W", "P"] and full["non_core_semantic_authority"] == 0},
        {"name": "recommendation_not_authorization", "passed": full["constitutional_boundaries"]["recommendation_is_not_authorization"]},
        {"name": "no_automatic_external_punishment", "passed": full["coupled_checks"]["no_automatic_external_punishment"]},
        {"name": "public_release_truth_preserving", "passed": full["releases"]["public"]["status"] == "PASS"},
        {"name": "affected_party_release_present", "passed": "affected_party" in full["releases"]},
        {"name": "world_effect_closed_only_with_outcomes", "passed": full["worldline"]["state"] == "FULL_WORLD_EFFECT_AND_CORRECTION_CLOSURE"},
        {"name": "responsibility_debt_vector_noncompensatory", "passed": full.get("responsibility_debt_noncompensatory") is True and all(value is False for value in full.get("responsibility_debt_vector", {}).values())},
        {"name": "next_required_transition_declared", "passed": full.get("next_required_transition") == "PRESERVE_AND_MONITOR_CLOSED_WORLDLINE"},
    ]
    return {
        "system": SYSTEM_NAME,
        "version": __version__,
        "passed": all(x["passed"] for x in checks),
        "passed_count": sum(bool(x["passed"]) for x in checks),
        "total": len(checks),
        "checks": checks,
    }


def command_conformance(args):
    result = run_conformance()
    if args.out:
        _write(result, args.out)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result["passed"] else 1


def command_demo(args):
    path = examples_dir() / "private" / args.name
    result = evaluate_integrated(_load(path), source_name=str(path))
    outdir = Path(args.output_dir)
    outdir.mkdir(parents=True, exist_ok=True)
    _write(result, outdir / "result.json")
    (outdir / "dashboard.html").write_text(render_result_dashboard(result, private=True), encoding="utf-8")
    print(outdir)
    return 0


def command_serve(args):
    from .server import serve
    serve(args.host, args.port)
    return 0


def build_parser():
    p = argparse.ArgumentParser(prog="mesh85", description=SYSTEM_NAME)
    p.add_argument("--version", action="version", version=__version__)
    s = p.add_subparsers(dest="cmd", required=True)
    q = s.add_parser("summary"); q.set_defaults(func=command_summary)
    q = s.add_parser("run"); q.add_argument("input"); q.add_argument("--out"); q.add_argument("--dashboard"); q.add_argument("--public", action="store_true"); q.set_defaults(func=command_run)
    q = s.add_parser("replay"); q.add_argument("run_file"); q.set_defaults(func=command_replay)
    q = s.add_parser("conformance"); q.add_argument("--out"); q.set_defaults(func=command_conformance)
    q = s.add_parser("demo"); q.add_argument("--name", default="full_worldline_closed.mesh85.json", choices=sorted(EXPECTED)); q.add_argument("--output-dir", default="outputs/demo"); q.set_defaults(func=command_demo)
    q = s.add_parser("serve"); q.add_argument("--host", default="127.0.0.1"); q.add_argument("--port", type=int, default=8585); q.set_defaults(func=command_serve)
    return p


def main(argv=None):
    parser = build_parser()
    args = parser.parse_args(argv)
    try:
        return int(args.func(args))
    except (ValueError, KeyError, TypeError) as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2
