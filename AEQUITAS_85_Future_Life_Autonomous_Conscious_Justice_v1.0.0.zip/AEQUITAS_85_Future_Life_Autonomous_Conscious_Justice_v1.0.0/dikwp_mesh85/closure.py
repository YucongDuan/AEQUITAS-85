from __future__ import annotations

from copy import deepcopy
from typing import Iterable

from .canonical import core_digest
from .graph import adjacency, reachable, reverse_adjacency
from .model import (
    CORE_KINDS,
    ClosureCandidate,
    CoreArtifact,
    Finding,
    SemanticRecord,
)

PROFILES: tuple[str, ...] = ("forward", "bidirectional")


def _unique_findings(findings: Iterable[Finding]) -> list[Finding]:
    seen: set[tuple[str, str, str, str]] = set()
    result: list[Finding] = []
    for finding in findings:
        key = (finding.code, finding.message, finding.record_id, finding.level)
        if key not in seen:
            seen.add(key)
            result.append(finding)
    return result


def validate_structure(artifact: CoreArtifact) -> list[Finding]:
    findings: list[Finding] = []
    records = artifact.records
    for kind in CORE_KINDS:
        if not artifact.by_kind(kind):
            findings.append(
                Finding(
                    f"{kind}_ABSENT",
                    f"no {kind} semantic record is present",
                    level="open",
                )
            )
    for record in records.values():
        for ref in record.all_refs():
            if ref not in records:
                findings.append(
                    Finding(
                        "MISSING_REFERENCE",
                        f"record references absent id {ref}",
                        record.record_id,
                        level="invalid",
                    )
                )
            elif not records[ref].given:
                findings.append(
                    Finding(
                        "REFERENCE_TO_OPEN_RECORD",
                        f"record references {ref}, whose core position is not given",
                        record.record_id,
                    )
                )
    graph_in = reverse_adjacency(artifact)
    all_p_inputs = {
        ref
        for record in artifact.by_kind("P", given_only=True)
        for ref in record.input_endpoint.refs
    }
    for record in records.values():
        if (
            record.given
            and record.kind in {"D", "I", "K"}
            and not graph_in.get(record.record_id)
            and record.record_id not in all_p_inputs
        ):
            findings.append(
                Finding(
                    "UNDECLARED_ROOT",
                    "a source-less D/I/K record is not exposed as a P input",
                    record.record_id,
                )
            )
    return _unique_findings(findings)


def _covered(final_k: SemanticRecord, record_id: str) -> bool:
    return record_id == final_k.record_id or record_id in final_k.refs


def _all_records_covered(artifact: CoreArtifact, final_k: SemanticRecord) -> tuple[bool, list[str]]:
    missing = [
        record_id
        for record_id in sorted(artifact.records)
        if record_id != final_k.record_id and record_id not in final_k.refs
    ]
    return not missing, missing


def _p_connectivity_findings(
    artifact: CoreArtifact,
    record: SemanticRecord,
    *,
    role: str,
) -> list[Finding]:
    graph = adjacency(artifact)
    findings: list[Finding] = []
    for ref in record.input_endpoint.refs:
        if ref not in artifact.records:
            findings.append(
                Finding("MISSING_REFERENCE", f"{role} P input {ref} is absent", record.record_id, "invalid")
            )
        elif not artifact.records[ref].given:
            findings.append(
                Finding("P_INPUT_NOT_GIVEN", f"{role} P input {ref} is open", record.record_id)
            )
        elif not reachable(graph, ref, record.record_id):
            findings.append(
                Finding(
                    "P_INPUT_PATH_OPEN",
                    f"no explicit route path carries {ref} into {role} P",
                    record.record_id,
                )
            )
    for ref in record.output_endpoint.refs:
        if ref not in artifact.records:
            findings.append(
                Finding("MISSING_REFERENCE", f"{role} P output {ref} is absent", record.record_id, "invalid")
            )
        elif not artifact.records[ref].given:
            findings.append(
                Finding("P_OUTPUT_NOT_GIVEN", f"{role} P output {ref} is open", record.record_id)
            )
        elif not reachable(graph, record.record_id, ref):
            findings.append(
                Finding(
                    "P_OUTPUT_INJECTED",
                    f"{role} P declares output {ref} without an explicit route path from P",
                    record.record_id,
                )
            )
    if not record.input_endpoint.refs:
        findings.append(
            Finding(
                "P_INPUT_REFERENCE_OPEN",
                f"{role} P has no input record references; payload may be present but core linkage remains open",
                record.record_id,
            )
        )
    if not record.output_endpoint.refs:
        findings.append(
            Finding(
                "P_OUTPUT_REFERENCE_OPEN",
                f"{role} P has no output record references; payload may be present but core linkage remains open",
                record.record_id,
            )
        )
    return findings


def _d_same(
    artifact: CoreArtifact,
    original_id: str,
    regenerated_ids: tuple[str, ...],
) -> bool:
    if original_id in regenerated_ids:
        return True
    for record in artifact.by_kind("D", given_only=True):
        if original_id in record.refs and any(value in record.refs for value in regenerated_ids):
            return True
    return False


def _candidate(
    artifact: CoreArtifact,
    profile: str,
    forward: SemanticRecord,
    final_k: SemanticRecord,
    reverse: SemanticRecord | None,
    global_findings: list[Finding],
) -> ClosureCandidate:
    vector = {kind: 1 for kind in CORE_KINDS}
    findings: list[Finding] = list(global_findings)

    # Any absent or open record keeps its corresponding position open.
    for kind in CORE_KINDS:
        kind_records = artifact.by_kind(kind)
        if not kind_records:
            vector[kind] = 0
        for record in kind_records:
            if not record.given:
                vector[kind] = 0
                findings.append(
                    Finding(
                        f"{kind}_NOT_GIVEN",
                        f"{kind} record is explicitly not given",
                        record.record_id,
                    )
                )

    forward_findings = _p_connectivity_findings(artifact, forward, role="forward")
    findings.extend(forward_findings)
    if forward_findings:
        vector["P"] = 0

    if final_k.record_id not in forward.output_endpoint.refs:
        vector["K"] = 0
        vector["P"] = 0
        findings.append(
            Finding(
                "K_NOT_FORWARD_OUTPUT",
                "selected K is not an explicit output of the selected forward P",
                final_k.record_id,
            )
        )

    covered, missing_coverage = _all_records_covered(artifact, final_k)
    if not covered:
        vector["K"] = 0
        findings.append(
            Finding(
                "K_COVERAGE_OPEN",
                "final K does not directly retain: " + ", ".join(missing_coverage),
                final_k.record_id,
            )
        )

    # D, I, and W must remain visible in final K.
    for kind in ("D", "I", "W"):
        missing = [
            record.record_id
            for record in artifact.by_kind(kind)
            if not _covered(final_k, record.record_id)
        ]
        if missing:
            vector[kind] = 0
            findings.append(
                Finding(
                    f"{kind}_NOT_RETAINED_BY_K",
                    f"final K does not retain {kind}: " + ", ".join(missing),
                    final_k.record_id,
                )
            )

    # W has operational visibility only when it participates in the forward P.
    graph = adjacency(artifact)
    visible_w = [
        record.record_id
        for record in artifact.by_kind("W", given_only=True)
        if record.record_id in forward.input_endpoint.refs
        or reachable(graph, record.record_id, forward.record_id)
    ]
    if not visible_w:
        vector["W"] = 0
        findings.append(
            Finding(
                "W_NOT_VISIBLE_TO_P",
                "no given W reaches or enters the selected forward P",
                forward.record_id,
            )
        )

    if any(finding.code == "UNDECLARED_ROOT" for finding in findings):
        vector["K"] = 0
        vector["P"] = 0
    if any(finding.level == "invalid" for finding in findings):
        vector["K"] = 0
        vector["P"] = 0

    if profile == "bidirectional":
        if reverse is None:
            vector["D"] = 0
            vector["P"] = 0
            findings.append(
                Finding(
                    "REVERSE_P_ABSENT",
                    "no reverse P was selected for bidirectional regeneration",
                    forward.record_id,
                )
            )
        else:
            reverse_findings = _p_connectivity_findings(artifact, reverse, role="reverse")
            findings.extend(reverse_findings)
            if reverse_findings:
                vector["P"] = 0
            if final_k.record_id not in reverse.input_endpoint.refs:
                vector["P"] = 0
                findings.append(
                    Finding(
                        "REVERSE_P_MISSING_K_INPUT",
                        "reverse P does not take final K as an explicit input",
                        reverse.record_id,
                    )
                )
            for original in forward.input_endpoint.refs:
                if not _d_same(artifact, original, reverse.output_endpoint.refs):
                    vector["D"] = 0
                    vector["P"] = 0
                    findings.append(
                        Finding(
                            "D_REGENERATION_OPEN",
                            f"reverse P output is not explicitly D-same with forward input {original}",
                            reverse.record_id,
                        )
                    )

    # K cannot be complete while any core position is open.
    if any(not record.given for record in artifact.records.values()):
        vector["K"] = 0

    return ClosureCandidate(
        vector=vector,
        findings=_unique_findings(findings),
        forward_p=forward.record_id,
        final_k=final_k.record_id,
        reverse_p=reverse.record_id if reverse else "",
    )


def evaluate_closure(artifact: CoreArtifact, *, profile: str = "bidirectional") -> dict[str, object]:
    if profile not in PROFILES:
        raise ValueError(f"profile must be one of {list(PROFILES)}")

    global_findings = validate_structure(artifact)
    forward_candidates = artifact.by_kind("P", given_only=True)
    candidates: list[ClosureCandidate] = []

    for forward in forward_candidates:
        final_k_records = [
            artifact.records[record_id]
            for record_id in forward.output_endpoint.refs
            if record_id in artifact.records
            and artifact.records[record_id].kind == "K"
            and artifact.records[record_id].given
        ]
        for final_k in final_k_records:
            if profile == "forward":
                candidates.append(
                    _candidate(
                        artifact,
                        profile,
                        forward,
                        final_k,
                        None,
                        global_findings,
                    )
                )
                continue
            reverse_options = [
                record
                for record in artifact.by_kind("P", given_only=True)
                if record.record_id != forward.record_id
                and final_k.record_id in record.input_endpoint.refs
            ]
            if not reverse_options:
                candidates.append(
                    _candidate(
                        artifact,
                        profile,
                        forward,
                        final_k,
                        None,
                        global_findings,
                    )
                )
            else:
                for reverse in reverse_options:
                    candidates.append(
                        _candidate(
                            artifact,
                            profile,
                            forward,
                            final_k,
                            reverse,
                            global_findings,
                        )
                    )

    if not candidates:
        vector = {kind: 0 for kind in CORE_KINDS}
        findings = list(global_findings)
        findings.append(
            Finding(
                "FORWARD_P_TO_K_ABSENT",
                "no given P explicitly outputs a given K",
            )
        )
        candidates.append(
            ClosureCandidate(vector=vector, findings=_unique_findings(findings))
        )

    candidates.sort(
        key=lambda candidate: (
            -candidate.score,
            tuple(-candidate.vector[kind] for kind in CORE_KINDS),
            candidate.forward_p,
            candidate.final_k,
            candidate.reverse_p,
        )
    )
    best = candidates[0]
    route_codes = sorted({artifact.route_code(route) for route in artifact.routes})
    return {
        "profile": profile,
        "core_digest": core_digest(artifact),
        "record_count": len(artifact.records),
        "route_count": len(artifact.routes),
        "route_code_count": len(route_codes),
        "route_codes_present": route_codes,
        "best": best.to_dict(),
        "candidates": [candidate.to_dict() for candidate in candidates],
        "structure_findings": [finding.to_dict() for finding in global_findings],
    }
