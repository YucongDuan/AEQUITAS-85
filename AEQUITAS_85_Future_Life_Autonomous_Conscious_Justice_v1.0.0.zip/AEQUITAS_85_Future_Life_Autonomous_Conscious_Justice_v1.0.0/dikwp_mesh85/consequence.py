from __future__ import annotations

from typing import Any

_E = {"S0":0,"S1":1,"S2":2,"S3":3,"S4":4}
_SEV = {"low":0,"moderate":1,"high":2,"critical":3}


def classify_bad_faith(case: dict[str, Any]) -> dict[str, Any]:
    signals = []
    for key in ("concealment_signal", "spoliation_signal", "promise_breach", "source_erasure", "nonpayment", "retaliation_risk"):
        if case.get(key): signals.append(key)
    repeated = int(case.get("recurrence",0)) >= 2
    if repeated: signals.append("repeated_harm")
    evidence = _E.get(case.get("evidence_level","S0"),0)
    intent = case.get("intent_state","unknown")
    pattern = evidence >= 3 and (len(signals) >= 2 or intent in {"reckless","deliberate"})
    return {
        "bad_faith_pattern": pattern,
        "signals": signals,
        "identity_boundary": "This classifies evidenced conduct and pattern, not permanent human essence.",
    }


def consequence_plan(case: dict[str, Any], safeguards: dict[str, bool], policy: dict[str, Any]) -> dict[str, Any]:
    evidence = _E.get(case.get("evidence_level","S0"),0)
    severity = _SEV.get(case.get("harm_severity","low"),0)
    ongoing = case.get("harm_state") in {"ongoing","imminent"}
    recurrence = int(case.get("recurrence",0))
    intent = case.get("intent_state","unknown")
    bad = classify_bad_faith(case)
    immediate: list[str] = ["PRESERVE_EVIDENCE"]
    remedy: list[str] = []
    sanction: list[str] = []
    reentry: list[str] = []
    level = "C0_EVIDENCE_PRESERVATION"

    if ongoing or case.get("retaliation_risk") or case.get("ongoing_access"):
        immediate += ["PROTECTIVE_HOLD", "LIMIT_FURTHER_ACCESS_OR_DISCLOSURE"]
        level = "C1_PROTECTIVE_CONTAINMENT"
    if evidence >= 1:
        immediate += ["NOTICE_AND_CURE_WINDOW"]
        level = max(level, "C2_NOTICE_AND_CURE")
    if evidence >= 2 and (case.get("benefit_flow") or case.get("nonpayment") or case.get("source_erasure")):
        remedy += ["RESTITUTION", "ATTRIBUTION_CORRECTION", "VALUE_RETURN_ACCOUNTING"]
        level = "C3_RESTITUTION_AND_CORRECTION"
    if evidence >= 3 and (recurrence >= 2 or intent in {"reckless","deliberate"} or bad["bad_faith_pattern"]):
        sanction += ["SUSPEND_PRIVILEGED_ACCESS", "RESTRICT_ELIGIBILITY", "INDEPENDENT_AUDIT"]
        level = "C4_PRIVILEGE_RESTRICTION"
    if evidence >= 4 or (evidence >= 3 and severity >= 2 and (case.get("retaliation_risk") or case.get("spoliation_signal") or intent == "deliberate")):
        sanction += ["TERMINATE_OR_REFUSE_RENEWAL", "FORMAL_REFERRAL_TO_AUTHORIZED_BODY", "OFFICIAL_RECORD_CORRECTION"]
        level = "C5_TERMINATION_AND_REFERRAL"
    if remedy or sanction:
        reentry = ["CURE_VERIFIED", "RESTITUTION_COMPLETED", "NON_RETALIATION_COMMITMENT", "MONITORING_PERIOD"]

    # Punitive external execution is never automatic.
    punitive_ready = evidence >= 3 and bool(sanction) and safeguards.get("independent_review", False)
    return {
        "recommended_level": level,
        "immediate_protection": list(dict.fromkeys(immediate)),
        "remedy": list(dict.fromkeys(remedy)),
        "sanction": list(dict.fromkeys(sanction)),
        "conditional_reentry": reentry,
        "punitive_consequence_ready": punitive_ready,
        "bad_faith": bad,
        "automatic_external_enforcement": False,
        "execution_boundary": "Decision support only. Real sanctions require an authorized human or institution and applicable law/contract.",
        "policy_notes": policy,
    }
