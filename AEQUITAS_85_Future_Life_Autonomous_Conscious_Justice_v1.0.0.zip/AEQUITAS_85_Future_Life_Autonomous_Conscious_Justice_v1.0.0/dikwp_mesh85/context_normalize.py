from __future__ import annotations

import re
from typing import Any

from .context_model import (
    CLAIM_KINDS, CONTEXT_PROFILES, DISCLOSURE_ZONES, MATERIALITY_LEVELS, TIMING_PHASES,
    ContextPacket,
)
from .errors import SpecError

_ID_RE = re.compile(r"^[A-Za-z0-9_.:-]{1,128}$")
_ALLOWED_TOP = {
    "mesh_version", "packet_id", "title", "phase", "facts", "objectives", "claims",
    "required_disclosures", "prohibited_claims", "lexicon",
}


def _id(value: Any, path: str) -> str:
    if not isinstance(value, str) or not _ID_RE.fullmatch(value):
        raise SpecError(f"{path} must be a stable id")
    return value


def _audiences(raw: Any, path: str) -> tuple[str, ...]:
    if raw is None:
        return ()
    if not isinstance(raw, (list, tuple)) or any(v not in CONTEXT_PROFILES for v in raw):
        raise SpecError(f"{path} contains unsupported audience")
    return tuple(dict.fromkeys(raw))


def normalize_context(raw: Any, *, source_name: str = "") -> ContextPacket:
    if raw is None:
        return ContextPacket(source_name=source_name)
    if not isinstance(raw, dict):
        raise SpecError("context packet must be an object")
    extra = set(raw) - _ALLOWED_TOP
    if extra:
        raise SpecError(f"context packet contains unsupported fields: {sorted(extra)}")
    version = str(raw.get("mesh_version", "8.5"))
    if version not in {"8.5", "8.5.0", "8.25", "8.25.0"}:
        raise SpecError("context mesh_version must be 8.5 or migratable 8.25")
    packet_id = _id(raw.get("packet_id", "packet"), "packet_id")
    title = str(raw.get("title", ""))
    phase = raw.get("phase", "T0_HOLD")
    if phase not in TIMING_PHASES:
        raise SpecError(f"phase must be one of {TIMING_PHASES}")

    facts_raw = raw.get("facts", [])
    if not isinstance(facts_raw, list):
        raise SpecError("facts must be a list")
    facts: list[dict[str, Any]] = []
    fact_ids: set[str] = set()
    for i, item in enumerate(facts_raw):
        if not isinstance(item, dict):
            raise SpecError(f"facts[{i}] must be an object")
        item_id = _id(item.get("id"), f"facts[{i}].id")
        if item_id in fact_ids:
            raise SpecError(f"duplicate fact id {item_id}")
        fact_ids.add(item_id)
        text = str(item.get("text", "")).strip()
        if not text:
            raise SpecError(f"facts[{i}].text is required")
        materiality = item.get("materiality", "contextual")
        if materiality not in MATERIALITY_LEVELS:
            raise SpecError(f"facts[{i}].materiality invalid")
        audiences = _audiences(item.get("audiences", list(CONTEXT_PROFILES)), f"facts[{i}].audiences")
        facts.append({
            "id": item_id,
            "text": text,
            "evidence": str(item.get("evidence", "")),
            "materiality": materiality,
            "audiences": audiences,
            "public_safe": bool(item.get("public_safe", False)),
        })

    objectives_raw = raw.get("objectives", [])
    if not isinstance(objectives_raw, list):
        raise SpecError("objectives must be a list")
    objectives: list[dict[str, Any]] = []
    objective_ids: set[str] = set()
    for i, item in enumerate(objectives_raw):
        if not isinstance(item, dict):
            raise SpecError(f"objectives[{i}] must be an object")
        item_id = _id(item.get("id"), f"objectives[{i}].id")
        if item_id in objective_ids:
            raise SpecError(f"duplicate objective id {item_id}")
        objective_ids.add(item_id)
        text = str(item.get("text", "")).strip()
        if not text:
            raise SpecError(f"objectives[{i}].text is required")
        zone = item.get("zone", "Z0_PRIVATE_CORE")
        if zone not in DISCLOSURE_ZONES:
            raise SpecError(f"objectives[{i}].zone invalid")
        audiences = _audiences(item.get("audiences", ["internal"]), f"objectives[{i}].audiences")
        objectives.append({
            "id": item_id,
            "text": text,
            "zone": zone,
            "audiences": audiences,
            "declassify_phase": str(item.get("declassify_phase", "")),
        })

    claims_raw = raw.get("claims", [])
    if not isinstance(claims_raw, list):
        raise SpecError("claims must be a list")
    claims: list[dict[str, Any]] = []
    claim_ids: set[str] = set()
    for i, item in enumerate(claims_raw):
        if not isinstance(item, dict):
            raise SpecError(f"claims[{i}] must be an object")
        item_id = _id(item.get("id"), f"claims[{i}].id")
        if item_id in claim_ids:
            raise SpecError(f"duplicate claim id {item_id}")
        claim_ids.add(item_id)
        kind = item.get("kind", "fact")
        if kind not in CLAIM_KINDS:
            raise SpecError(f"claims[{i}].kind invalid")
        text = str(item.get("text", "")).strip()
        if not text:
            raise SpecError(f"claims[{i}].text is required")
        audiences = _audiences(item.get("audiences", ["public"]), f"claims[{i}].audiences")
        fact_refs = tuple(item.get("fact_refs", []))
        if any(ref not in fact_ids for ref in fact_refs):
            raise SpecError(f"claims[{i}] references absent fact")
        claims.append({
            "id": item_id,
            "kind": kind,
            "text": text,
            "audiences": audiences,
            "fact_refs": fact_refs,
            "required": bool(item.get("required", False)),
            "order": int(item.get("order", i)),
        })

    req_raw = raw.get("required_disclosures", {})
    if not isinstance(req_raw, dict):
        raise SpecError("required_disclosures must be an object")
    required: dict[str, tuple[str, ...]] = {}
    claim_id_set = set(claim_ids)
    for audience, values in req_raw.items():
        if audience not in CONTEXT_PROFILES:
            raise SpecError(f"unsupported required disclosure audience {audience}")
        if not isinstance(values, (list, tuple)) or any(v not in claim_id_set for v in values):
            raise SpecError(f"required_disclosures.{audience} contains absent claim")
        required[audience] = tuple(dict.fromkeys(values))

    prohibited = raw.get("prohibited_claims", [])
    if not isinstance(prohibited, (list, tuple)) or any(not isinstance(x, str) for x in prohibited):
        raise SpecError("prohibited_claims must be list of strings")
    lexicon = raw.get("lexicon", {})
    if not isinstance(lexicon, dict):
        raise SpecError("lexicon must be an object")
    return ContextPacket(
        version="8.5", packet_id=packet_id, title=title, phase=phase,
        facts=facts, objectives=objectives, claims=claims,
        required_disclosures=required, prohibited_claims=tuple(prohibited),
        lexicon=lexicon, source_name=source_name,
    )
