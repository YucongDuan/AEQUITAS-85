from __future__ import annotations

from typing import Any

from .canonical import canonical_core_object, core_digest
from .errors import ContinuityError
from .io import core_to_carrier
from .model import CoreArtifact
from .normalize import normalize_core


def _record_map(artifact: CoreArtifact) -> dict[str, dict[str, Any]]:
    canonical = canonical_core_object(artifact)
    return {record["id"]: record for record in canonical["records"]}


def _route_set(artifact: CoreArtifact) -> set[tuple[str, str]]:
    return {(route.source, route.target) for route in artifact.routes}


def diff_core(parent: CoreArtifact, child: CoreArtifact) -> dict[str, Any]:
    parent_records = _record_map(parent)
    child_records = _record_map(child)
    parent_ids = set(parent_records)
    child_ids = set(child_records)
    mutated = sorted(
        record_id
        for record_id in parent_ids & child_ids
        if parent_records[record_id] != child_records[record_id]
    )
    parent_routes = _route_set(parent)
    child_routes = _route_set(child)
    result = {
        "parent_core_digest": core_digest(parent),
        "child_core_digest": core_digest(child),
        "added_records": sorted(child_ids - parent_ids),
        "removed_records": sorted(parent_ids - child_ids),
        "mutated_records": mutated,
        "added_routes": [
            {"source": source, "target": target}
            for source, target in sorted(child_routes - parent_routes)
        ],
        "removed_routes": [
            {"source": source, "target": target}
            for source, target in sorted(parent_routes - child_routes)
        ],
    }
    result["append_only_continuity"] = not any(
        [
            result["removed_records"],
            result["mutated_records"],
            result["removed_routes"],
        ]
    )
    return result


def assert_continuity(parent: CoreArtifact, child: CoreArtifact) -> dict[str, Any]:
    result = diff_core(parent, child)
    if not result["append_only_continuity"]:
        raise ContinuityError(
            "append-only continuity failed: "
            f"removed_records={result['removed_records']}, "
            f"mutated_records={result['mutated_records']}, "
            f"removed_routes={result['removed_routes']}"
        )
    return result


def compose(left: CoreArtifact, right: CoreArtifact) -> CoreArtifact:
    left_carrier = core_to_carrier(left)
    right_carrier = core_to_carrier(right)
    records_by_id: dict[str, dict[str, Any]] = {
        record["id"]: record for record in left_carrier["records"]
    }
    canonical_left = _record_map(left)
    canonical_right = _record_map(right)
    for record in right_carrier["records"]:
        record_id = record["id"]
        if record_id in records_by_id:
            if canonical_left[record_id] != canonical_right[record_id]:
                raise ContinuityError(
                    f"record id collision with different core content: {record_id}"
                )
        else:
            records_by_id[record_id] = record
    route_set = {
        (item["source"], item["target"])
        for item in left_carrier["routes"] + right_carrier["routes"]
    }
    return normalize_core(
        {
            "mesh_version": "8.5",
            "records": [records_by_id[key] for key in sorted(records_by_id)],
            "routes": [
                {"source": source, "target": target}
                for source, target in sorted(route_set)
            ],
        },
        source_name="composition",
    )


def extend(parent: CoreArtifact, extension: CoreArtifact) -> tuple[CoreArtifact, dict[str, Any]]:
    child = compose(parent, extension)
    return child, assert_continuity(parent, child)
