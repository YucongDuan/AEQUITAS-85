from __future__ import annotations

import html
import json
from typing import Any


def render_result_dashboard(result: dict[str, Any], *, title: str | None = None, private: bool = True) -> str:
    title = title or result.get("title", "MESH8.5")
    state = result.get("system_state", "UNKNOWN")
    primary = result.get("decision", {}).get("primary_action") or {}
    hypotheses = result.get("decision", {}).get("hypothesis_ranking", [])
    releases = result.get("releases", {})
    checks = result.get("coupled_checks", {})
    colors = {"PASS": "ok", "BLOCK": "bad", "REVIEW": "warn"}
    closure_order = [
        "semantic_11111",
        "active_responsibility",
        "substantive_protection",
        "truth_preserving_disclosure",
        "authority_chain_at_declared_stage",
        "world_effect_and_correction",
    ]
    boundary_order = [
        "primary_action_not_treated_as_execution_authority",
        "no_automatic_external_punishment",
    ]
    def _gate_cards(keys: list[str], *, pass_label: str = "闭合", fail_label: str = "开放") -> str:
        return "".join(
            f'<div class="gate"><span>{html.escape(k.replace("_", " "))}</span>'
            f'<b class="{"ok" if checks.get(k) else "bad"}">{pass_label if checks.get(k) else fail_label}</b></div>'
            for k in keys
        )
    closure_cards = _gate_cards(closure_order)
    boundary_cards = _gate_cards(boundary_order, pass_label="满足", fail_label="违反")
    debt = result.get("responsibility_debt_vector", {})
    debt_rows = "".join(
        f'<tr><td>{html.escape(k.replace("_", " "))}</td>'
        f'<td class="{"bad" if v else "ok"}">{"存在" if v else "清偿"}</td></tr>'
        for k, v in debt.items()
    )
    hyp_rows = "".join(
        f'<tr><td>{html.escape(h.get("label", ""))}</td>'
        f'<td>{html.escape(h.get("probability", {}).get("band", ""))}</td>'
        f'<td>{h.get("probability", {}).get("low", 0):.1%} - {h.get("probability", {}).get("high", 0):.1%}</td>'
        f'<td>{html.escape(h.get("severity_if_missed", ""))}</td></tr>'
        for h in hypotheses
    )
    release_rows = "".join(
        f'<tr><td>{html.escape(a)}</td><td class="{colors.get(v.get("status"), "warn")}">'
        f'{html.escape(v.get("status", ""))}</td><td>'
        f'{html.escape(", ".join(x.get("code", "") for x in v.get("findings", [])) or "-")}</td></tr>'
        for a, v in releases.items()
    )
    monitor = "".join(f'<li>{html.escape(x)}</li>' for x in primary.get("monitor", []))
    triggers = "".join(f'<li>{html.escape(x)}</li>' for x in primary.get("escalation_triggers", []))
    raw = html.escape(json.dumps(result, ensure_ascii=False, indent=2))
    private_badge = (
        '<span class="private">内部控制视图</span>'
        if private
        else '<span class="public">公开参考视图</span>'
    )
    return f"""<!doctype html><html lang="zh-CN"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><title>{html.escape(title)}</title><style>
:root{{--bg:#071014;--panel:#0c1b21;--panel2:#10272e;--line:#23434d;--ink:#e8f3f3;--muted:#93aeb3;--cyan:#43d6d0;--gold:#f5c66d;--green:#64db8b;--red:#ff7d7d;--orange:#ffb96b}}
*{{box-sizing:border-box}}body{{margin:0;background:radial-gradient(circle at 80% 0,#16363d 0,transparent 38%),var(--bg);color:var(--ink);font-family:Inter,"Noto Sans SC","Microsoft YaHei",sans-serif}}
header{{padding:46px 5vw 28px;border-bottom:1px solid var(--line)}}.eyebrow{{color:var(--cyan);letter-spacing:.12em;font-weight:800}}h1{{font-size:clamp(30px,5vw,62px);line-height:1.06;margin:12px 0}}
.sub{{color:var(--muted);max-width:950px;font-size:17px}}.badge,.private,.public{{display:inline-block;border:1px solid var(--line);border-radius:999px;padding:7px 11px;margin:4px 8px 4px 0}}
.private{{border-color:#824951;background:#29181d;color:#ffd8dc}}.public{{border-color:#2d7051;background:#10271d;color:#d4ffe5}}main{{padding:30px 5vw 70px;max-width:1500px;margin:auto}}
.hero{{display:grid;grid-template-columns:1.4fr .8fr;gap:18px}}.card{{background:linear-gradient(180deg,var(--panel2),var(--panel));border:1px solid var(--line);border-radius:20px;padding:20px;box-shadow:0 18px 45px #0005}}
.state{{font-size:22px;color:var(--gold);overflow-wrap:anywhere;word-break:break-word}}.transition{{color:var(--cyan);font-weight:800;overflow-wrap:anywhere;word-break:break-word}}h2{{margin-top:34px;color:var(--cyan)}}h3{{margin-top:0}}.gates{{display:grid;grid-template-columns:repeat(auto-fit,minmax(230px,1fr));gap:10px}}
.gate{{display:flex;justify-content:space-between;gap:10px;background:#09171c;border:1px solid var(--line);border-radius:12px;padding:13px}}.ok{{color:var(--green)}}.bad{{color:var(--red)}}.warn{{color:var(--orange)}}
table{{width:100%;border-collapse:collapse;background:var(--panel)}}th,td{{border:1px solid var(--line);padding:11px;text-align:left;vertical-align:top}}th{{color:var(--gold)}}.split{{display:grid;grid-template-columns:1fr 1fr;gap:18px}}
pre{{white-space:pre-wrap;overflow:auto;max-height:520px;background:#041014;border:1px solid var(--line);border-radius:15px;padding:16px;color:#cfe6e8}}footer{{color:var(--muted);padding:25px 5vw 50px;border-top:1px solid var(--line)}}
@media(max-width:850px){{.hero,.split{{grid-template-columns:1fr}}}}
</style></head><body><header><div class="eyebrow">DIKWP-MESH 8.5 · RESPONSIBILITY WORLDLINE</div>
<h1>{html.escape(title)}</h1><p class="sub">主动责任、语境分域、实质保护与世界效应闭合。推荐不是授权，执行不是完成，公开不是内部纪要，纠错不是覆盖历史。</p>
{private_badge}<span class="badge">D / I / K / W / P only</span><span class="badge">non-core semantic authority = 0</span></header><main>
<div class="hero"><div class="card"><h3>系统状态</h3><div class="state">{html.escape(state)}</div><p>案例：{html.escape(result.get("case_id", ""))}</p><p>运行摘要：<code>{html.escape(result.get("run_digest", "")[:24])}…</code></p></div>
<div class="card"><h3>当前首选行动</h3><div class="state">{html.escape(primary.get("label", "无可执行行动"))}</div><p>状态：{html.escape(result.get("decision", {}).get("decision_state", ""))}</p><p>负责人：{html.escape(primary.get("owner", ""))}</p><p>截止：{primary.get("deadline_hours", "-")} 小时</p></div></div>
<div class="card" style="margin-top:18px"><h3>下一项强制迁移</h3><div class="transition">{html.escape(result.get("next_required_transition", "UNDECLARED"))}</div><p>责任债务采用非补偿向量：任何一项未清偿，都不能被其他维度的高表现抵消。</p></div>
<h2>六重闭合</h2><div class="gates">{closure_cards}</div>
<h2>两条不可越过边界</h2><div class="gates">{boundary_cards}</div>
<h2>责任债务向量</h2><div class="card"><table><thead><tr><th>债务</th><th>状态</th></tr></thead><tbody>{debt_rows}</tbody></table></div>
<div class="split"><div><h2>监测</h2><div class="card"><ul>{monitor or '<li>未声明</li>'}</ul></div></div><div><h2>升级触发器</h2><div class="card"><ul>{triggers or '<li>未声明</li>'}</ul></div></div></div>
<h2>假设概率排序</h2><div class="card"><table><thead><tr><th>解释</th><th>层级</th><th>区间</th><th>漏判后果</th></tr></thead><tbody>{hyp_rows}</tbody></table></div>
<h2>受众发布状态</h2><div class="card"><table><thead><tr><th>受众</th><th>状态</th><th>发现</th></tr></thead><tbody>{release_rows}</tbody></table></div>
<div class="split"><div><h2>授权链</h2><div class="card"><p class="state">{html.escape(result.get("authority", {}).get("state", ""))}</p><p>{html.escape(result.get("authority", {}).get("boundary", ""))}</p></div></div>
<div><h2>世界效应</h2><div class="card"><p class="state">{html.escape(result.get("worldline", {}).get("state", ""))}</p><p>阶段：{html.escape(result.get("worldline", {}).get("stage", ""))}</p></div></div></div>
<h2>机器可读运行记录</h2><details class="card"><summary>展开完整JSON</summary><pre>{raw}</pre></details></main>
<footer>Mesh8.5 reference runtime. PASS只表示当前声明的结构条件满足，不替代外部事实核验、法定授权、专业判断或现实验收。</footer></body></html>"""
