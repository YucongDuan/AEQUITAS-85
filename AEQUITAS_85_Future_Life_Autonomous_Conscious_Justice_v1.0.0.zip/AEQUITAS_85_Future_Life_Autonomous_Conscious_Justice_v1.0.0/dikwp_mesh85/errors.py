class Mesh82Error(ValueError):
    """Base error for DIKWP-MESH 8.5 carrier/runtime validation."""


class SpecError(Mesh82Error):
    """Raised when a JSON carrier does not satisfy the 8.1 protocol."""


class NativeParseError(Mesh82Error):
    """Raised when a native .d825 carrier cannot be parsed."""


class ContinuityError(Mesh82Error):
    """Raised when append-only continuity or composition is violated."""


class MigrationError(Mesh82Error):
    """Raised when a Mesh8.0 carrier cannot be migrated faithfully."""
