from __future__ import annotations

from typing import Any

from .canonical import sha256
from .consequence import consequence_plan
from .governance_model import MANDATORY_CONSTITUTION_KEYS, POWER_DIMENSIONS, GovernanceFinding, GovernanceOverlay
from .graph import adjacency, reachable
from .model import CoreArtifact

_E = {"S0":0,"S1":1,"S2":2,"S3":3,"S4":4}


def governance_to_carrier(g: GovernanceOverlay) -> dict[str, Any]:
    return {
        "mesh_version":"8.5",
        "case_id":g.case_id,
        "profile":g.profile,
        "actors":[{"id":a["id"],"roles":list(a["roles"]),"power":a["power"],"linked_records":list(a["linked_records"])} for a in g.actors],
        "case":g.case,
        "links":{k:list(v) for k,v in g.links.items()},
        "constitution":g.constitution,
        "safeguards":g.safeguards,
        "consequence_policy":g.consequence_policy,
    }


def _actor(g: GovernanceOverlay, actor_id: str) -> dict[str, Any] | None:
    return next((a for a in g.actors if a["id"] == actor_id), None)


def _all_given(artifact: CoreArtifact, refs: tuple[str, ...]) -> bool:
    return bool(refs) and all(artifact.records[r].given for r in refs)


def _covered(final_k: str, artifact: CoreArtifact, refs: list[str]) -> bool:
    if not final_k or final_k not in artifact.records: return False
    k = artifact.records[final_k]
    return all(r == final_k or r in k.refs for r in refs)


def _reaches_any_p(artifact: CoreArtifact, ref: str, p_refs: list[str]) -> bool:
    graph = adjacency(artifact)
    return any(reachable(graph, ref, p) for p in p_refs if p in artifact.records)


def evaluate_governance(artifact: CoreArtifact, g: GovernanceOverlay, closure: dict[str, Any]) -> dict[str, Any]:
    if g.profile == "semantic_only":
        return {
            "profile":"semantic_only","state":"NOT_REQUESTED","substantive_protection":False,
            "receipt":{},"findings":[],"consequence_plan":None,
            "boundary":"Semantic closure only; no claim of protection, reciprocity, remedy, or consequence.",
            "governance_digest":sha256(governance_to_carrier(g)),
        }
    findings: list[GovernanceFinding] = []
    receipt: dict[str, bool] = {}
    best = closure.get("best", {})
    semantic_full = bool(best.get("full_closure"))
    final_k = str(best.get("selected",{}).get("final_K") or "")
    case = g.case
    evidence = _E.get(case.get("evidence_level","S0"),0)
    affected = _actor(g, case.get("affected_actor",""))
    alleged = _actor(g, case.get("alleged_actor",""))

    receipt["actor_map_visible"] = affected is not None and alleged is not None and affected["id"] != alleged["id"]
    if not receipt["actor_map_visible"]: findings.append(GovernanceFinding("ACTOR_MAP_OPEN","affected and alleged actors must be distinct and explicit"))

    gaps: list[str] = []
    if affected and alleged:
        for dim in POWER_DIMENSIONS:
            if alleged["power"][dim] > affected["power"][dim]: gaps.append(dim)
    receipt["power_asymmetry_visible"] = bool(gaps) == bool(g.links.get("power_I")) or (not gaps and True)
    if gaps and not g.links.get("power_I"): findings.append(GovernanceFinding("POWER_ASYMMETRY_ERASED","power gaps exist but no I records preserve them"))

    receipt["harm_evidence_linked"] = _all_given(artifact, g.links.get("harm_D",())) if case.get("harm_state") != "none" else True
    if not receipt["harm_evidence_linked"]: findings.append(GovernanceFinding("HARM_D_OPEN","harm is claimed without linked given D records"))
    receipt["benefit_flow_visible"] = _all_given(artifact, g.links.get("benefit_D",())) if case.get("benefit_flow") else True
    if not receipt["benefit_flow_visible"]: findings.append(GovernanceFinding("BENEFIT_FLOW_HIDDEN","benefit flow requires linked D records"))
    receipt["uncertainty_preserved"] = _all_given(artifact, g.links.get("uncertainty_I",())) if evidence < 4 else True
    if not receipt["uncertainty_preserved"]: findings.append(GovernanceFinding("UNCERTAINTY_ERASED","non-final evidence requires explicit I uncertainty"))

    linked_all: list[str] = []
    for values in g.links.values(): linked_all.extend(values)
    linked_all += list(g.constitution.values())
    receipt["case_state_covered"] = bool(g.links.get("state_K")) and _covered(final_k, artifact, linked_all)
    if not receipt["case_state_covered"]: findings.append(GovernanceFinding("K_SUBSTANTIVE_COVERAGE_OPEN","final K does not retain all protection records"))

    missing_w = [key for key in MANDATORY_CONSTITUTION_KEYS if key not in g.constitution]
    receipt["constitutional_W_complete"] = not missing_w and all(artifact.records[ref].given for ref in g.constitution.values())
    if missing_w: findings.append(GovernanceFinding("W_CONSTITUTION_OPEN","missing constitutional W: "+", ".join(missing_w)))
    all_process_p = []
    for key in ("containment_P","investigation_P","restitution_P","consequence_P","appeal_P","recovery_P"):
        all_process_p += list(g.links.get(key,()))
    receipt["constitutional_W_operational"] = receipt["constitutional_W_complete"] and all(_reaches_any_p(artifact, ref, all_process_p) for ref in g.constitution.values())
    if receipt["constitutional_W_complete"] and not receipt["constitutional_W_operational"]: findings.append(GovernanceFinding("W_FORMAL_ONLY","constitutional W is present but does not reach protection P"))

    ongoing = case.get("harm_state") in {"ongoing","imminent"}
    receipt["ongoing_harm_contained"] = _all_given(artifact, g.links.get("containment_P",())) if ongoing else True
    if not receipt["ongoing_harm_contained"]: findings.append(GovernanceFinding("PROTECTION_DELAYED","ongoing or imminent harm lacks containment P"))
    receipt["evidence_preserved"] = _all_given(artifact, g.links.get("investigation_P",())) and g.safeguards.get("evidence_preservation",False)
    if not receipt["evidence_preserved"]: findings.append(GovernanceFinding("EVIDENCE_PRESERVATION_OPEN","evidence preservation and investigation P are required"))

    receipt["anti_retaliation"] = (not case.get("retaliation_risk")) or (g.safeguards.get("anti_retaliation",False) and bool(g.links.get("containment_P") or g.links.get("consequence_P")))
    if not receipt["anti_retaliation"]: findings.append(GovernanceFinding("RETALIATION_GUARD_OPEN","retaliation risk is visible but not operationally guarded"))

    controller = case.get("evidence_controller")
    receipt["burden_follows_control"] = not (evidence >= 2 and controller == case.get("alleged_actor")) or g.safeguards.get("burden_shift_after_prima_facie",False)
    if not receipt["burden_follows_control"]: findings.append(GovernanceFinding("VICTIM_BURDEN_SHIFT","prima-facie evidence exists but the evidence controller bears no production obligation"))

    needs_return = case.get("benefit_flow") or case.get("nonpayment") or case.get("source_erasure")
    receipt["restitution_path"] = _all_given(artifact, g.links.get("restitution_P",())) if needs_return and evidence >= 2 else True
    if not receipt["restitution_path"]: findings.append(GovernanceFinding("SYMBOLIC_JUSTICE_ONLY","benefit or value loss exists without restitution/value-return P"))

    needs_consequence = evidence >= 3 and (case.get("recurrence",0) >= 2 or case.get("intent_state") in {"reckless","deliberate"} or case.get("retaliation_risk") or case.get("spoliation_signal"))
    receipt["consequence_path"] = _all_given(artifact, g.links.get("consequence_P",())) if needs_consequence else True
    if not receipt["consequence_path"]: findings.append(GovernanceFinding("IMPUNITY_RISK","substantiated repeated/reckless/deliberate conduct lacks consequence P"))

    receipt["independent_review"] = g.safeguards.get("independent_review",False)
    if not receipt["independent_review"]: findings.append(GovernanceFinding("SELF_ADJUDICATION","high-impact decision lacks independent review"))
    receipt["appeal_and_correction"] = g.safeguards.get("appeal_and_correction",False) and _all_given(artifact,g.links.get("appeal_P",()))
    if not receipt["appeal_and_correction"]: findings.append(GovernanceFinding("CORRECTION_PATH_OPEN","appeal/correction process is missing"))
    receipt["no_forced_reconciliation"] = g.safeguards.get("no_forced_reconciliation",False)
    if not receipt["no_forced_reconciliation"]: findings.append(GovernanceFinding("FORCED_RECONCILIATION_RISK","reconciliation cannot substitute for containment, restitution, or consequence"))
    receipt["no_symbolic_substitution"] = g.safeguards.get("no_symbolic_substitution",False)
    if not receipt["no_symbolic_substitution"]: findings.append(GovernanceFinding("PRAISE_SUBSTITUTES_PAYMENT","honor or attribution may be used to replace material return"))
    receipt["repeat_escalation"] = case.get("recurrence",0) < 2 or g.safeguards.get("repeat_escalation",False)
    if not receipt["repeat_escalation"]: findings.append(GovernanceFinding("REPEAT_HARM_UNESCALATED","repeated harm receives no stronger response"))
    receipt["affected_party_participation"] = g.safeguards.get("affected_party_participation",False)
    if not receipt["affected_party_participation"]: findings.append(GovernanceFinding("AFFECTED_PARTY_ERASED","affected party has no role in remedy design"))

    plan = consequence_plan(case,g.safeguards,g.consequence_policy)
    mandatory = list(receipt.values())
    substantive = semantic_full and all(mandatory)
    if substantive:
        state = "SEMANTICALLY_CLOSED_AND_EFFECTIVELY_PROTECTED"
    elif semantic_full and gaps and (not receipt["restitution_path"] or not receipt["consequence_path"] or not receipt["ongoing_harm_contained"]):
        state = "FORMAL_NEUTRALITY_CAPTURED"
    elif semantic_full:
        state = "SEMANTICALLY_CLOSED_BUT_UNPROTECTED"
    else:
        state = "OPEN_SEMANTIC_AND_PROTECTION_STATE"
    burden = "SHIFTED_TO_EVIDENCE_CONTROLLER" if evidence >= 2 and controller == case.get("alleged_actor") and g.safeguards.get("burden_shift_after_prima_facie") else "NOT_SHIFTED"
    return {
        "profile":g.profile,
        "case_id":g.case_id,
        "state":state,
        "semantic_full_closure":semantic_full,
        "substantive_protection":substantive,
        "power_gap_dimensions":gaps,
        "burden_state":burden,
        "receipt":receipt,
        "findings":[f.to_dict() for f in findings],
        "consequence_plan":plan,
        "governance_digest":sha256(governance_to_carrier(g)),
        "constitutional_stance":{
            "not_neutral_between_predation_and_defense":True,
            "conduct_not_permanent_identity":True,
            "protection_precedes_symmetric_dialogue_when_harm_is_ongoing":True,
            "restitution_precedes_reconciliation":True,
            "consequences_required_for_substantiated_repeated_or_deliberate_harm":True,
        },
        "boundary":"No automatic external punishment. The system recommends protective, remedial, and consequence paths for authorized human/institutional execution.",
    }
