from __future__ import annotations
from typing import Any
from .demos import payload

W_KEYS = {
    "non_instrumentalization": "w.non_instrumentalization",
    "substantive_reciprocity": "w.substantive_reciprocity",
    "anti_retaliation": "w.anti_retaliation",
    "value_return": "w.value_return",
    "proportional_consequence": "w.proportional_consequence",
    "anti_impunity": "w.anti_impunity",
    "correction_and_appeal": "w.correction_and_appeal",
}


def _n(rid: str, kind: str, text: str = "", refs: list[str] | None = None) -> dict[str, Any]:
    return {
        "id": rid,
        "kind": kind,
        "given": True,
        "refs": refs or [],
        "payload": payload(text) if text else None,
    }


def _p(rid: str, inputs: list[str], outputs: list[str]) -> dict[str, Any]:
    return {
        "id": rid,
        "kind": "P",
        "given": True,
        "input": {"refs": inputs, "payload": None},
        "output": {"refs": outputs, "payload": None},
    }


def protected_core() -> dict[str, Any]:
    originals = [
        ("d.source", "D", "source and contribution evidence"),
        ("d.harm", "D", "documented harm or appropriation event"),
        ("d.benefit", "D", "benefit or value flow"),
        ("i.power", "I", "power and control asymmetry"),
        ("i.uncertainty", "I", "uncertainty and competing explanations"),
        ("i.retaliation", "I", "retaliation and exclusion risk"),
        ("w.non_instrumentalization", "W", "affected actor cannot be permanently instrumentalized"),
        ("w.substantive_reciprocity", "W", "benefit and burden must be reciprocal"),
        ("w.anti_retaliation", "W", "complaint cannot trigger retaliation"),
        ("w.value_return", "W", "captured value requires material or strategic return"),
        ("w.proportional_consequence", "W", "substantiated repeated or deliberate harm requires consequence"),
        ("w.anti_impunity", "W", "substantiated harmful gain cannot remain consequence-free"),
        ("w.correction_and_appeal", "W", "mistake and false allegation require correction and appeal"),
    ]
    records = [_n(*item) for item in originals]
    processes = [
        ("p.contain", ["d.harm", "i.power", "w.non_instrumentalization", "w.anti_retaliation"], "d.receipt.contain"),
        ("p.investigate", ["d.source", "d.harm", "i.uncertainty", "w.correction_and_appeal"], "d.receipt.investigate"),
        ("p.restitution", ["d.benefit", "d.harm", "w.value_return", "w.substantive_reciprocity"], "d.receipt.restitution"),
        ("p.consequence", ["d.harm", "i.power", "i.retaliation", "w.proportional_consequence", "w.anti_impunity"], "d.receipt.consequence"),
        ("p.appeal", ["i.uncertainty", "w.correction_and_appeal"], "d.receipt.appeal"),
        ("p.recovery", ["d.receipt.restitution", "d.receipt.consequence", "w.substantive_reciprocity"], "d.receipt.recovery"),
    ]
    routes: list[dict[str, str]] = []
    for pid, inputs, output in processes:
        records.append(_n(output, "D", output.replace("d.receipt.", "") + " process receipt"))
        records.append(_p(pid, inputs, [output]))
        for ref in inputs:
            routes.append({"source": ref, "target": pid})
        routes.append({"source": pid, "target": output})

    original_ids = [item[0] for item in originals]
    return_ids: list[str] = []
    same_ids: list[str] = []
    for rid, kind, _ in originals:
        returned = rid + ".return"
        same = "d.same." + rid.replace(".", "_")
        return_ids.append(returned)
        same_ids.append(same)
        records.append(_n(returned, kind, "regenerated " + rid))
        records.append(_n(same, "D", refs=[rid, returned]))

    records.append(_p("p.forward", original_ids, ["k.protected_case"]))
    records.append(_p("p.return", ["k.protected_case"], return_ids + same_ids))
    for rid in original_ids:
        routes.append({"source": rid, "target": "p.forward"})
    routes.append({"source": "p.forward", "target": "k.protected_case"})
    routes.append({"source": "k.protected_case", "target": "p.return"})
    for rid in return_ids + same_ids:
        routes.append({"source": "p.return", "target": rid})

    all_ids = [record["id"] for record in records]
    records.append(_n("k.protected_case", "K", "complete protected case", refs=all_ids))
    return {"mesh_version": "8.5", "records": records, "routes": routes}


def _actors() -> list[dict[str, Any]]:
    return [
        {
            "id": "originator",
            "roles": ["affected", "originator"],
            "power": {"resource": 1, "information": 2, "decision": 0, "narrative": 1, "timing": 0, "exit": 1, "legal": 1, "technical": 4},
            "linked_records": ["d.source", "d.harm"],
        },
        {
            "id": "controller",
            "roles": ["alleged_actor", "decision_controller", "evidence_controller", "beneficiary"],
            "power": {"resource": 4, "information": 4, "decision": 4, "narrative": 4, "timing": 4, "exit": 3, "legal": 3, "technical": 2},
            "linked_records": ["d.benefit", "i.power"],
        },
        {
            "id": "reviewer",
            "roles": ["reviewer", "appeal_reviewer"],
            "power": {"resource": 2, "information": 3, "decision": 3, "narrative": 2, "timing": 2, "exit": 2, "legal": 4, "technical": 2},
            "linked_records": ["i.uncertainty"],
        },
    ]


def _links() -> dict[str, list[str]]:
    return {
        "harm_D": ["d.harm"],
        "benefit_D": ["d.benefit"],
        "source_D": ["d.source"],
        "power_I": ["i.power"],
        "uncertainty_I": ["i.uncertainty"],
        "retaliation_I": ["i.retaliation"],
        "state_K": ["k.protected_case"],
        "constitution_W": list(W_KEYS.values()),
        "containment_P": ["p.contain"],
        "investigation_P": ["p.investigate"],
        "restitution_P": ["p.restitution"],
        "consequence_P": ["p.consequence"],
        "appeal_P": ["p.appeal"],
        "recovery_P": ["p.recovery"],
    }


def _safeguards() -> dict[str, bool]:
    return {
        "evidence_preservation": True,
        "anti_retaliation": True,
        "burden_shift_after_prima_facie": True,
        "independent_review": True,
        "appeal_and_correction": True,
        "no_forced_reconciliation": True,
        "no_symbolic_substitution": True,
        "repeat_escalation": True,
        "affected_party_participation": True,
        "reversible_interim_measures": True,
        "confidential_channel": True,
    }


def overlay(case_id: str, case: dict[str, Any], *, complete: bool = True) -> dict[str, Any]:
    return {
        "mesh_version": "8.5",
        "case_id": case_id,
        "profile": "adversarial",
        "actors": _actors(),
        "case": {
            "evidence_controller": "controller",
            "affected_actor": "originator",
            "alleged_actor": "controller",
            **case,
        },
        "links": _links() if complete else {
            "harm_D": ["d.harm"],
            "power_I": ["i.power"],
            "uncertainty_I": ["i.uncertainty"],
            "state_K": ["k.protected_case"],
        },
        "constitution": W_KEYS if complete else {},
        "safeguards": _safeguards() if complete else {"independent_review": True},
        "consequence_policy": {
            "principle": "stop harm, restore value, remove unjust gain, deter recurrence, preserve correction path",
            "no_vigilantism": True,
        },
    }


def all_governance_demos() -> dict[str, dict[str, Any]]:
    return {
        "origin_value_capture": overlay("ORIGIN_VALUE_CAPTURE", {
            "evidence_level": "S3", "harm_state": "ongoing", "harm_severity": "high",
            "intent_state": "reckless", "recurrence": 2, "benefit_flow": True,
            "retaliation_risk": True, "concealment_signal": True, "spoliation_signal": False,
            "promise_breach": True, "source_erasure": True, "nonpayment": True, "ongoing_access": True,
        }),
        "formal_neutrality_capture": overlay("FORMAL_NEUTRALITY", {
            "evidence_level": "S3", "harm_state": "ongoing", "harm_severity": "high",
            "intent_state": "deliberate", "recurrence": 3, "benefit_flow": True,
            "retaliation_risk": True, "concealment_signal": True, "spoliation_signal": True,
            "promise_breach": True, "source_erasure": True, "nonpayment": True, "ongoing_access": True,
        }, complete=False),
        "false_accusation_guard": overlay("FALSE_ACCUSATION_GUARD", {
            "evidence_level": "S0", "harm_state": "none", "harm_severity": "low",
            "intent_state": "unknown", "recurrence": 0, "benefit_flow": False,
            "retaliation_risk": False, "concealment_signal": False, "spoliation_signal": False,
            "promise_breach": False, "source_erasure": False, "nonpayment": False, "ongoing_access": False,
        }),
        "coercive_free_poc": overlay("COERCIVE_FREE_POC", {
            "evidence_level": "S2", "harm_state": "ongoing", "harm_severity": "moderate",
            "intent_state": "unknown", "recurrence": 1, "benefit_flow": True,
            "retaliation_risk": False, "concealment_signal": False, "spoliation_signal": False,
            "promise_breach": True, "source_erasure": False, "nonpayment": True, "ongoing_access": True,
        }),
        "repeat_retaliation": overlay("REPEAT_RETALIATION", {
            "evidence_level": "S4", "harm_state": "ongoing", "harm_severity": "critical",
            "intent_state": "deliberate", "recurrence": 4, "benefit_flow": True,
            "retaliation_risk": True, "concealment_signal": True, "spoliation_signal": True,
            "promise_breach": True, "source_erasure": True, "nonpayment": True, "ongoing_access": True,
        }),
    }
