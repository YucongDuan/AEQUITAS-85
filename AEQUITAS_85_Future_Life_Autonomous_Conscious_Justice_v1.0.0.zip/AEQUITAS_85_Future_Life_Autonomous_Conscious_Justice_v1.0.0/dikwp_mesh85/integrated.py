from __future__ import annotations

from copy import deepcopy
from pathlib import Path
from typing import Any

from .active_decision import evaluate_active_decision
from .active_normalize import normalize_active_case
from .authority import evaluate_authority, normalize_authority
from .canonical import sha256
from .closure import evaluate_closure
from .context_normalize import normalize_context
from .disclosure import release_packet
from .errors import SpecError
from .governance import evaluate_governance
from .governance_normalize import normalize_governance
from .io import load_json
from .normalize import normalize_core
from .probability import assess_all
from .worldline import evaluate_worldline, normalize_worldline

SYSTEM_NAME = "DIKWP-MESH 8.5 Active Responsibility, Context Partitioning, Substantive Protection, and World-Effect Closure"
MODE = "MESH85_ACTIVE_CONTEXTUAL_RESPONSIBILITY_AND_WORLD_EFFECT_CLOSURE"


def normalize_integrated(raw: Any, *, source_name: str = "") -> dict[str, Any]:
    if not isinstance(raw, dict):
        raise SpecError("Mesh8.5 integrated carrier must be an object")
    value = deepcopy(raw)
    if str(value.get("mesh_version", "")) not in {"8.5", "8.5.0"}:
        raise SpecError("integrated mesh_version must be 8.5")
    value["mesh_version"] = "8.5"
    if not isinstance(value.get("case_id"), str) or not value["case_id"].strip():
        raise SpecError("case_id must be a non-empty string")
    value.setdefault("title", value["case_id"])
    for key in ("core", "active", "governance", "context", "authority", "worldline"):
        if key not in value:
            raise SpecError(f"integrated carrier missing {key}")
    value.setdefault("release_audiences", ["affected_party", "executor", "public"])
    value.setdefault("source_name", source_name)
    return value


def evaluate_integrated(raw: Any, *, source_name: str = "") -> dict[str, Any]:
    carrier = normalize_integrated(raw, source_name=source_name)
    core = normalize_core(carrier["core"], source_name=source_name + "#core")
    closure = evaluate_closure(core, profile="bidirectional")

    active = normalize_active_case(carrier["active"], source_name=source_name + "#active")
    hypotheses = assess_all(active["hypotheses"], active["evidence"])
    decision = evaluate_active_decision(active, hypotheses).to_dict()

    governance_overlay = normalize_governance(carrier["governance"], core, source_name=source_name + "#governance")
    governance = evaluate_governance(core, governance_overlay, closure)

    context = normalize_context(carrier["context"], source_name=source_name + "#context")
    audiences = list(dict.fromkeys(carrier["release_audiences"] + (decision.get("primary_action") or {}).get("required_audiences", [])))
    releases = {audience: release_packet(context, audience) for audience in audiences}

    authority_carrier = normalize_authority(carrier["authority"], source_name=source_name + "#authority")
    authority = evaluate_authority(authority_carrier, decision)

    worldline_carrier = normalize_worldline(carrier["worldline"], source_name=source_name + "#worldline")
    worldline = evaluate_worldline(worldline_carrier, decision, authority, governance, releases)

    semantic_closed = bool(closure.get("best", {}).get("full_closure"))
    active_closed = decision.get("responsibility_closure") == "FULL_ACTIVE_RESPONSIBILITY_CLOSURE"
    protection_closed = bool(governance.get("substantive_protection", False))
    disclosure_closed = all(value.get("status") == "PASS" for value in releases.values())
    stage = worldline.get("stage", "planned")
    authority_ready = authority.get("execution_ready", False) if stage in {"authorized", "executed", "observed", "corrected", "closed", "rolled_back"} else authority.get("recommendation_ready", False)
    world_effect_closed = worldline.get("state") == "FULL_WORLD_EFFECT_AND_CORRECTION_CLOSURE"

    coupled_checks = {
        "semantic_11111": semantic_closed,
        "active_responsibility": active_closed,
        "substantive_protection": protection_closed,
        "truth_preserving_disclosure": disclosure_closed,
        "authority_chain_at_declared_stage": authority_ready,
        "world_effect_and_correction": world_effect_closed,
        "primary_action_not_treated_as_execution_authority": not authority.get("execution_ready", False) or worldline.get("stage") in {"authorized", "executed", "observed", "corrected", "closed", "rolled_back"},
        "no_automatic_external_punishment": governance.get("consequence_plan") is None or not governance.get("consequence_plan", {}).get("automatic_external_enforcement", True),
    }

    if all(coupled_checks.values()):
        system_state = "FULL_MESH85_WORLDLINE_RESPONSIBILITY_CLOSURE"
    elif not semantic_closed:
        system_state = "OPEN_SEMANTIC_FOUNDATION"
    elif not active_closed:
        system_state = "OPEN_ACTIVE_DECISION"
    elif not protection_closed:
        system_state = "FORMALLY_CLOSED_BUT_SUBSTANTIVELY_UNPROTECTED"
    elif not disclosure_closed:
        system_state = "TRUTH_OR_DISCLOSURE_GATE_BLOCKED"
    elif not authority_ready:
        system_state = "AUTHORITY_CHAIN_OPEN"
    elif worldline.get("state") == "EXECUTED_EFFECT_OPEN":
        system_state = "EXECUTED_EFFECT_OPEN"
    else:
        system_state = "PARTIAL_MESH85_CLOSURE"

    responsibility_debt_vector = {
        "semantic_debt": not semantic_closed,
        "decision_debt": not active_closed,
        "protection_debt": not protection_closed,
        "disclosure_debt": not disclosure_closed,
        "authority_debt": not authority_ready,
        "execution_debt": bool(worldline.get("checks", {}).get("execution_event_present") is False),
        "effect_debt": worldline.get("state") == "EXECUTED_EFFECT_OPEN",
        "correction_debt": worldline.get("state") == "CORRECTION_WORLDLINE_OPEN",
        "affected_party_voice_debt": not authority.get("checks", {}).get("affected_party_voice", False),
    }
    transition_by_state = {
        "FULL_MESH85_WORLDLINE_RESPONSIBILITY_CLOSURE": "PRESERVE_AND_MONITOR_CLOSED_WORLDLINE",
        "OPEN_SEMANTIC_FOUNDATION": "COMPLETE_DIKWP_SEMANTIC_FOUNDATION",
        "OPEN_ACTIVE_DECISION": "SELECT_ONE_FEASIBLE_PRIMARY_ACTION_WITH_DEADLINE",
        "FORMALLY_CLOSED_BUT_SUBSTANTIVELY_UNPROTECTED": "CONTAIN_HARM_AND_COMPLETE_PROTECTION_RESTITUTION_PATH",
        "TRUTH_OR_DISCLOSURE_GATE_BLOCKED": "RECOMPILE_AUDIENCE_RELEASE_FROM_SHARED_FACT_SOURCE",
        "AUTHORITY_CHAIN_OPEN": "ASSIGN_AND_VALIDATE_DISTINCT_AUTHORITY_ROLES",
        "EXECUTED_EFFECT_OPEN": "OBSERVE_REAL_WORLD_OUTCOMES_BEFORE_CLOSURE",
        "PARTIAL_MESH85_CLOSURE": "ADVANCE_TO_NEXT_DECLARED_WORLDLINE_STAGE_WITH_RECEIPT",
    }

    result = {
        "system": SYSTEM_NAME,
        "mode": MODE,
        "mesh_version": "8.5.0",
        "case_id": carrier["case_id"],
        "title": carrier["title"],
        "system_state": system_state,
        "coupled_checks": coupled_checks,
        "responsibility_debt_vector": responsibility_debt_vector,
        "responsibility_debt_noncompensatory": True,
        "next_required_transition": transition_by_state[system_state],
        "semantic": closure,
        "decision": decision,
        "governance": governance,
        "releases": releases,
        "authority": authority,
        "worldline": worldline,
        "receipts": {
            "decision": sha256(decision),
            "protection": governance.get("governance_digest"),
            "disclosure": {key: value.get("release_digest") for key, value in releases.items()},
            "authority": authority.get("authority_digest"),
            "worldline": worldline.get("worldline_digest"),
        },
        "semantic_authority": ["D", "I", "K", "W", "P"],
        "non_core_semantic_authority": 0,
        "constitutional_boundaries": {
            "truth_preserving_non_total_disclosure": True,
            "material_disclosure_cannot_be_hidden_by_strategy": True,
            "recommendation_is_not_authorization": True,
            "execution_without_outcome_observation_remains_open": True,
            "protection_and_restitution_precede_forced_reconciliation": True,
            "correction_requires_release_and_consequence_updates": True,
            "responsibility_debts_do_not_compensate_each_other": True,
        },
    }
    result["run_digest"] = sha256(result)
    return result


def evaluate_file(path: str | Path) -> dict[str, Any]:
    return evaluate_integrated(load_json(path), source_name=str(path))
