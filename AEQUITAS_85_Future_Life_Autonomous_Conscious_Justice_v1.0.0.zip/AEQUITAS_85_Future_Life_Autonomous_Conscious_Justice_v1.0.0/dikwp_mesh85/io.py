from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from .aliases import normalize_alias_overlay
from .model import AliasOverlay, CoreArtifact
from .normalize import normalize_core


def core_to_carrier(artifact: CoreArtifact) -> dict[str, Any]:
    records: list[dict[str, Any]] = []
    for record_id in sorted(artifact.records):
        record = artifact.records[record_id]
        base: dict[str, Any] = {
            "id": record.record_id,
            "kind": record.kind,
            "given": record.given,
        }
        if record.kind == "P":
            base["input"] = {
                "refs": list(record.input_endpoint.refs),
                "payload": (
                    {"encoding": "hex", "value": record.input_endpoint.payload.hex()}
                    if record.input_endpoint.payload
                    else None
                ),
            }
            base["output"] = {
                "refs": list(record.output_endpoint.refs),
                "payload": (
                    {"encoding": "hex", "value": record.output_endpoint.payload.hex()}
                    if record.output_endpoint.payload
                    else None
                ),
            }
        else:
            base["refs"] = list(record.refs)
            base["payload"] = (
                {"encoding": "hex", "value": record.payload.hex()}
                if record.payload
                else None
            )
        records.append(base)
    return {
        "mesh_version": "8.5",
        "records": records,
        "routes": [
            {"source": route.source, "target": route.target}
            for route in sorted(artifact.routes)
        ],
    }


def alias_to_carrier(overlay: AliasOverlay) -> dict[str, Any]:
    return {
        "mesh_version": "8.5",
        "bindings": [
            {
                "alias": binding.alias,
                "language": binding.language,
                "targets": list(binding.targets),
            }
            for binding in sorted(
                overlay.bindings,
                key=lambda item: (item.language, item.alias, item.targets),
            )
        ],
    }


def load_json(path: str | Path) -> Any:
    return json.loads(Path(path).read_text(encoding="utf-8"))


def write_json(value: Any, path: str | Path) -> Path:
    output = Path(path)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(
        json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2) + "\n",
        encoding="utf-8",
    )
    return output


def load_core(path: str | Path) -> CoreArtifact:
    source = Path(path)
    return normalize_core(load_json(source), source_name=str(source))


def load_aliases(path: str | Path, artifact: CoreArtifact) -> AliasOverlay:
    source = Path(path)
    return normalize_alias_overlay(load_json(source), artifact, source_name=str(source))
