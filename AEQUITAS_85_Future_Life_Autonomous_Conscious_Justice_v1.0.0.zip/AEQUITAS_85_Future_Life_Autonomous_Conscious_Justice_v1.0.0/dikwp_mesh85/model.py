from __future__ import annotations

from dataclasses import dataclass, field
from typing import Iterable

CORE_KINDS: tuple[str, ...] = ("D", "I", "K", "W", "P")
ALL_ROUTE_CODES: tuple[str, ...] = tuple(
    f"{source}>{target}" for source in CORE_KINDS for target in CORE_KINDS
)


@dataclass(frozen=True)
class Endpoint:
    refs: tuple[str, ...] = ()
    payload: bytes = b""

    @property
    def empty(self) -> bool:
        return not self.refs and not self.payload


@dataclass(frozen=True)
class SemanticRecord:
    kind: str
    record_id: str
    given: bool
    refs: tuple[str, ...] = ()
    payload: bytes = b""
    input_endpoint: Endpoint = field(default_factory=Endpoint)
    output_endpoint: Endpoint = field(default_factory=Endpoint)

    def all_refs(self) -> tuple[str, ...]:
        if self.kind == "P":
            return self.input_endpoint.refs + self.output_endpoint.refs
        return self.refs

    def content_empty(self) -> bool:
        if self.kind == "P":
            return self.input_endpoint.empty and self.output_endpoint.empty
        return not self.refs and not self.payload


@dataclass(frozen=True, order=True)
class Route:
    source: str
    target: str


@dataclass
class CoreArtifact:
    version: str = "8.5"
    records: dict[str, SemanticRecord] = field(default_factory=dict)
    routes: list[Route] = field(default_factory=list)
    source_name: str = ""

    def by_kind(self, kind: str, *, given_only: bool = False) -> list[SemanticRecord]:
        records = [record for record in self.records.values() if record.kind == kind]
        if given_only:
            records = [record for record in records if record.given]
        return sorted(records, key=lambda record: record.record_id)

    def route_code(self, route: Route) -> str:
        return f"{self.records[route.source].kind}>{self.records[route.target].kind}"


@dataclass(frozen=True)
class AliasBinding:
    alias: str
    targets: tuple[str, ...]
    language: str = ""


@dataclass
class AliasOverlay:
    version: str = "8.5"
    bindings: list[AliasBinding] = field(default_factory=list)
    source_name: str = ""

    def aliases_for_targets(self, targets: Iterable[str]) -> list[str]:
        target_tuple = tuple(targets)
        return sorted(
            binding.alias for binding in self.bindings if binding.targets == target_tuple
        )


@dataclass(frozen=True)
class Finding:
    code: str
    message: str
    record_id: str = ""
    level: str = "open"

    def to_dict(self) -> dict[str, str]:
        result = {"code": self.code, "message": self.message, "level": self.level}
        if self.record_id:
            result["record_id"] = self.record_id
        return result


@dataclass
class ClosureCandidate:
    vector: dict[str, int]
    findings: list[Finding]
    forward_p: str = ""
    final_k: str = ""
    reverse_p: str = ""

    @property
    def compact(self) -> str:
        return "".join(str(self.vector[kind]) for kind in CORE_KINDS)

    @property
    def full(self) -> bool:
        return self.compact == "11111"

    @property
    def score(self) -> int:
        return sum(self.vector.values())

    def to_dict(self) -> dict[str, object]:
        return {
            "vector": {kind: self.vector[kind] for kind in CORE_KINDS},
            "vector_compact": self.compact,
            "full_closure": self.full,
            "selected": {
                "forward_P": self.forward_p or None,
                "final_K": self.final_k or None,
                "reverse_P": self.reverse_p or None,
            },
            "open_reasons": [finding.to_dict() for finding in self.findings],
        }
