from __future__ import annotations

import re
from pathlib import Path
from typing import Any

from .errors import NativeParseError, SpecError
from .model import ALL_ROUTE_CODES, CoreArtifact
from .normalize import normalize_core

_ID_RE = re.compile(r"^[A-Za-z0-9_.:-]{1,128}$")
_HEX_RE = re.compile(r"^(?:[0-9A-Fa-f]{2})*$")


def _refs(raw: str, *, line_no: int) -> list[str]:
    if raw in {"", "-"}:
        return []
    values = [value.strip() for value in raw.split(",") if value.strip()]
    if len(values) != len(set(values)):
        raise NativeParseError(f"line {line_no}: duplicate reference")
    for value in values:
        if not _ID_RE.fullmatch(value):
            raise NativeParseError(f"line {line_no}: invalid record id {value!r}")
    return values


def _payload(raw: str, *, line_no: int) -> dict[str, Any] | None:
    if raw in {"", "-"}:
        return None
    if not _HEX_RE.fullmatch(raw):
        raise NativeParseError(
            f"line {line_no}: payload must be even-length hexadecimal or '-'"
        )
    return {"encoding": "hex", "value": raw.lower()}


def parse_native_text(
    text: str,
    *,
    pure: bool = False,
    source_name: str = "",
) -> CoreArtifact:
    if pure:
        try:
            text.encode("ascii")
        except UnicodeEncodeError as exc:
            raise NativeParseError("pure mode accepts ASCII transport only") from exc

    header_seen = False
    records: list[dict[str, Any]] = []
    route_rows: list[tuple[str, str, str, int]] = []
    seen_ids: set[str] = set()

    for line_no, original in enumerate(text.splitlines(), 1):
        line = original.strip()
        if not line:
            continue
        if line.startswith(";"):
            if pure:
                raise NativeParseError(f"line {line_no}: comments are disabled in pure mode")
            continue
        fields = line.split("|")
        if not header_seen:
            if fields not in (["M85", "1"], ["M825", "1"], ["M82", "1"], ["M81", "1"]):
                raise NativeParseError("first content line must be M85|1, migratable M825|1, M82|1, or M81|1")
            header_seen = True
            continue

        tag = fields[0]
        if tag in {"D", "I", "K", "W"}:
            if len(fields) != 5:
                raise NativeParseError(
                    f"line {line_no}: {tag} record requires 5 fields"
                )
            _, record_id, given_raw, refs_raw, payload_raw = fields
            if not _ID_RE.fullmatch(record_id):
                raise NativeParseError(f"line {line_no}: invalid record id {record_id!r}")
            if record_id in seen_ids:
                raise NativeParseError(f"line {line_no}: duplicate record id {record_id}")
            if given_raw not in {"0", "1"}:
                raise NativeParseError(f"line {line_no}: given must be 0 or 1")
            seen_ids.add(record_id)
            records.append(
                {
                    "id": record_id,
                    "kind": tag,
                    "given": given_raw == "1",
                    "refs": _refs(refs_raw, line_no=line_no),
                    "payload": _payload(payload_raw, line_no=line_no),
                }
            )
            continue

        if tag == "P":
            if len(fields) != 7:
                raise NativeParseError(
                    f"line {line_no}: P record requires 7 fields"
                )
            (
                _,
                record_id,
                given_raw,
                input_refs_raw,
                input_payload_raw,
                output_refs_raw,
                output_payload_raw,
            ) = fields
            if not _ID_RE.fullmatch(record_id):
                raise NativeParseError(f"line {line_no}: invalid record id {record_id!r}")
            if record_id in seen_ids:
                raise NativeParseError(f"line {line_no}: duplicate record id {record_id}")
            if given_raw not in {"0", "1"}:
                raise NativeParseError(f"line {line_no}: given must be 0 or 1")
            seen_ids.add(record_id)
            records.append(
                {
                    "id": record_id,
                    "kind": "P",
                    "given": given_raw == "1",
                    "input": {
                        "refs": _refs(input_refs_raw, line_no=line_no),
                        "payload": _payload(input_payload_raw, line_no=line_no),
                    },
                    "output": {
                        "refs": _refs(output_refs_raw, line_no=line_no),
                        "payload": _payload(output_payload_raw, line_no=line_no),
                    },
                }
            )
            continue

        if tag in ALL_ROUTE_CODES:
            if len(fields) != 3:
                raise NativeParseError(
                    f"line {line_no}: route requires code, source id, and target id"
                )
            _, source, target = fields
            route_rows.append((tag, source, target, line_no))
            continue

        raise NativeParseError(f"line {line_no}: unsupported native tag {tag!r}")

    if not header_seen:
        raise NativeParseError("missing M85|1 header")

    routes = [{"source": source, "target": target} for _, source, target, _ in route_rows]
    try:
        artifact = normalize_core(
            {"mesh_version": "8.5", "records": records, "routes": routes},
            source_name=source_name,
        )
    except SpecError as exc:
        raise NativeParseError(str(exc)) from exc

    for code, source, target, line_no in route_rows:
        actual = f"{artifact.records[source].kind}>{artifact.records[target].kind}"
        if code != actual:
            raise NativeParseError(
                f"line {line_no}: route code {code} does not match endpoint kinds {actual}"
            )
    return artifact


def parse_native_file(path: str | Path, *, pure: bool = False) -> CoreArtifact:
    source = Path(path)
    return parse_native_text(
        source.read_text(encoding="utf-8"),
        pure=pure,
        source_name=str(source),
    )


def render_native(artifact: CoreArtifact) -> str:
    lines = ["M85|1"]
    for record_id in sorted(artifact.records):
        record = artifact.records[record_id]
        given = "1" if record.given else "0"
        if record.kind == "P":
            input_refs = ",".join(record.input_endpoint.refs) or "-"
            output_refs = ",".join(record.output_endpoint.refs) or "-"
            input_payload = record.input_endpoint.payload.hex() or "-"
            output_payload = record.output_endpoint.payload.hex() or "-"
            lines.append(
                "|".join(
                    [
                        "P",
                        record.record_id,
                        given,
                        input_refs,
                        input_payload,
                        output_refs,
                        output_payload,
                    ]
                )
            )
        else:
            refs = ",".join(record.refs) or "-"
            payload = record.payload.hex() or "-"
            lines.append("|".join([record.kind, record.record_id, given, refs, payload]))
    for route in sorted(artifact.routes):
        code = artifact.route_code(route)
        lines.append(f"{code}|{route.source}|{route.target}")
    return "\n".join(lines) + "\n"


def write_native(artifact: CoreArtifact, path: str | Path) -> Path:
    output = Path(path)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(render_native(artifact), encoding="ascii")
    return output
