from __future__ import annotations

import re
from copy import deepcopy
from typing import Any

from .errors import SpecError
from .model import CORE_KINDS, CoreArtifact, Endpoint, Route, SemanticRecord
from .payload import decode_payload

_ID_RE = re.compile(r"^[A-Za-z0-9_.:-]{1,128}$")
MAX_RECORDS = 10_000
MAX_ROUTES = 100_000
MAX_PAYLOAD_BYTES = 1_048_576


def _record_id(value: Any, *, path: str) -> str:
    if not isinstance(value, str) or not _ID_RE.fullmatch(value):
        raise SpecError(
            f"{path} must match {_ID_RE.pattern!r}; received {value!r}"
        )
    return value


def _refs(raw: Any, *, path: str) -> tuple[str, ...]:
    if raw is None:
        return ()
    if not isinstance(raw, list):
        raise SpecError(f"{path} must be a list")
    values = tuple(_record_id(value, path=f"{path}[]") for value in raw)
    if len(values) != len(set(values)):
        raise SpecError(f"{path} cannot contain duplicate record identifiers")
    return values


def _payload(raw: Any, *, path: str) -> bytes:
    value = decode_payload(raw, path=path)
    if len(value) > MAX_PAYLOAD_BYTES:
        raise SpecError(
            f"{path} exceeds the {MAX_PAYLOAD_BYTES}-byte carrier limit"
        )
    return value


def _endpoint(raw: Any, *, path: str) -> Endpoint:
    if not isinstance(raw, dict):
        raise SpecError(f"{path} must be an object")
    extra = set(raw) - {"refs", "payload"}
    if extra:
        raise SpecError(f"{path} contains non-protocol fields: {sorted(extra)}")
    return Endpoint(
        refs=_refs(raw.get("refs", []), path=f"{path}.refs"),
        payload=_payload(raw.get("payload"), path=f"{path}.payload"),
    )


def normalize_record(raw: Any, *, index: int = 0) -> SemanticRecord:
    path = f"records[{index}]"
    if not isinstance(raw, dict):
        raise SpecError(f"{path} must be an object")
    kind = raw.get("kind")
    if kind not in CORE_KINDS:
        raise SpecError(f"{path}.kind must be exactly one of {list(CORE_KINDS)}")
    record_id = _record_id(raw.get("id"), path=f"{path}.id")
    if not isinstance(raw.get("given"), bool):
        raise SpecError(f"{path}.given must be boolean")
    given = raw["given"]

    if kind == "P":
        extra = set(raw) - {"id", "kind", "given", "input", "output"}
        if extra:
            raise SpecError(f"{path} contains non-protocol fields: {sorted(extra)}")
        input_endpoint = _endpoint(raw.get("input", {}), path=f"{path}.input")
        output_endpoint = _endpoint(raw.get("output", {}), path=f"{path}.output")
        if given and (input_endpoint.empty or output_endpoint.empty):
            raise SpecError(
                f"{path} is P with given=true, so both input and output must carry refs or payload"
            )
        if not given and (not input_endpoint.empty or not output_endpoint.empty):
            raise SpecError(f"{path} has given=false and therefore cannot carry P content")
        return SemanticRecord(
            kind=kind,
            record_id=record_id,
            given=given,
            input_endpoint=input_endpoint,
            output_endpoint=output_endpoint,
        )

    extra = set(raw) - {"id", "kind", "given", "refs", "payload"}
    if extra:
        raise SpecError(f"{path} contains non-protocol fields: {sorted(extra)}")
    refs = _refs(raw.get("refs", []), path=f"{path}.refs")
    payload = _payload(raw.get("payload"), path=f"{path}.payload")
    if given and not refs and not payload:
        raise SpecError(
            f"{path} has given=true and must carry refs or payload"
        )
    if not given and (refs or payload):
        raise SpecError(
            f"{path} has given=false and therefore cannot carry refs or payload"
        )
    return SemanticRecord(
        kind=kind,
        record_id=record_id,
        given=given,
        refs=refs,
        payload=payload,
    )


def normalize_core(raw: Any, *, source_name: str = "") -> CoreArtifact:
    if not isinstance(raw, dict):
        raise SpecError("Mesh8.5 core carrier must be a JSON object")
    extra = set(raw) - {"mesh_version", "records", "routes"}
    if extra:
        raise SpecError(
            "core carrier contains fields outside the 8.1 core protocol: "
            f"{sorted(extra)}"
        )
    version = str(raw.get("mesh_version", ""))
    if version not in {"8.1", "8.1.0", "8.2", "8.2.0", "8.5", "8.5.0", "8.25", "8.25.0"}:
        raise SpecError("mesh_version must be 8.1, 8.2, 8.25, or 8.5")
    records_raw = raw.get("records")
    routes_raw = raw.get("routes")
    if not isinstance(records_raw, list):
        raise SpecError("records must be a list")
    if len(records_raw) > MAX_RECORDS:
        raise SpecError(f"records exceeds the carrier limit of {MAX_RECORDS}")
    records: dict[str, SemanticRecord] = {}
    for index, item in enumerate(records_raw):
        record = normalize_record(item, index=index)
        if record.record_id in records:
            raise SpecError(f"duplicate record id: {record.record_id}")
        records[record.record_id] = record

    if not isinstance(routes_raw, list):
        raise SpecError("routes must be a list")
    if len(routes_raw) > MAX_ROUTES:
        raise SpecError(f"routes exceeds the carrier limit of {MAX_ROUTES}")
    routes: list[Route] = []
    seen_routes: set[tuple[str, str]] = set()
    for index, item in enumerate(routes_raw):
        path = f"routes[{index}]"
        if not isinstance(item, dict):
            raise SpecError(f"{path} must be an object")
        extra_route = set(item) - {"source", "target"}
        if extra_route:
            raise SpecError(f"{path} contains non-protocol fields: {sorted(extra_route)}")
        source = _record_id(item.get("source"), path=f"{path}.source")
        target = _record_id(item.get("target"), path=f"{path}.target")
        if source not in records or target not in records:
            missing = [value for value in (source, target) if value not in records]
            raise SpecError(f"{path} references absent records: {missing}")
        key = (source, target)
        if key in seen_routes:
            raise SpecError(f"duplicate route: {source}>{target}")
        seen_routes.add(key)
        routes.append(Route(source=source, target=target))

    return CoreArtifact(
        version="8.5",
        records=records,
        routes=routes,
        source_name=source_name,
    )


def core_from_records(
    records: list[dict[str, Any]],
    routes: list[dict[str, Any]],
    *,
    source_name: str = "",
) -> CoreArtifact:
    return normalize_core(
        {"mesh_version": "8.5", "records": deepcopy(records), "routes": deepcopy(routes)},
        source_name=source_name,
    )
