from __future__ import annotations

from copy import deepcopy
from typing import Any

from .canonical import sha256
from .errors import SpecError

STAGES = ("planned", "authorized", "executed", "observed", "corrected", "closed", "held", "rolled_back")
STAGE_RANK = {name: index for index, name in enumerate(STAGES[:6])}


def normalize_worldline(raw: Any, *, source_name: str = "") -> dict[str, Any]:
    if not isinstance(raw, dict):
        raise SpecError("worldline carrier must be an object")
    value = deepcopy(raw)
    if str(value.get("mesh_version", "")) not in {"8.5", "8.5.0"}:
        raise SpecError("worldline mesh_version must be 8.5")
    value["mesh_version"] = "8.5"
    if not isinstance(value.get("case_id"), str) or not value["case_id"].strip():
        raise SpecError("worldline.case_id must be a non-empty string")
    stage = value.get("stage", "planned")
    if stage not in STAGES:
        raise SpecError(f"worldline.stage must be one of {STAGES}")
    value["stage"] = stage
    value.setdefault("decision_receipt", {})
    value.setdefault("authorization_receipt", {})
    value.setdefault("execution_events", [])
    value.setdefault("outcomes", [])
    value.setdefault("corrections", [])
    value.setdefault("release_receipts", [])
    value.setdefault("protection_receipts", [])
    rollback = value.setdefault("rollback", {})
    rollback.setdefault("available", False)
    rollback.setdefault("trigger", "")
    rollback.setdefault("executed", False)
    rollback.setdefault("receipt", "")
    value.setdefault("source_name", source_name)
    return value


def _at_least(stage: str, target: str) -> bool:
    if stage in {"held", "rolled_back"}:
        return False
    return STAGE_RANK.get(stage, -1) >= STAGE_RANK[target]


def evaluate_worldline(
    worldline: dict[str, Any],
    decision: dict[str, Any],
    authority: dict[str, Any],
    governance: dict[str, Any],
    releases: dict[str, dict[str, Any]],
) -> dict[str, Any]:
    stage = worldline["stage"]
    primary = decision.get("primary_action") or {}
    primary_id = primary.get("id", "")
    required_audiences = set(primary.get("required_audiences", []))
    decision_receipt = worldline["decision_receipt"]
    authorization_receipt = worldline["authorization_receipt"]
    execution_events = worldline["execution_events"]
    outcomes = worldline["outcomes"]
    corrections = worldline["corrections"]

    checks: dict[str, bool] = {
        "decision_receipt_matches_primary": decision_receipt.get("primary_action_id") == primary_id and bool(primary_id),
        "authority_ready_before_execution": (not _at_least(stage, "executed")) or authority.get("execution_ready", False),
        "authorization_receipt_matches": (not _at_least(stage, "authorized")) or (
            authorization_receipt.get("action_id") == primary_id
            and authorization_receipt.get("authorization_id") == authority.get("execution_authorization", {}).get("authorization_id")
        ),
        "execution_event_present": (not _at_least(stage, "executed")) or any(e.get("action_id") == primary_id and e.get("status") in {"completed", "in_progress", "rolled_back"} for e in execution_events),
        "outcome_observation_present": (not _at_least(stage, "observed")) or bool(outcomes),
        "required_releases_pass": all(releases.get(a, {}).get("status") == "PASS" for a in required_audiences),
        "substantive_protection_closed": bool(governance.get("substantive_protection", False)),
        "correction_complete_when_declared": (not _at_least(stage, "corrected")) or bool(corrections),
        "rollback_available_for_reversible_action": primary.get("vector", {}).get("reversibility", 0.0) < 0.2 or bool(worldline["rollback"].get("available")),
    }

    if corrections:
        latest = corrections[-1]
        expected_audiences = set(latest.get("audiences_to_update", []))
        updated = set(latest.get("audiences_updated", []))
        checks["correction_updates_all_owed_audiences"] = expected_audiences.issubset(updated)
        checks["correction_names_changed_fact"] = bool(latest.get("new_fact")) and bool(latest.get("invalidated_premise")) and bool(latest.get("withdrawn_or_revised_advice"))
        checks["correction_updates_protection_and_consequence"] = bool(latest.get("protection_or_consequence_update"))
    else:
        checks["correction_updates_all_owed_audiences"] = not _at_least(stage, "corrected")
        checks["correction_names_changed_fact"] = not _at_least(stage, "corrected")
        checks["correction_updates_protection_and_consequence"] = not _at_least(stage, "corrected")

    findings = [{"code": key.upper(), "message": key.replace("_", " ") + " is open"} for key, ok in checks.items() if not ok]
    executed = _at_least(stage, "executed")
    observed = _at_least(stage, "observed")
    corrected = _at_least(stage, "corrected")

    if stage == "held":
        state = "WORLDLINE_HELD"
    elif stage == "rolled_back":
        state = "WORLDLINE_ROLLED_BACK" if worldline["rollback"].get("executed") else "ROLLBACK_RECEIPT_OPEN"
    elif executed and not observed:
        state = "EXECUTED_EFFECT_OPEN"
    elif corrected and not all(checks.values()):
        state = "CORRECTION_WORLDLINE_OPEN"
    elif stage == "closed" and all(checks.values()):
        state = "FULL_WORLD_EFFECT_AND_CORRECTION_CLOSURE"
    elif all(checks.values()):
        state = "WORLDLINE_READY_AT_DECLARED_STAGE"
    else:
        state = "OPEN_WORLDLINE_STATE"

    receipt = {
        "case_id": worldline["case_id"],
        "stage": stage,
        "state": state,
        "checks": checks,
        "findings": findings,
        "decision_receipt": decision_receipt,
        "authorization_receipt": authorization_receipt,
        "execution_events": execution_events,
        "outcomes": outcomes,
        "corrections": corrections,
        "rollback": worldline["rollback"],
        "boundary": "Execution without observed effects remains open. Correction is incomplete until the changed fact, invalidated premise, affected releases, protection, restitution, and consequence paths are updated.",
    }
    receipt["worldline_digest"] = sha256(receipt)
    return receipt
