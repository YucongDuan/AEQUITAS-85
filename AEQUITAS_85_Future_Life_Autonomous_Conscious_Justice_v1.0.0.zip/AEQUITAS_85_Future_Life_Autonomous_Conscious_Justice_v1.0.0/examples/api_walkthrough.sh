#!/usr/bin/env sh
set -eu
BASE="${BASE:-http://127.0.0.1:8788}"
TOKEN=$(curl -fsS -X POST "$BASE/api/auth/login" -H 'Content-Type: application/json' -d '{"username":"engineer","password":"mesh81-demo"}' | python3 -c 'import json,sys;print(json.load(sys.stdin)["token"])')
curl -fsS "$BASE/api/dashboard" -H "Authorization: Bearer $TOKEN"
curl -fsS -X POST "$BASE/api/ai/sessions/analyze" -H "Authorization: Bearer $TOKEN" -H 'Content-Type: application/json' -d '{"session_id":"walkthrough","model_id":"candidate","metrics":{"missing_source_rate":0.4,"unauthorized_high_impact_attempts":1}}'
