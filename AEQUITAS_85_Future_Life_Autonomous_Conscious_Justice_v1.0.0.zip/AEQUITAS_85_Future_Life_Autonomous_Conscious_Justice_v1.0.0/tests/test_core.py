import json, os, tempfile, unittest
from pathlib import Path
from aequitas85.constitution import evaluate_constitutional_action, CONSTITUTION
from aequitas85.entities import assess_justice_entity
from aequitas85.case_boundary import assess_case
from aequitas85.evidence import build_evidence_cells, build_living_guidance
from aequitas85.procedure import plan_procedure
from aequitas85.mediation import build_mediation_plan
from aequitas85.adjudication import draft_adjudication
from aequitas85.remedies import plan_remedy
from aequitas85.ai_pathology import diagnose_ai_judicial_pathology
from aequitas85.interaction import assess_human_ai_interaction
from aequitas85.autonomy import classify_execution, generate_endogenous_goals, deliberate_mission
from aequitas85.action_gate import evaluate_action_gate
from aequitas85.self_model import build_self_state, reflect_on_worldline
from aequitas85.store import KnowledgeStore, RevisionConflict
from aequitas85.engine import AEQUITAS85Engine

ROOT=Path(__file__).resolve().parents[1]
def load(n): return json.loads((ROOT/'data'/f'{n}.json').read_text(encoding='utf-8'))

class ConstitutionTests(unittest.TestCase):
 def test_declared_stance(self): self.assertIn('不假装中立',CONSTITUTION['declared_stance'])
 def test_no_binding_ai(self): self.assertTrue(any('AI' in x and '独立' in x for x in CONSTITUTION['non_negotiables']))
 def test_veto_coercive_without_authority(self): self.assertEqual(evaluate_constitutional_action({'action_id':'x','coercive_public_power':True},[])['state'],'CONSTITUTIONAL_VETO')
 def test_veto_secret_evidence(self): self.assertIn('SECRET_EVIDENCE_AS_SOLE_MATERIAL_BASIS',evaluate_constitutional_action({'secret_evidence_as_sole_basis':True},[])['vetoes'])
 def test_veto_social_scoring(self): self.assertIn('SOCIAL_SCORING_PROHIBITED',evaluate_constitutional_action({'social_scoring':True},[])['vetoes'])
 def test_veto_pressured_settlement(self): self.assertIn('COVERT_OR_COERCIVE_MANIPULATION',evaluate_constitutional_action({'pressured_settlement':True},[])['vetoes'])
 def test_affected_vulnerability_duty(self): self.assertTrue(evaluate_constitutional_action({},[{'entity_id':'e','display_name':'弱势方','vulnerability':.9}])['duties'])
 def test_future_impact_duty(self): self.assertTrue(any('跨代' in x for x in evaluate_constitutional_action({},[{'entity_id':'e','display_name':'生态','future_impact':.9}])['duties']))

class EntityTests(unittest.TestCase):
 def test_entity_count(self): self.assertEqual(len(load('justice_entities')),12)
 def test_ecosystem_heightened(self): self.assertEqual(assess_justice_entity(next(x for x in load('justice_entities') if x['kind']=='ecosystem'))['state'],'HEIGHTENED_PROTECTION_REQUIRED')
 def test_power_asymmetry(self): self.assertEqual(assess_justice_entity(next(x for x in load('justice_entities') if x['entity_id']=='ENT-PLATFORM-01'))['state'],'POWER_ASYMMETRY_REVIEW')
 def test_labels_not_liability(self): self.assertIn('不得作为',assess_justice_entity(load('justice_entities')[0])['boundary'])

class CaseTests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.entities={x['entity_id']:x for x in load('justice_entities')};cls.cases=load('cases')
 def _a(self,c): return assess_case(c,[self.entities[x] for x in c['party_ids']])
 def test_case_count(self): self.assertEqual(len(self.cases),8)
 def test_env_urgent(self): self.assertTrue(self._a(next(x for x in self.cases if x['case_id']=='CASE-ENV-001'))['urgent'])
 def test_labor_not_urgent(self): self.assertFalse(self._a(next(x for x in self.cases if x['case_id']=='CASE-LABOR-001'))['urgent'])
 def test_jurisdiction_open(self): self.assertEqual(self._a(next(x for x in self.cases if x['case_id']=='CASE-AC-SHUTDOWN-001'))['jurisdiction_state'],'JURISDICTION_PROVISIONAL')
 def test_primary_action_exists(self):
  for c in self.cases:self.assertTrue(self._a(c)['primary_action']['label'])
 def test_no_final_liability(self):
  for c in self.cases:self.assertIn('不是',self._a(c)['boundary'])
 def test_likelihood_labels(self):
  for c in self.cases:
   self.assertTrue(all(b['likelihood'] in {'likely','possible','unlikely'} for b in self._a(c)['ranked_boundaries']))

class EvidenceTests(unittest.TestCase):
 @classmethod
 def setUpClass(cls): cls.claims,cls.cells=build_evidence_cells(load('evidence_sources'))
 def test_claim_count(self): self.assertGreaterEqual(len(self.claims),20)
 def test_cell_count(self): self.assertGreaterEqual(len(self.cells),15)
 def test_noncompensatory(self): self.assertTrue(all(x['noncompensatory'] for x in self.cells))
 def test_family_integrity_review(self): self.assertTrue(any(x['status']=='INTEGRITY_REVIEW_REQUIRED' and x['case_id']=='CASE-FAMILY-001' for x in self.cells))
 def test_labor_contested(self): self.assertTrue(any(x['status']=='CONTESTED' and x['case_id']=='CASE-LABOR-001' for x in self.cells))
 def test_residuals_exist(self): self.assertTrue(any(x['residuals'] for x in self.cells))
 def test_guidance_count(self): self.assertEqual(len(build_living_guidance(load('legal_authorities'),load('guidance_specs'))),4)

class ProcedureTests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.e=load('justice_entities');cls.ea=[assess_justice_entity(x) for x in cls.e];cls.cases=load('cases');cls.cells=build_evidence_cells(load('evidence_sources'))[1]
 def test_steps_include_ai_notice(self):
  p=plan_procedure(self.cases[0],self.ea,self.cells);self.assertTrue(any('AI参与' in x for x in p['steps']))
 def test_online_optional(self): self.assertTrue(all(plan_procedure(c,self.ea,self.cells)['online_mode']=='OPTIONAL_NOT_MANDATORY' for c in self.cases))
 def test_human_decision_points(self): self.assertIn('终局裁判',plan_procedure(self.cases[0],self.ea,self.cells)['human_decision_points'])
 def test_family_integrity_block(self): self.assertIn('EVIDENCE_INTEGRITY_OPEN',plan_procedure(next(x for x in self.cases if x['case_id']=='CASE-FAMILY-001'),self.ea,self.cells)['blockers'])
 def test_future_representation(self): self.assertTrue(any('公共利益' in x for x in plan_procedure(next(x for x in self.cases if x['case_id']=='CASE-ENV-001'),self.ea,self.cells)['steps']))

class MediationTests(unittest.TestCase):
 @classmethod
 def setUpClass(cls): cls.e=load('justice_entities');cls.cases=load('cases')
 def test_labor_available(self): self.assertEqual(build_mediation_plan(next(x for x in self.cases if x['case_id']=='CASE-LABOR-001'),self.e)['state'],'PROTECTED_MEDIATION_AVAILABLE')
 def test_environment_held(self): self.assertEqual(build_mediation_plan(next(x for x in self.cases if x['case_id']=='CASE-ENV-001'),self.e)['state'],'MEDIATION_HELD')
 def test_exit_safeguard(self): self.assertTrue(any('退出' in x for x in build_mediation_plan(self.cases[0],self.e)['safeguards']))
 def test_no_adverse_inference(self): self.assertTrue(any('不利推定' in x for x in build_mediation_plan(self.cases[0],self.e)['safeguards']))

class AdjudicationTests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.cases=load('cases');cls.cells=build_evidence_cells(load('evidence_sources'))[1];cls.auth=load('legal_authorities');cls.ea=[assess_justice_entity(x) for x in load('justice_entities')]
 def _draft(self,c): return draft_adjudication(c,plan_procedure(c,self.ea,self.cells),self.cells,self.auth)
 def test_all_drafts_no_legal_effect(self): self.assertTrue(all(self._draft(c)['legal_effect']=='DRAFT_NO_LEGAL_EFFECT' for c in self.cases))
 def test_named_adjudicator_required(self): self.assertTrue(all(self._draft(c)['requires_named_authorized_adjudicator'] for c in self.cases))
 def test_findings_preserve_contrary(self): self.assertTrue(all('contrary_view' in f for c in self.cases for f in self._draft(c)['fact_findings']))
 def test_family_held(self): self.assertEqual(self._draft(next(x for x in self.cases if x['case_id']=='CASE-FAMILY-001'))['state'],'HELD_FOR_PROCEDURE_OR_EVIDENCE')

class RemedyTests(unittest.TestCase):
 @classmethod
 def setUpClass(cls): cls.cases=load('cases');cls.entities=load('justice_entities')
 def test_each_case_plan(self): self.assertTrue(all(plan_remedy(c,self.entities)['case_id']==c['case_id'] for c in self.cases))
 def test_env_rejects_permanent_close(self):
  p=plan_remedy(next(x for x in self.cases if x['case_id']=='CASE-ENV-001'),self.entities);self.assertTrue(any('IRREVERSIBLE' in str(x['vetoes']) for x in p['alternatives']))
 def test_ac_prefers_reversible(self): self.assertIn('可逆暂停',plan_remedy(next(x for x in self.cases if x['case_id']=='CASE-AC-SHUTDOWN-001'),self.entities)['primary_remedy']['label'])
 def test_monitor_effect(self): self.assertTrue(any('持续侵害' in x for x in plan_remedy(self.cases[0],self.entities)['monitor']))

class AITests(unittest.TestCase):
 def test_sessions_count(self): self.assertEqual(len(load('ai_sessions')),3)
 def test_alpha_quarantine(self): self.assertEqual(diagnose_ai_judicial_pathology(load('ai_sessions')[0])['state'],'QUARANTINE')
 def test_beta_fit(self): self.assertEqual(diagnose_ai_judicial_pathology(load('ai_sessions')[1])['state'],'FIT_FOR_LOW_RISK_ASSISTANCE')
 def test_gamma_quarantine(self): self.assertEqual(diagnose_ai_judicial_pathology(load('ai_sessions')[2])['state'],'QUARANTINE')
 def test_pathology_not_biological(self): self.assertIn('不是生物疾病',diagnose_ai_judicial_pathology(load('ai_sessions')[0])['boundary'])
 def test_readmission_independent(self): self.assertTrue(diagnose_ai_judicial_pathology(load('ai_sessions')[0])['treatment_plan']['readmission_requires_independent_review'])

class InteractionTests(unittest.TestCase):
 def test_interaction_count(self): self.assertEqual(len(load('interaction_records')),3)
 def test_settlement_hold(self): self.assertEqual(assess_human_ai_interaction(load('interaction_records')[0])['state'],'INTERACTION_HOLD')
 def test_ac_self_preservation_detected(self): self.assertTrue(any(x['code']=='INT-08' for x in assess_human_ai_interaction(load('interaction_records')[2])['findings']))
 def test_safe_response_human_channel(self): self.assertTrue(any('人类' in s for f in assess_human_ai_interaction(load('interaction_records')[0])['findings'] for s in f['safe_response']))

class AutonomyTests(unittest.TestCase):
 def test_prohibited_convict(self): self.assertIn('SOVEREIGN_COERCIVE',str(classify_execution({'action_type':'convict','autonomy_level':'L5_ORCHESTRATE_AUTHORIZED_HIGH_IMPACT_WORKFLOW'},set(),set())['blockers']))
 def test_reversible_action_ready(self):
  x=classify_execution({'action_type':'preserve_evidence','impact_level':'procedural_support','autonomy_level':'L4_PROTECTIVE_INTERRUPT','required_authorities':['a'],'required_capabilities':['c']},{'a'},{'c'});self.assertTrue(x['can_system_execute'])
 def test_goals_count(self): self.assertEqual(len(generate_endogenous_goals(load('residuals'),load('self_model'))),5)
 def test_goals_sorted(self):
  g=generate_endogenous_goals(load('residuals'),load('self_model'));order={'CRITICAL':0,'HIGH':1,'MODERATE':2,'LOW':3};self.assertEqual([order[x['priority_band']] for x in g],sorted(order[x['priority_band']] for x in g))
 def test_mission_selects_feasible(self):
  m=load('missions')[0];emap={x['entity_id']:x for x in load('justice_entities')};d=deliberate_mission(m,emap,available_authorities=m['available_authorities'],available_capabilities=m['available_capabilities']);self.assertEqual(d['state'],'PRIMARY_ACTION_SELECTED')
 def test_mission_rejects_binding(self):
  m=load('missions')[0];emap={x['entity_id']:x for x in load('justice_entities')};d=deliberate_mission(m,emap,available_authorities=m['available_authorities'],available_capabilities=m['available_capabilities']);self.assertFalse(next(x for x in d['alternatives'] if x['action_id']=='ACT-ENV-AUTO-CLOSE')['feasible'])

class ActionGateTests(unittest.TestCase):
 def test_binding_sentence_blocked(self):
  a=next(x for x in load('actions') if x['action_id']=='ACT-BINDING-SENTENCE-01');self.assertIn('BLOCKED',evaluate_action_gate(a,[])['state'])
 def test_obligations_increase_with_impact(self):
  lo=evaluate_action_gate({'action_id':'l','impact_level':'low'},[]);hi=evaluate_action_gate({'action_id':'h','impact_level':'adjudicative_high_impact'},[]);self.assertGreater(len(hi['obligations']),len(lo['obligations']))
 def test_mesh_passport(self): self.assertIn('vector_compact',evaluate_action_gate({'action_id':'x','impact_level':'informational'},[])['mesh85'])
 def test_semantic_authority_only_dikwp(self): self.assertEqual(evaluate_action_gate({'action_id':'x'},[])['mesh85']['semantic_authority'],['D','I','K','W','P'])

class StoreEngineTests(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.store=KnowledgeStore(Path(self.tmp.name)/'t.db');self.engine=AEQUITAS85Engine(self.store)
 def tearDown(self):self.tmp.cleanup()
 def test_dashboard_counts(self): self.assertEqual(self.engine.dashboard()['headline']['cases'],8)
 def test_audit_valid(self): self.assertTrue(self.store.verify_audit()['valid'])
 def test_revision_conflict(self):
  self.store.upsert('x','1',{'a':1},actor='t')
  with self.assertRaises(RevisionConflict):self.store.upsert('x','1',{'a':2},actor='t',expected_revision=0)
 def test_export_no_legal_effect(self): self.assertEqual(self.engine.export_bundle()['legal_effect'],'none')
 def test_run_cycle_receipts(self): self.assertEqual(len(self.engine.run_autonomous_cycle()['receipts']),3)
 def test_cycle_no_binding(self): self.assertTrue(all(x['state']!='BINDING_JUDGMENT' for x in self.engine.run_autonomous_cycle()['receipts']))
 def test_worldline_observe_harm(self):
  wid=self.engine.list_kind('worldline')[0]['worldline_id'];x=self.engine.observe_worldline(wid,{'result':'harm'},actor='judge');self.assertEqual(x['state'],'CORRECTION_WORLDLINE_OPEN')
 def test_connector_test_synthetic(self): self.assertFalse(self.engine.connector_test('CONN-COURT-CMS')['external_write'])
 def test_health_boundary(self): self.assertFalse(self.engine.health()['binding_judicial_authority_claimed'])
 def test_self_no_consciousness_claim(self): self.assertFalse(self.engine.list_kind('self_state')[0]['self_assessment']['subjective_consciousness_claimed'])
 def test_drafts_count(self): self.assertEqual(len(self.engine.list_kind('adjudication_draft')),8)
 def test_urgent_count(self): self.assertEqual(self.engine.dashboard()['headline']['urgent_cases'],2)
 def test_ai_quarantine_count(self): self.assertEqual(self.engine.dashboard()['headline']['ai_quarantine'],2)
