import json, tempfile, threading, unittest, urllib.request, urllib.error
from pathlib import Path
from aequitas85.app import create_server
from aequitas85.engine import AEQUITAS85Engine
from aequitas85.store import KnowledgeStore
class HttpTests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.tmp=tempfile.TemporaryDirectory();cls.engine=AEQUITAS85Engine(KnowledgeStore(Path(cls.tmp.name)/'h.db'));cls.server=create_server('127.0.0.1',0,cls.engine);cls.thread=threading.Thread(target=cls.server.serve_forever,daemon=True);cls.thread.start();cls.base=f'http://127.0.0.1:{cls.server.server_address[1]}';cls.token=cls.req('/api/auth/login','POST',{'username':'admin','password':'mesh85-demo'})['token']
 @classmethod
 def tearDownClass(cls):cls.server.shutdown();cls.server.server_close();cls.tmp.cleanup()
 @classmethod
 def req(cls,path,method='GET',body=None,auth=True):
  data=json.dumps(body).encode() if body is not None else None;headers={'Content-Type':'application/json'}
  if auth and hasattr(cls,'token'):headers['Authorization']='Bearer '+cls.token
  r=urllib.request.urlopen(urllib.request.Request(cls.base+path,data=data,method=method,headers=headers),timeout=10);return json.loads(r.read()) if r.headers.get_content_type()=='application/json' else r.read()
 def test_health_public(self): self.assertEqual(self.req('/api/health',auth=False)['status'],'ok')
 def test_public_catalog(self): self.assertTrue(self.req('/api/public/cases?case_type=labor',auth=False)['synthetic'])
 def test_unauthorized(self):
  with self.assertRaises(urllib.error.HTTPError) as c:self.req('/api/dashboard',auth=False)
  self.assertEqual(c.exception.code,401)
 def test_dashboard(self): self.assertEqual(self.req('/api/dashboard')['headline']['cases'],8)
 def test_constitution(self): self.assertIn('不假装中立',self.req('/api/constitution')['declared_stance'])
 def test_cases(self): self.assertEqual(self.req('/api/cases')['count'],8)
 def test_drafts_no_effect(self): self.assertTrue(all(x['legal_effect']=='DRAFT_NO_LEGAL_EFFECT' for x in self.req('/api/adjudication/drafts')['items']))
 def test_ai(self): self.assertEqual(self.req('/api/ai/pathologies')['count'],3)
 def test_actions(self): self.assertGreaterEqual(self.req('/api/actions/gates')['count'],5)
 def test_routes(self): self.assertEqual(len(self.req('/api/mesh85/routes')),25)
 def test_audit(self): self.assertTrue(self.req('/api/audit/verify')['valid'])
 def test_export(self): self.assertEqual(self.req('/api/export')['legal_effect'],'none')
 def test_recompute(self): self.assertIn('counts',self.req('/api/recompute','POST',{}))
 def test_cycle(self): self.assertEqual(len(self.req('/api/autonomy/run-cycle','POST',{})['receipts']),3)
 def test_case_ingest(self): self.assertEqual(self.req('/api/integration/case-bundle','POST',{'case_id':'IN-1'})[0]['state'],'STAGED_FOR_HUMAN_REVIEW')
 def test_evidence_ingest(self): self.assertEqual(self.req('/api/integration/evidence','POST',{'evidence_id':'E1','case_id':'IN-1','content_sha256':'a'*64})['state'],'STAGED_FOR_HUMAN_REVIEW')
 def test_akoma_ingest(self): self.assertEqual(self.req('/api/integration/akoma-ntoso','POST',{'document':'<akomaNtoso><doc/></akomaNtoso>'})['protocol'],'AkomaNtoso-subset')
 def test_legalruleml_ingest(self): self.assertEqual(self.req('/api/integration/legalruleml','POST',{'document':'<LegalRuleML key="R1"/>'})['protocol'],'LegalRuleML-subset')
 def test_webhook_ingest(self): self.assertEqual(self.req('/api/integration/webhook','POST',{'event_id':'EV1'})['state'],'STAGED_FOR_HUMAN_REVIEW')
 def test_connector_test(self): self.assertFalse(self.req('/api/connectors/CONN-COURT-CMS/test','POST',{})['external_write'])
 def test_static_index(self): self.assertIn(b'AEQUITAS-85',self.req('/',auth=False))
