import unittest
from aequitas85.protocols import *
class ProtocolTests(unittest.TestCase):
 def test_case_single(self): self.assertEqual(parse_case_bundle({'case_id':'C1'})[0].case_key,'C1')
 def test_case_bundle(self): self.assertEqual(len(parse_case_bundle({'resourceType':'CaseBundle','entry':[{'resource':{'case_id':'C1'}},{'resource':{'case_id':'C2'}}]})),2)
 def test_case_requires_id(self):
  with self.assertRaises(InterfaceValidationError):parse_case_bundle({'title':'x'})
 def test_evidence(self): self.assertEqual(parse_evidence_manifest({'evidence_id':'E1','case_id':'C1','content_sha256':'a'*64}).case_key,'C1')
 def test_evidence_digest_required(self):
  with self.assertRaises(InterfaceValidationError):parse_evidence_manifest({'evidence_id':'E1','case_id':'C1'})
 def test_akoma(self): self.assertEqual(parse_akoma_ntoso('<akomaNtoso><doc><meta><identification><FRBRthis value="/cn/doc/1"/></identification></meta></doc></akomaNtoso>').protocol,'AkomaNtoso-subset')
 def test_akoma_doctype_blocked(self):
  with self.assertRaises(InterfaceValidationError):parse_akoma_ntoso('<!DOCTYPE a><akomaNtoso/>')
 def test_legalruleml(self): self.assertEqual(parse_legalruleml('<LegalRuleML key="r1"><Rule/></LegalRuleML>').external_id,'r1')
 def test_legalruleml_entity_blocked(self):
  with self.assertRaises(InterfaceValidationError):parse_legalruleml('<!ENTITY a "x"><LegalRuleML/>')
 def test_webhook(self): self.assertEqual(parse_vendor_webhook({'event_id':'EV1','case_id':'C1'}).case_key,'C1')
 def test_webhook_requires_event(self):
  with self.assertRaises(InterfaceValidationError):parse_vendor_webhook({})
 def test_public_catalog(self): self.assertEqual(len(filter_public_case_catalog({'case_type':'labor'})),1)
