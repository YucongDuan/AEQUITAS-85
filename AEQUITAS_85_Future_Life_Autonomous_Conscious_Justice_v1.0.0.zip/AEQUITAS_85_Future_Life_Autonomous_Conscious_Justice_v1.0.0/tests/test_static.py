import json,re,unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
class StaticTests(unittest.TestCase):
 def test_required_files(self):
  for x in ['README.md','LICENSE','NOTICE','SECURITY.md','CONSTITUTION.md','openapi.json','web/index.html','web/app.js','web/styles.css','Dockerfile','docker-compose.yml','START_AEQUITAS85.sh','打开衡界AEQUITAS85.bat']:self.assertTrue((ROOT/x).exists(),x)
 def test_no_vitalis_brand(self):
  texts='\n'.join(p.read_text(encoding='utf-8',errors='ignore') for p in list((ROOT/'aequitas85').glob('*.py'))+list((ROOT/'web').glob('*')) if p.is_file());self.assertNotIn('VITALIS',texts)
 def test_no_medical_routes(self): self.assertNotIn('/api/health/cases',(ROOT/'web/app.js').read_text(encoding='utf-8'))
 def test_external_write_off(self): self.assertTrue(all(not x['external_write'] for x in json.loads((ROOT/'data/connectors.json').read_text(encoding='utf-8'))))
 def test_cases_synthetic(self): self.assertEqual(len(json.loads((ROOT/'data/cases.json').read_text(encoding='utf-8'))),8)
 def test_constitution_principles(self): self.assertEqual(len(json.loads((ROOT/'data/constitution.json').read_text(encoding='utf-8'))['principles']),10)
 def test_openapi_valid_json(self): json.loads((ROOT/'openapi.json').read_text(encoding='utf-8'))
 def test_csp_no_external(self): self.assertNotRegex((ROOT/'web/index.html').read_text(encoding='utf-8'),r'https?://')
 def test_ai_no_binding(self): self.assertIn('DRAFT_NO_LEGAL_EFFECT',(ROOT/'aequitas85/adjudication.py').read_text(encoding='utf-8'))
 def test_prohibited_actions(self): self.assertIn("'convict'",(ROOT/'aequitas85/autonomy.py').read_text(encoding='utf-8'))
 def test_25_routes(self):
  from aequitas85.mesh85_bridge import route_catalog
  self.assertEqual(len(route_catalog()),25)
 def test_utf8_chinese(self): self.assertIn('衡界',(ROOT/'README.md').read_text(encoding='utf-8'))
