import sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
import json,subprocess
outdir=ROOT/'outputs/visual_evidence';outdir.mkdir(parents=True,exist_ok=True)
for p in outdir.glob('*.png'):p.unlink()
# Regenerate deterministic offline artifact from a temporary store.
subprocess.run([sys.executable,'tools/generate_offline.py'],cwd=ROOT,check=True,capture_output=True,text=True)
html=(ROOT/'web/offline_demo.html').read_text(encoding='utf-8')
from playwright.sync_api import sync_playwright
views=['overview','constitution','self','missions','cases','evidence','procedure','mediation','adjudication','remedies','ai','interaction','entities','guidance','actions','worldlines','connectors','mesh85','audit','architecture'];checks={};errors=[]
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-web-security','--allow-file-access-from-files'])
 page=b.new_page(viewport={'width':1440,'height':1000});page.on('console',lambda m: errors.append('console:'+m.text) if m.type=='error' else None);page.on('pageerror',lambda exc: errors.append('page:'+str(exc)));page.set_content(html,wait_until='load');page.fill('#username','offline');page.fill('#password','offline');page.click('#loginBtn');page.wait_for_selector('#shell:not(.hidden)')
 for i,v in enumerate(views):
  page.click(f'[data-view="{v}"]');page.wait_for_timeout(100);path=outdir/f'{i+1:02d}_{v}.png';page.screenshot(path=str(path),full_page=True);checks[v]={'passed':path.exists() and path.stat().st_size>15000,'bytes':path.stat().st_size if path.exists() else 0,'title':page.locator('#viewTitle').inner_text()}
 m=b.new_page(viewport={'width':390,'height':844});m.set_content(html,wait_until='load');m.fill('#username','offline');m.fill('#password','offline');m.click('#loginBtn');m.wait_for_selector('#shell:not(.hidden)');m.click('[data-view="overview"]');mp=outdir/'21_mobile.png';m.screenshot(path=str(mp),full_page=True);checks['mobile']={'passed':mp.exists() and mp.stat().st_size>12000,'bytes':mp.stat().st_size if mp.exists() else 0};b.close()
checks['no_browser_errors']={'passed':not errors,'detail':errors};res={'suite':'browser_validate','checks':checks,'passed':sum(x['passed'] for x in checks.values()),'total':len(checks),'failed':[k for k,v in checks.items() if not v['passed']]};(ROOT/'outputs/browser_validate.json').write_text(json.dumps(res,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps(res,ensure_ascii=False,indent=2));sys.exit(0 if not res['failed'] else 1)
