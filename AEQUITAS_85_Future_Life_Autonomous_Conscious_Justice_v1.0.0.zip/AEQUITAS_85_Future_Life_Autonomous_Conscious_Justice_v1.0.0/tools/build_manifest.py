import sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];exclude={'MANIFEST.sha256'};lines=[]
for p in sorted(x for x in ROOT.rglob('*') if x.is_file()):
 rel=p.relative_to(ROOT).as_posix()
 if rel in exclude or rel.startswith('var/') or '__pycache__' in rel or rel.endswith('.pyc'):continue
 lines.append(f"{hashlib.sha256(p.read_bytes()).hexdigest()}  {rel}")
(ROOT/'MANIFEST.sha256').write_text('\n'.join(lines)+'\n');print(len(lines))
