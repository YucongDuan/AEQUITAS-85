import sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import json,re
from pathlib import Path
from aequitas85.engine import AEQUITAS85Engine
from aequitas85.store import KnowledgeStore
import tempfile
_tmp=tempfile.TemporaryDirectory(); e=AEQUITAS85Engine(KnowledgeStore(Path(_tmp.name)/'offline.db'));
paths={'dashboard':e.dashboard(),'constitution':e.list_kind('constitution')[0],'self':e.list_kind('self_state')[0],'self_reflection':e.list_kind('self_reflection')[0],'entities_assessments':{'items':e.list_kind('entity_assessment')},'cases':{'items':e.list_kind('case')},'cases_assessments':{'items':e.list_kind('case_assessment')},'evidence_sources':{'items':e.list_kind('source')},'evidence_cells':{'items':e.list_kind('evidence_cell')},'legal_authorities':{'items':e.list_kind('legal_authority')},'procedure_plans':{'items':e.list_kind('procedure_plan')},'mediation_plans':{'items':e.list_kind('mediation_plan')},'adjudication_drafts':{'items':e.list_kind('adjudication_draft')},'remedies_plans':{'items':e.list_kind('remedy_plan')},'ai_pathologies':{'items':e.list_kind('ai_pathology')},'interactions_risks':{'items':e.list_kind('interaction_risk')},'goals':{'items':e.list_kind('goal')},'missions_deliberations':{'items':e.list_kind('mission_deliberation')},'autonomy_status':e.autonomous_daemon_status(),'actions_gates':{'items':e.list_kind('action_gate')},'worldlines':{'items':e.list_kind('worldline')},'guidance':{'items':e.list_kind('living_guidance')},'connectors':{'items':e.list_kind('connector')},'mesh85_evaluations':{'items':e.list_kind('mesh85_evaluation')}}
html=(ROOT/'web/index.html').read_text();css=(ROOT/'web/styles.css').read_text();js=(ROOT/'web/app.js').read_text();html=re.sub(r'<link rel="icon"[^>]*>','',html);html=re.sub(r'<link rel="manifest"[^>]*>','',html);html=html.replace('<link rel="stylesheet" href="styles.css">','<style>'+css+'</style>');html=html.replace('<script src="app.js"></script>','<script>window.AEQUITAS_OFFLINE_DATA='+json.dumps(paths,ensure_ascii=False).replace('</','<\\/')+';</script><script>'+js+'</script>');(ROOT/'web/offline_demo.html').write_text(html,encoding='utf-8');print(ROOT/'web/offline_demo.html');_tmp.cleanup()
