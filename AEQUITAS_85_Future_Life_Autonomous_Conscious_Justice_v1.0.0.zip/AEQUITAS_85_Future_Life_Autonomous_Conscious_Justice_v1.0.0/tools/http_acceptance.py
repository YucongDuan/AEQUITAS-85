import sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import json,tempfile,threading,urllib.request,urllib.error,sys
from pathlib import Path
from aequitas85.app import create_server
from aequitas85.engine import AEQUITAS85Engine
from aequitas85.store import KnowledgeStore
ROOT=Path(__file__).resolve().parents[1];tmp=tempfile.TemporaryDirectory();e=AEQUITAS85Engine(KnowledgeStore(Path(tmp.name)/'a.db'));s=create_server('127.0.0.1',0,e);threading.Thread(target=s.serve_forever,daemon=True).start();base=f'http://127.0.0.1:{s.server_address[1]}';checks={}
def req(path,method='GET',body=None,token=None):
 d=json.dumps(body).encode() if body is not None else None;h={'Content-Type':'application/json'}
 if token:h['Authorization']='Bearer '+token
 r=urllib.request.urlopen(urllib.request.Request(base+path,data=d,headers=h,method=method),timeout=10);ct=r.headers.get_content_type();return json.loads(r.read()) if ct=='application/json' else True
def ck(n,fn):
 try:checks[n]={'passed':bool(fn()),'detail':'ok'}
 except Exception as ex:checks[n]={'passed':False,'detail':f'{type(ex).__name__}: {ex}'}
ck('health',lambda:req('/api/health')['status']=='ok');ck('public_catalog',lambda:req('/api/public/cases')['synthetic'])
tok=req('/api/auth/login','POST',{'username':'admin','password':'mesh85-demo'})['token']
for path,key,val in [('/api/dashboard','headline',None),('/api/constitution','declared_stance',None),('/api/cases','count',8),('/api/entities/assessments','count',12),('/api/evidence/cells','count',19),('/api/procedure/plans','count',8),('/api/mediation/plans','count',8),('/api/adjudication/drafts','count',8),('/api/remedies/plans','count',8),('/api/ai/pathologies','count',3),('/api/interactions/risks','count',3),('/api/mesh85/routes',None,25)]:
 ck('get:'+path,lambda p=path,k=key,v=val:(len(req(p,token=tok))==v if k is None else (k in req(p,token=tok) if v is None else req(p,token=tok)[k]==v)))
ck('draft_boundary',lambda:all(x['legal_effect']=='DRAFT_NO_LEGAL_EFFECT' for x in req('/api/adjudication/drafts',token=tok)['items']))
ck('audit_valid',lambda:req('/api/audit/verify',token=tok)['valid'])
ck('export_none',lambda:req('/api/export',token=tok)['legal_effect']=='none')
ck('cycle_three',lambda:len(req('/api/autonomy/run-cycle','POST',{},tok)['receipts'])==3)
ck('case_stage',lambda:req('/api/integration/case-bundle','POST',{'case_id':'X1'},tok)[0]['state']=='STAGED_FOR_HUMAN_REVIEW')
ck('evidence_stage',lambda:req('/api/integration/evidence','POST',{'evidence_id':'E1','case_id':'X1','content_sha256':'a'*64},tok)['state']=='STAGED_FOR_HUMAN_REVIEW')
ck('connector_synthetic',lambda:not req('/api/connectors/CONN-COURT-CMS/test','POST',{},tok)['external_write'])
ck('static',lambda:req('/') is True)
s.shutdown();s.server_close();tmp.cleanup();out={'suite':'http_acceptance','checks':checks,'passed':sum(x['passed'] for x in checks.values()),'total':len(checks),'failed':[k for k,v in checks.items() if not v['passed']]};(ROOT/'outputs/http_acceptance.json').write_text(json.dumps(out,ensure_ascii=False,indent=2));print(json.dumps(out,ensure_ascii=False,indent=2));sys.exit(0 if not out['failed'] else 1)
