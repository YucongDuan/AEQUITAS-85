import sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import json,subprocess,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
commands=[('unit',['python','-m','unittest','discover','-s','tests','-v']),('static',['python','tools/static_audit.py']),('http',['python','tools/http_acceptance.py']),('browser',['python','tools/browser_validate.py'])]
results=[]
for name,cmd in commands:
 if name == 'static':
  for db in (ROOT/'var').glob('*.db*'):
   db.unlink(missing_ok=True)
 p=subprocess.run(cmd,cwd=ROOT,text=True,capture_output=True);results.append({'name':name,'returncode':p.returncode,'stdout':p.stdout[-8000:],'stderr':p.stderr[-8000:]})
# The acceptance suites intentionally create an ephemeral SQLite database. Remove it after QA so the source tree remains clean.
for db in (ROOT/'var').glob('*.db*'):
 db.unlink(missing_ok=True)
# parse counts
import re
m=re.search(r'Ran (\d+) tests',results[0]['stderr']+results[0]['stdout']);unit=int(m.group(1)) if m else 0
s=json.loads((ROOT/'outputs/static_audit.json').read_text()) if (ROOT/'outputs/static_audit.json').exists() else {'passed':0,'total':0}
h=json.loads((ROOT/'outputs/http_acceptance.json').read_text()) if (ROOT/'outputs/http_acceptance.json').exists() else {'passed':0,'total':0}
b=json.loads((ROOT/'outputs/browser_validate.json').read_text()) if (ROOT/'outputs/browser_validate.json').exists() else {'passed':0,'total':0}
out={'project':'AEQUITAS-85','version':'1.0.0','passed':all(x['returncode']==0 for x in results),'suites':{'unit':{'passed':unit,'total':unit if results[0]['returncode']==0 else unit+1},'static':{'passed':s['passed'],'total':s['total']},'http':{'passed':h['passed'],'total':h['total']},'browser':{'passed':b['passed'],'total':b['total']}},'total_passed':unit+s['passed']+h['passed']+b['passed'],'total_checks':unit+s['total']+h['total']+b['total'],'commands':results,'boundary':'Engineering checks on synthetic data only; not court acceptance, legal validation, fairness certification, consciousness proof or authorization for binding judgment.'};(ROOT/'outputs/qa_summary.json').write_text(json.dumps(out,ensure_ascii=False,indent=2));print(json.dumps(out,ensure_ascii=False,indent=2));sys.exit(0 if out['passed'] else 1)
