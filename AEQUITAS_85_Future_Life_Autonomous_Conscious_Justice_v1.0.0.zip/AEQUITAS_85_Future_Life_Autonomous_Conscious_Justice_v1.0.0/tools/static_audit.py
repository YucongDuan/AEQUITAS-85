import sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import json,re,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
checks={}
def ck(name,cond,detail=''):checks[name]={'passed':bool(cond),'detail':detail}
req=['README.md','LICENSE','NOTICE','SECURITY.md','CONSTITUTION.md','openapi.json','web/index.html','web/app.js','web/styles.css','aequitas85/engine.py','aequitas85/app.py','data/cases.json','data/legal_authorities.json']
for x in req:ck('exists:'+x,(ROOT/x).exists())
source_roots=[ROOT/'aequitas85',ROOT/'web',ROOT/'data',ROOT/'docs']
source_files=[]
for base in source_roots:
    source_files.extend([p for p in base.rglob('*') if p.is_file() and p.suffix in {'.py','.js','.html','.md','.json','.css'} and p.name!='offline_demo.html'])
alltext='\n'.join(p.read_text(encoding='utf-8',errors='ignore') for p in source_files)
ck('no_vitalis_brand','VITALIS' not in alltext)
# A prohibition sentence is allowed; what must be absent is a positive runtime claim of autonomous binding legal effect.
forbidden_positive=['binding_legal_authority = true','binding_legal_authority=true','\"binding_legal_authority\": true','AI终局裁判自动生效','autonomous_binding_judgment: true']
ck('no_binding_ai_claim',not any(x in alltext for x in forbidden_positive))
ck('draft_no_legal_effect','DRAFT_NO_LEGAL_EFFECT' in alltext)
ck('external_write_default_off','AEQUITAS85_EXTERNAL_WRITE=0' in (ROOT/'config/production.env.example').read_text())
ck('doctype_block','DOCTYPE' in (ROOT/'aequitas85/protocols.py').read_text())
ck('audit_chain','previous_hash' in (ROOT/'aequitas85/store.py').read_text())
ck('cases_8',len(json.loads((ROOT/'data/cases.json').read_text()))==8)
ck('entities_12',len(json.loads((ROOT/'data/justice_entities.json').read_text()))==12)
ck('connectors_10',len(json.loads((ROOT/'data/connectors.json').read_text()))==10)
ck('roles_11',len(__import__('aequitas85.auth',fromlist=['DEMO_USERS']).DEMO_USERS)==11)
ck('routes_25',len(__import__('aequitas85.mesh85_bridge',fromlist=['route_catalog']).route_catalog())==25)
ck('web_no_external_urls',not re.search(r'https?://',(ROOT/'web/index.html').read_text()))
ck('no_runtime_db_in_source',not any((ROOT/'var').glob('*.db')))
out={'suite':'static_audit','checks':checks,'passed':sum(x['passed'] for x in checks.values()),'total':len(checks),'failed':[k for k,v in checks.items() if not v['passed']]};(ROOT/'outputs/static_audit.json').write_text(json.dumps(out,ensure_ascii=False,indent=2));print(json.dumps(out,ensure_ascii=False,indent=2));sys.exit(0 if not out['failed'] else 1)
