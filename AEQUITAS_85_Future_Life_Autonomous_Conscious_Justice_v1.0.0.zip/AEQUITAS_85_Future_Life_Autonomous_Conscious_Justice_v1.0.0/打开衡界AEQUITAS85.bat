@echo off
cd /d %~dp0
where py >nul 2>nul && (py -3 start_showcase.py & goto :eof)
python start_showcase.py
